using System.Text.Json;
using FundingRateScan.Models;

namespace FundingRateScan.Services.Exchanges;

/// <summary>Bitget USDT-FUTURES (CEX). Endpoint pubblici v2.</summary>
public class BitgetClient : IExchangeClient
{
    public string Name => "Bitget";
    private const string Base = "https://api.bitget.com";

    public async Task<IReadOnlyList<CoinMarket>> FetchMarketsAsync(CancellationToken ct)
    {
        var result = new List<CoinMarket>();
        using var doc = await HttpHelper.GetJsonAsync(
            $"{Base}/api/v2/mix/market/tickers?productType=USDT-FUTURES", ct);
        if (doc == null) return result;
        if (HttpHelper.GetString(doc.RootElement, "code") != "00000") return result;
        if (!doc.RootElement.TryGetProperty("data", out var data) || data.ValueKind != JsonValueKind.Array)
            return result;

        foreach (var t in data.EnumerateArray())
        {
            var sym = HttpHelper.GetString(t, "symbol");          // es. BTCUSDT
            if (!sym.EndsWith("USDT")) continue;
            var baseAsset = sym[..^4];
            if (SymbolUtils.IsStable(baseAsset)) continue;

            double last = HttpHelper.GetDouble(t, "lastPr");
            double oiCoin = HttpHelper.GetDouble(t, "holdingAmount"); // OI in coin
            result.Add(new CoinMarket
            {
                Exchange = Name,
                Symbol = sym,
                Base = SymbolUtils.Normalize(baseAsset),
                FundingRate = HttpHelper.GetDouble(t, "fundingRate"),
                FundingIntervalHours = 8.0,
                Volume24hUsd = HttpHelper.GetDouble(t, "usdtVolume"),
                OpenInterestUsd = oiCoin * last,
                LastPrice = last,
            });
        }
        return result;
    }

    public async Task EnrichHistoryAsync(CoinMarket m, int lookbackDays, CancellationToken ct)
    {
        using var fr = await HttpHelper.GetJsonAsync(
            $"{Base}/api/v2/mix/market/history-fund-rate?symbol={m.Symbol}&productType=USDT-FUTURES&pageSize=100", ct);
        if (fr != null && HttpHelper.GetString(fr.RootElement, "code") == "00000"
            && fr.RootElement.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array)
        {
            foreach (var e in data.EnumerateArray())
                m.FundingHistory.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(HttpHelper.GetLong(e, "fundingTime")).UtcDateTime,
                    HttpHelper.GetDouble(e, "fundingRate")));
            m.FundingHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
        }
        // Bitget non espone uno storico OI pubblico semplice: i trend OI/volume
        // restano stimati dagli altri exchange in caso di merge cross-exchange.
    }

    public async Task<List<TrendPoint>> FetchFundingHistoryAsync(string symbol, int days, CancellationToken ct)
    {
        var result = new List<TrendPoint>();
        long startMs = DateTimeOffset.UtcNow.AddDays(-days).ToUnixTimeMilliseconds();

        for (int page = 1; page <= 40; page++)
        {
            using var doc = await HttpHelper.GetJsonAsync(
                $"{Base}/api/v2/mix/market/history-fund-rate?symbol={symbol}" +
                $"&productType=USDT-FUTURES&pageSize=100&pageNo={page}", ct);
            if (doc == null || HttpHelper.GetString(doc.RootElement, "code") != "00000"
                || !doc.RootElement.TryGetProperty("data", out var data)
                || data.ValueKind != JsonValueKind.Array)
                break;

            long oldest = long.MaxValue;
            int n = 0;
            foreach (var e in data.EnumerateArray())
            {
                long t = HttpHelper.GetLong(e, "fundingTime");
                result.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(t).UtcDateTime,
                    HttpHelper.GetDouble(e, "fundingRate")));
                if (t < oldest) oldest = t;
                n++;
            }
            if (n < 100 || oldest <= startMs) break;
        }
        result.Sort((a, b) => a.Time.CompareTo(b.Time));
        return result;
    }
}
