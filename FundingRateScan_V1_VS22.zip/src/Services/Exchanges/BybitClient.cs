using System.Text.Json;
using FundingRateScan.Models;

namespace FundingRateScan.Services.Exchanges;

/// <summary>Bybit v5 perpetui lineari (CEX). Endpoint pubblici.</summary>
public class BybitClient : IExchangeClient
{
    public string Name => "Bybit";
    private const string Base = "https://api.bybit.com";

    public async Task<IReadOnlyList<CoinMarket>> FetchMarketsAsync(CancellationToken ct)
    {
        var result = new List<CoinMarket>();
        using var doc = await HttpHelper.GetJsonAsync($"{Base}/v5/market/tickers?category=linear", ct);
        if (doc == null) return result;
        if (!doc.RootElement.TryGetProperty("result", out var res)) return result;
        if (!res.TryGetProperty("list", out var list) || list.ValueKind != JsonValueKind.Array) return result;

        foreach (var t in list.EnumerateArray())
        {
            var sym = HttpHelper.GetString(t, "symbol");
            if (!sym.EndsWith("USDT")) continue;
            var baseAsset = sym[..^4];
            if (SymbolUtils.IsStable(baseAsset)) continue;

            double lastPrice = HttpHelper.GetDouble(t, "lastPrice");
            double turnover = HttpHelper.GetDouble(t, "turnover24h");           // gia' in USD
            double oiContracts = HttpHelper.GetDouble(t, "openInterest");        // in coin
            result.Add(new CoinMarket
            {
                Exchange = Name,
                Symbol = sym,
                Base = SymbolUtils.Normalize(baseAsset),
                FundingRate = HttpHelper.GetDouble(t, "fundingRate"),
                FundingIntervalHours = 8.0,
                Volume24hUsd = turnover,
                OpenInterestUsd = oiContracts * lastPrice,
                LastPrice = lastPrice,
            });
        }
        return result;
    }

    public async Task EnrichHistoryAsync(CoinMarket m, int lookbackDays, CancellationToken ct)
    {
        int limit = Math.Clamp(lookbackDays * 3, 21, 90);

        // Funding history
        using (var fr = await HttpHelper.GetJsonAsync(
            $"{Base}/v5/market/funding/history?category=linear&symbol={m.Symbol}&limit={limit}", ct))
        {
            if (fr != null && fr.RootElement.TryGetProperty("result", out var res)
                && res.TryGetProperty("list", out var list) && list.ValueKind == JsonValueKind.Array)
            {
                foreach (var e in list.EnumerateArray())
                    m.FundingHistory.Add(new TrendPoint(
                        DateTimeOffset.FromUnixTimeMilliseconds(HttpHelper.GetLong(e, "fundingRateTimestamp")).UtcDateTime,
                        HttpHelper.GetDouble(e, "fundingRate")));
            }
        }

        // Open interest history (in coin -> *prezzo per stimare USD)
        int oiLimit = Math.Clamp(lookbackDays, 7, 50);
        using (var oi = await HttpHelper.GetJsonAsync(
            $"{Base}/v5/market/open-interest?category=linear&symbol={m.Symbol}&intervalTime=1d&limit={oiLimit}", ct))
        {
            if (oi != null && oi.RootElement.TryGetProperty("result", out var res)
                && res.TryGetProperty("list", out var list) && list.ValueKind == JsonValueKind.Array)
            {
                foreach (var e in list.EnumerateArray())
                    m.OiHistory.Add(new TrendPoint(
                        DateTimeOffset.FromUnixTimeMilliseconds(HttpHelper.GetLong(e, "timestamp")).UtcDateTime,
                        HttpHelper.GetDouble(e, "openInterest") * (m.LastPrice > 0 ? m.LastPrice : 1)));
                // l'API restituisce dal piu' recente: riordino crescente
                m.OiHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
            }
        }

        // Volume history dalle candele giornaliere (turnover in USD = indice 6)
        using (var kl = await HttpHelper.GetJsonAsync(
            $"{Base}/v5/market/kline?category=linear&symbol={m.Symbol}&interval=D&limit={oiLimit}", ct))
        {
            if (kl != null && kl.RootElement.TryGetProperty("result", out var res)
                && res.TryGetProperty("list", out var list) && list.ValueKind == JsonValueKind.Array)
            {
                foreach (var c in list.EnumerateArray())
                {
                    if (c.ValueKind != JsonValueKind.Array) continue;
                    var arr = c.EnumerateArray().ToArray();
                    if (arr.Length < 7) continue;
                    long start = long.Parse(arr[0].GetString() ?? "0");
                    double turnover = HttpHelper.ParseDouble(arr[6]);
                    m.VolumeHistory.Add(new TrendPoint(
                        DateTimeOffset.FromUnixTimeMilliseconds(start).UtcDateTime, turnover));
                }
                m.VolumeHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
            }
        }
    }

    public async Task<List<TrendPoint>> FetchFundingHistoryAsync(string symbol, int days, CancellationToken ct)
    {
        var result = new List<TrendPoint>();
        long startMs = DateTimeOffset.UtcNow.AddDays(-days).ToUnixTimeMilliseconds();
        long endCursor = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        for (int page = 0; page < 30; page++)
        {
            using var doc = await HttpHelper.GetJsonAsync(
                $"{Base}/v5/market/funding/history?category=linear&symbol={symbol}" +
                $"&startTime={startMs}&endTime={endCursor}&limit=200", ct);
            if (doc == null || !doc.RootElement.TryGetProperty("result", out var res)
                || !res.TryGetProperty("list", out var list) || list.ValueKind != JsonValueKind.Array)
                break;

            long oldest = long.MaxValue;
            int n = 0;
            foreach (var e in list.EnumerateArray())
            {
                long t = HttpHelper.GetLong(e, "fundingRateTimestamp");
                result.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(t).UtcDateTime,
                    HttpHelper.GetDouble(e, "fundingRate")));
                if (t < oldest) oldest = t;
                n++;
            }
            if (n < 200 || oldest <= startMs) break;
            endCursor = oldest - 1;
        }
        result.Sort((a, b) => a.Time.CompareTo(b.Time));
        return result;
    }
}
