using System.Text.Json;
using FundingRateScan.Models;

namespace FundingRateScan.Services.Exchanges;

/// <summary>Gate.io futures USDT (CEX). Endpoint pubblici v4.</summary>
public class GateioClient : IExchangeClient
{
    public string Name => "Gate.io";
    private const string Base = "https://api.gateio.ws/api/v4/futures/usdt";

    public async Task<IReadOnlyList<CoinMarket>> FetchMarketsAsync(CancellationToken ct)
    {
        var result = new List<CoinMarket>();

        // Contratti: per quantity multiplier e total_size (OI)
        var oiBySymbol = new Dictionary<string, (double size, double mult, double mark)>(StringComparer.OrdinalIgnoreCase);
        using (var con = await HttpHelper.GetJsonAsync($"{Base}/contracts", ct))
        {
            if (con != null && con.RootElement.ValueKind == JsonValueKind.Array)
                foreach (var c in con.RootElement.EnumerateArray())
                {
                    var name = HttpHelper.GetString(c, "name");
                    oiBySymbol[name] = (
                        HttpHelper.GetDouble(c, "open_interest"),
                        HttpHelper.GetDouble(c, "quanto_multiplier"),
                        HttpHelper.GetDouble(c, "mark_price"));
                }
        }

        using var doc = await HttpHelper.GetJsonAsync($"{Base}/tickers", ct);
        if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) return result;

        foreach (var t in doc.RootElement.EnumerateArray())
        {
            var contract = HttpHelper.GetString(t, "contract");   // es. BTC_USDT
            if (!contract.EndsWith("_USDT")) continue;
            var baseAsset = contract[..^5];
            if (SymbolUtils.IsStable(baseAsset)) continue;

            double last = HttpHelper.GetDouble(t, "last");
            double oiUsd = 0;
            if (oiBySymbol.TryGetValue(contract, out var oi))
            {
                double mult = oi.mult > 0 ? oi.mult : 1;
                double mark = oi.mark > 0 ? oi.mark : last;
                oiUsd = oi.size * mult * mark;
            }

            result.Add(new CoinMarket
            {
                Exchange = Name,
                Symbol = contract,
                Base = SymbolUtils.Normalize(baseAsset),
                FundingRate = HttpHelper.GetDouble(t, "funding_rate"),
                FundingIntervalHours = 8.0,
                Volume24hUsd = HttpHelper.GetDouble(t, "volume_24h_settle"),  // in USDT
                OpenInterestUsd = oiUsd,
                LastPrice = last,
            });
        }
        return result;
    }

    public async Task EnrichHistoryAsync(CoinMarket m, int lookbackDays, CancellationToken ct)
    {
        using var fr = await HttpHelper.GetJsonAsync(
            $"{Base}/funding_rate?contract={m.Symbol}&limit=100", ct);
        if (fr != null && fr.RootElement.ValueKind == JsonValueKind.Array)
        {
            foreach (var e in fr.RootElement.EnumerateArray())
                m.FundingHistory.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeSeconds(HttpHelper.GetLong(e, "t")).UtcDateTime,
                    HttpHelper.GetDouble(e, "r")));
            m.FundingHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
        }
    }

    public async Task<List<TrendPoint>> FetchFundingHistoryAsync(string symbol, int days, CancellationToken ct)
    {
        var result = new List<TrendPoint>();
        // L'endpoint Gate.io restituisce fino a 1000 record piu' recenti (≈11 mesi a 8h).
        using var doc = await HttpHelper.GetJsonAsync($"{Base}/funding_rate?contract={symbol}&limit=1000", ct);
        if (doc != null && doc.RootElement.ValueKind == JsonValueKind.Array)
        {
            foreach (var e in doc.RootElement.EnumerateArray())
                result.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeSeconds(HttpHelper.GetLong(e, "t")).UtcDateTime,
                    HttpHelper.GetDouble(e, "r")));
            result.Sort((a, b) => a.Time.CompareTo(b.Time));
        }
        return result;
    }
}
