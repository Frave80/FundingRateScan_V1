using System.Text.Json;
using FundingRateScan.Models;

namespace FundingRateScan.Services.Exchanges;

/// <summary>HTX (ex Huobi) linear swap USDT (CEX). Endpoint pubblici.</summary>
public class HtxClient : IExchangeClient
{
    public string Name => "HTX";
    private const string Base = "https://api.hbdm.com";

    public async Task<IReadOnlyList<CoinMarket>> FetchMarketsAsync(CancellationToken ct)
    {
        var result = new List<CoinMarket>();

        // Funding corrente per tutti i contratti
        var funding = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        using (var fr = await HttpHelper.GetJsonAsync($"{Base}/linear-swap-api/v1/swap_batch_funding_rate", ct))
        {
            if (fr != null && HttpHelper.GetString(fr.RootElement, "status") == "ok"
                && fr.RootElement.TryGetProperty("data", out var fd) && fd.ValueKind == JsonValueKind.Array)
                foreach (var e in fd.EnumerateArray())
                    funding[HttpHelper.GetString(e, "contract_code")] = HttpHelper.GetDouble(e, "funding_rate");
        }

        // Volume 24h (turnover in USDT)
        using var doc = await HttpHelper.GetJsonAsync($"{Base}/v2/linear-swap-ex/market/detail/batch_merged", ct);
        if (doc == null) return result;
        if (!doc.RootElement.TryGetProperty("ticks", out var ticks) || ticks.ValueKind != JsonValueKind.Array)
            return result;

        foreach (var t in ticks.EnumerateArray())
        {
            var code = HttpHelper.GetString(t, "contract_code");   // es. BTC-USDT
            if (!code.EndsWith("-USDT")) continue;
            var baseAsset = code[..^5];
            if (SymbolUtils.IsStable(baseAsset)) continue;

            double close = HttpHelper.GetDouble(t, "close");
            double turnover = HttpHelper.GetDouble(t, "trade_turnover"); // USDT
            result.Add(new CoinMarket
            {
                Exchange = Name,
                Symbol = code,
                Base = SymbolUtils.Normalize(baseAsset),
                FundingRate = funding.TryGetValue(code, out var f) ? f : 0,
                FundingIntervalHours = 8.0,
                Volume24hUsd = turnover,
                LastPrice = close,
            });
        }

        // Open interest in coin -> USD
        using (var oi = await HttpHelper.GetJsonAsync($"{Base}/linear-swap-api/v1/swap_open_interest", ct))
        {
            if (oi != null && oi.RootElement.TryGetProperty("data", out var od) && od.ValueKind == JsonValueKind.Array)
            {
                var oiByCode = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
                foreach (var e in od.EnumerateArray())
                    oiByCode[HttpHelper.GetString(e, "contract_code")] = HttpHelper.GetDouble(e, "amount"); // in coin
                foreach (var m in result)
                    if (oiByCode.TryGetValue(m.Symbol, out var amt))
                        m.OpenInterestUsd = amt * m.LastPrice;
            }
        }
        return result;
    }

    public async Task EnrichHistoryAsync(CoinMarket m, int lookbackDays, CancellationToken ct)
    {
        using var fr = await HttpHelper.GetJsonAsync(
            $"{Base}/linear-swap-api/v1/swap_historical_funding_rate?contract_code={m.Symbol}&page_size=50&page_index=1", ct);
        if (fr != null && HttpHelper.GetString(fr.RootElement, "status") == "ok"
            && fr.RootElement.TryGetProperty("data", out var data)
            && data.TryGetProperty("data", out var arr) && arr.ValueKind == JsonValueKind.Array)
        {
            foreach (var e in arr.EnumerateArray())
                m.FundingHistory.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(HttpHelper.GetLong(e, "funding_time")).UtcDateTime,
                    HttpHelper.GetDouble(e, "funding_rate")));
            m.FundingHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
        }
    }

    public async Task<List<TrendPoint>> FetchFundingHistoryAsync(string symbol, int days, CancellationToken ct)
    {
        var result = new List<TrendPoint>();
        long startMs = DateTimeOffset.UtcNow.AddDays(-days).ToUnixTimeMilliseconds();

        for (int page = 1; page <= 40; page++)
        {
            using var doc = await HttpHelper.GetJsonAsync(
                $"{Base}/linear-swap-api/v1/swap_historical_funding_rate?contract_code={symbol}" +
                $"&page_size=50&page_index={page}", ct);
            if (doc == null || HttpHelper.GetString(doc.RootElement, "status") != "ok"
                || !doc.RootElement.TryGetProperty("data", out var data)
                || !data.TryGetProperty("data", out var arr) || arr.ValueKind != JsonValueKind.Array)
                break;

            long oldest = long.MaxValue;
            int n = 0;
            foreach (var e in arr.EnumerateArray())
            {
                long t = HttpHelper.GetLong(e, "funding_time");
                result.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(t).UtcDateTime,
                    HttpHelper.GetDouble(e, "funding_rate")));
                if (t < oldest) oldest = t;
                n++;
            }
            int totalPage = (int)HttpHelper.GetDouble(data, "total_page");
            if (n == 0 || oldest <= startMs || page >= totalPage) break;
        }
        result.Sort((a, b) => a.Time.CompareTo(b.Time));
        return result;
    }
}
