using System.Text.Json;
using FundingRateScan.Models;

namespace FundingRateScan.Services.Exchanges;

/// <summary>OKX SWAP USDT (CEX). Endpoint pubblici.</summary>
public class OkxClient : IExchangeClient
{
    public string Name => "OKX";
    private const string Base = "https://www.okx.com";

    public async Task<IReadOnlyList<CoinMarket>> FetchMarketsAsync(CancellationToken ct)
    {
        var result = new List<CoinMarket>();

        // Funding corrente per tutti gli SWAP non e' bulk: lo prendiamo dai tickers + funding-rate per candidate.
        // I tickers SWAP danno volume (volCcy24h gia' in valuta quote per OKX? -> usiamo volCcyQuote se presente).
        using var tick = await HttpHelper.GetJsonAsync($"{Base}/api/v5/market/tickers?instType=SWAP", ct);
        if (tick == null) return result;
        if (HttpHelper.GetString(tick.RootElement, "code") != "0") return result;
        if (!tick.RootElement.TryGetProperty("data", out var data) || data.ValueKind != JsonValueKind.Array)
            return result;

        // Open interest bulk
        var oiBySymbol = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        using (var oi = await HttpHelper.GetJsonAsync($"{Base}/api/v5/public/open-interest?instType=SWAP", ct))
        {
            if (oi != null && oi.RootElement.TryGetProperty("data", out var od) && od.ValueKind == JsonValueKind.Array)
                foreach (var e in od.EnumerateArray())
                    oiBySymbol[HttpHelper.GetString(e, "instId")] = HttpHelper.GetDouble(e, "oiCcy"); // in coin
        }

        // Funding bulk
        var frBySymbol = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        using (var fr = await HttpHelper.GetJsonAsync($"{Base}/api/v5/public/funding-rate?instId=ANY", ct))
        {
            // ANY potrebbe non essere supportato su tutte le versioni; ignoriamo se vuoto.
            if (fr != null && fr.RootElement.TryGetProperty("data", out var fd) && fd.ValueKind == JsonValueKind.Array)
                foreach (var e in fd.EnumerateArray())
                    frBySymbol[HttpHelper.GetString(e, "instId")] = HttpHelper.GetDouble(e, "fundingRate");
        }

        foreach (var t in data.EnumerateArray())
        {
            var inst = HttpHelper.GetString(t, "instId");
            if (!inst.EndsWith("-USDT-SWAP")) continue;
            var baseAsset = inst.Split('-')[0];
            if (SymbolUtils.IsStable(baseAsset)) continue;

            double last = HttpHelper.GetDouble(t, "last");
            double volQuote = HttpHelper.GetDouble(t, "volCcy24h") * last; // volCcy24h e' in coin -> *prezzo
            double oiCoin = oiBySymbol.TryGetValue(inst, out var o) ? o : 0;

            result.Add(new CoinMarket
            {
                Exchange = Name,
                Symbol = inst,
                Base = SymbolUtils.Normalize(baseAsset),
                FundingRate = frBySymbol.TryGetValue(inst, out var f) ? f : 0,
                FundingIntervalHours = 8.0,
                Volume24hUsd = volQuote,
                OpenInterestUsd = oiCoin * last,
                LastPrice = last,
            });
        }
        return result;
    }

    public async Task EnrichHistoryAsync(CoinMarket m, int lookbackDays, CancellationToken ct)
    {
        // Funding corrente (se non riempito nel bulk) + history
        if (m.FundingRate == 0)
        {
            using var f = await HttpHelper.GetJsonAsync($"{Base}/api/v5/public/funding-rate?instId={m.Symbol}", ct);
            if (f != null && f.RootElement.TryGetProperty("data", out var fd) && fd.ValueKind == JsonValueKind.Array)
                foreach (var e in fd.EnumerateArray())
                    m.FundingRate = HttpHelper.GetDouble(e, "fundingRate");
        }

        using (var fr = await HttpHelper.GetJsonAsync(
            $"{Base}/api/v5/public/funding-rate-history?instId={m.Symbol}&limit=100", ct))
        {
            if (fr != null && fr.RootElement.TryGetProperty("data", out var fd) && fd.ValueKind == JsonValueKind.Array)
                foreach (var e in fd.EnumerateArray())
                    m.FundingHistory.Add(new TrendPoint(
                        DateTimeOffset.FromUnixTimeMilliseconds(HttpHelper.GetLong(e, "fundingTime")).UtcDateTime,
                        HttpHelper.GetDouble(e, "fundingRate")));
            m.FundingHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
        }

        // OI + volume storici (rubik): periodo 1D
        using (var oi = await HttpHelper.GetJsonAsync(
            $"{Base}/api/v5/rubik/stat/contracts/open-interest-volume?ccy={m.Base}&period=1D", ct))
        {
            if (oi != null && oi.RootElement.TryGetProperty("data", out var od) && od.ValueKind == JsonValueKind.Array)
            {
                foreach (var c in od.EnumerateArray())
                {
                    if (c.ValueKind != JsonValueKind.Array) continue;
                    var arr = c.EnumerateArray().ToArray();
                    if (arr.Length < 3) continue;
                    long ts = long.Parse(arr[0].GetString() ?? "0");
                    double oiUsd = HttpHelper.ParseDouble(arr[1]);
                    double volUsd = HttpHelper.ParseDouble(arr[2]);
                    var dt = DateTimeOffset.FromUnixTimeMilliseconds(ts).UtcDateTime;
                    m.OiHistory.Add(new TrendPoint(dt, oiUsd));
                    m.VolumeHistory.Add(new TrendPoint(dt, volUsd));
                }
                m.OiHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
                m.VolumeHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
                if (m.OiHistory.Count > 0 && m.OpenInterestUsd == 0)
                    m.OpenInterestUsd = m.OiHistory[^1].Value;
            }
        }
    }

    public async Task<List<TrendPoint>> FetchFundingHistoryAsync(string symbol, int days, CancellationToken ct)
    {
        var result = new List<TrendPoint>();
        long startMs = DateTimeOffset.UtcNow.AddDays(-days).ToUnixTimeMilliseconds();
        string? after = null;

        for (int page = 0; page < 40; page++)
        {
            var url = $"{Base}/api/v5/public/funding-rate-history?instId={symbol}&limit=100";
            if (after != null) url += $"&after={after}";
            using var doc = await HttpHelper.GetJsonAsync(url, ct);
            if (doc == null || !doc.RootElement.TryGetProperty("data", out var data)
                || data.ValueKind != JsonValueKind.Array)
                break;

            long oldest = long.MaxValue;
            int n = 0;
            foreach (var e in data.EnumerateArray())
            {
                long t = HttpHelper.GetLong(e, "fundingTime");
                result.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(t).UtcDateTime,
                    HttpHelper.GetDouble(e, "fundingRate")));
                if (t < oldest) oldest = t;
                n++;
            }
            if (n < 100 || oldest <= startMs) break;
            after = oldest.ToString();
        }
        result.Sort((a, b) => a.Time.CompareTo(b.Time));
        return result;
    }
}
