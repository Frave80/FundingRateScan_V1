using System.Diagnostics;
using System.Reflection;

namespace FundingRateScan.Services;

/// <summary>
/// Accesso alla documentazione incorporata (Word). Permette di aprirla con
/// l'applicazione predefinita o di salvarne una copia ("scaricarla").
/// </summary>
public static class DocResources
{
    private const string GemDocResource = "GemDoc.docx";
    public const string GemDocFileName = "Scanner_Gemme_PRO_x100.docx";

    public static byte[]? GetGemDoc()
    {
        var asm = Assembly.GetExecutingAssembly();
        using var s = asm.GetManifestResourceStream(GemDocResource);
        if (s == null) return null;
        using var ms = new MemoryStream();
        s.CopyTo(ms);
        return ms.ToArray();
    }

    /// <summary>Estrae il documento in una cartella temporanea e lo apre (Word/Office).</summary>
    public static void OpenGemDoc(IWin32Window owner)
    {
        var bytes = GetGemDoc();
        if (bytes == null) { Missing(owner); return; }
        try
        {
            var path = Path.Combine(Path.GetTempPath(), GemDocFileName);
            File.WriteAllBytes(path, bytes);
            Process.Start(new ProcessStartInfo { FileName = path, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show(owner, ex.Message, "Documentazione", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    /// <summary>Salva una copia del documento nel percorso scelto dall'utente.</summary>
    public static void SaveGemDoc(IWin32Window owner)
    {
        var bytes = GetGemDoc();
        if (bytes == null) { Missing(owner); return; }
        using var sfd = new SaveFileDialog
        {
            Filter = "Documento Word (*.docx)|*.docx",
            FileName = GemDocFileName,
            Title = "Salva la documentazione dello Scanner Gemme PRO"
        };
        if (sfd.ShowDialog(owner) != DialogResult.OK) return;
        try
        {
            File.WriteAllBytes(sfd.FileName, bytes);
            if (MessageBox.Show(owner, "Documento salvato. Vuoi aprirlo ora?", "Documentazione",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                Process.Start(new ProcessStartInfo { FileName = sfd.FileName, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show(owner, ex.Message, "Documentazione", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static void Missing(IWin32Window owner)
        => MessageBox.Show(owner, "Documentazione non trovata nell'eseguibile.", "Documentazione",
            MessageBoxButtons.OK, MessageBoxIcon.Warning);
}
