using System.Text.Json;

namespace FundingRateScan.Services;

/// <summary>
/// Una coin salvata dall'utente nella watchlist (« scoperte »). L'identità è data da
/// <see cref="Key"/>: per i token on-chain è « chain:contratto », per le coin da exchange
/// centralizzato è « sym:SIMBOLO ». Così la stessa coin è riconosciuta in tutte le ricerche.
/// </summary>
public sealed class WatchedCoin
{
    public string Key { get; set; } = "";
    public string Symbol { get; set; } = "";
    public string Name { get; set; } = "";
    public string Chain { get; set; } = "";
    public string Contract { get; set; } = "";
    public string Url { get; set; } = "";
    public string Source { get; set; } = "";       // "Funding", "Gemme", "Gemme PRO", "Meme"
    public string Note { get; set; } = "";          // es. punteggio al momento del salvataggio
    public DateTime SavedUtc { get; set; } = DateTime.UtcNow;

    /// <summary>Costruisce la chiave univoca: contratto on-chain se presente, altrimenti simbolo.</summary>
    public static string MakeKey(string? chain, string? contract, string symbol)
        => !string.IsNullOrWhiteSpace(contract)
            ? $"{(chain ?? "").ToLowerInvariant()}:{contract!.ToLowerInvariant()}"
            : $"sym:{symbol.ToUpperInvariant()}";
}

/// <summary>
/// Archivio permanente delle coin salvate dall'utente, condiviso da tutte le finestre di ricerca.
/// È caricato dal file all'avvio (primo accesso) e salvato a ogni modifica, così le scoperte
/// restano fra una sessione e l'altra e una coin già salvata viene riconosciuta quando ricompare.
/// File: %APPDATA%\FundingRateScan\watchlist.json.
/// </summary>
public static class WatchlistService
{
    private static readonly string FilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "FundingRateScan", "watchlist.json");

    private static readonly JsonSerializerOptions Json = new() { WriteIndented = true };
    private static readonly object Gate = new();
    private static Dictionary<string, WatchedCoin>? _items;   // chiave → coin

    /// <summary>Evento sollevato a ogni modifica (aggiunta/rimozione): le finestre aperte possono aggiornarsi.</summary>
    public static event Action? Changed;

    private static Dictionary<string, WatchedCoin> Items
    {
        get
        {
            if (_items != null) return _items;
            lock (Gate)
            {
                if (_items != null) return _items;
                _items = Load();
            }
            return _items;
        }
    }

    private static Dictionary<string, WatchedCoin> Load()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                var list = JsonSerializer.Deserialize<List<WatchedCoin>>(File.ReadAllText(FilePath)) ?? new();
                return list.Where(c => c.Key.Length > 0).GroupBy(c => c.Key).ToDictionary(g => g.Key, g => g.First());
            }
        }
        catch { /* file assente o corrotto: si riparte da vuoto */ }
        return new Dictionary<string, WatchedCoin>();
    }

    private static void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(Items.Values.OrderByDescending(c => c.SavedUtc), Json));
        }
        catch { /* salvataggio best-effort */ }
    }

    /// <summary>Vero se la coin con questa chiave è già stata salvata (« già scoperta »).</summary>
    public static bool Contains(string key) { lock (Gate) return Items.ContainsKey(key); }

    /// <summary>Data di salvataggio della coin, o null se non presente.</summary>
    public static DateTime? SavedAt(string key)
    {
        lock (Gate) return Items.TryGetValue(key, out var c) ? c.SavedUtc : null;
    }

    /// <summary>Aggiunge (o aggiorna) una coin nella watchlist e persiste.</summary>
    public static void Add(WatchedCoin coin)
    {
        if (string.IsNullOrWhiteSpace(coin.Key)) return;
        lock (Gate)
        {
            // Conserva la data di prima scoperta se già presente.
            if (Items.TryGetValue(coin.Key, out var existing)) coin.SavedUtc = existing.SavedUtc;
            Items[coin.Key] = coin;
            Save();
        }
        Changed?.Invoke();
    }

    /// <summary>Rimuove una coin dalla watchlist e persiste.</summary>
    public static void Remove(string key)
    {
        lock (Gate)
        {
            if (!Items.Remove(key)) return;
            Save();
        }
        Changed?.Invoke();
    }

    /// <summary>Tutte le coin salvate, dalla più recente.</summary>
    public static IReadOnlyList<WatchedCoin> All()
    {
        lock (Gate) return Items.Values.OrderByDescending(c => c.SavedUtc).ToList();
    }

    public static int Count { get { lock (Gate) return Items.Count; } }
}
