using FundingRateScan.Models;

namespace FundingRateScan.Services;

public enum DecisionPriority { Alta = 1, Media = 2, Bassa = 3 }
public enum VolExpectation { Bassa = 0, Media = 1, Alta = 2 }

/// <summary>Valutazione decisionale di una coin: priorità, area e volatilità attesa.</summary>
public sealed class DecisionAssessment
{
    public DecisionPriority Priority { get; set; }
    public string PriorityLabel => Priority switch
    {
        DecisionPriority.Alta => "Alta",
        DecisionPriority.Media => "Media",
        _ => "Bassa"
    };

    /// <summary>True = area accademica (segnale teorico, non confermato dai flussi).</summary>
    public bool IsAcademic { get; set; }
    public string Area => IsAcademic ? "Accademica" : "Operativa";

    public VolExpectation Volatility { get; set; }
    public double VolScore { get; set; }
    public string VolatilityLabel => Volatility switch
    {
        VolExpectation.Alta => "Alta",
        VolExpectation.Media => "Media",
        _ => "Bassa"
    };

    public string Advice { get; set; } = "";
    public string Rationale { get; set; } = "";
}

/// <summary>
/// Trasforma i segnali grezzi (funding, persistenza, crescita volumi/OI) in una
/// raccomandazione per priorità, distinguendo l'area OPERATIVA (segnali confermati
/// dai flussi reali) dall'area ACCADEMICA (pressione funding solo teorica), e stima
/// dove è attesa alta volatilità (long affollati persistenti + open interest in aumento).
/// </summary>
public static class DecisionAdvisor
{
    public static DecisionAssessment Evaluate(CoinResult r, ScanParameters p)
    {
        bool volConfirmed = r.VolGrowthPct >= p.VolGrowthMinPct;
        bool oiConfirmed = r.OiGrowthPct >= p.OiGrowthMinPct;
        bool anyFlow = r.VolGrowthPct > 0 || r.OiGrowthPct > 0;   // conferma parziale
        bool persistent = r.PersistencePct >= p.MinPersistencePct;

        var a = new DecisionAssessment();

        // ---- Priorità e area -------------------------------------------------
        if (volConfirmed && oiConfirmed && persistent)
        {
            a.Priority = DecisionPriority.Alta;
            a.IsAcademic = false;   // Operativa: pattern pienamente confermato
            a.Advice = "Priorità alta: pattern confermato (funding persistente + volumi e OI in crescita). Coin più concreta da seguire.";
        }
        else if (persistent && anyFlow)
        {
            a.Priority = DecisionPriority.Media;
            a.IsAcademic = false;   // Operativa parziale
            string manca = !volConfirmed ? "volumi" : "open interest";
            a.Advice = $"Priorità media: conferma parziale dai flussi. Attendere conferma anche su {manca}.";
        }
        else
        {
            a.Priority = DecisionPriority.Bassa;
            a.IsAcademic = true;    // Accademica: solo pressione funding, nessuna conferma reale
            a.Advice = "Priorità bassa (area accademica): pressione funding senza conferma di volumi/OI. Solo osservazione, segnale probabilistico.";
        }

        // ---- Volatilità attesa ----------------------------------------------
        // Long affollati (funding APR elevato) + persistenti + open interest crescente
        // = accumulo di leva → maggiore rischio di squeeze/movimenti bruschi.
        double fundingComp = Clamp01(r.FundingApr / Math.Max(1.0, p.FundingAprThreshold * 3.0));
        double persistComp = Clamp01(r.PersistencePct / 100.0);
        double oiComp = Clamp01(r.OiGrowthPct / 40.0);
        a.VolScore = 0.45 * fundingComp + 0.25 * persistComp + 0.30 * oiComp;

        a.Volatility = (a.VolScore >= 0.66 || r.FundingApr >= 100)
            ? VolExpectation.Alta
            : a.VolScore >= 0.40 ? VolExpectation.Media : VolExpectation.Bassa;

        // ---- Motivazione testuale -------------------------------------------
        var parts = new List<string>
        {
            $"Funding APR {r.FundingApr:N1}% · persistenza {r.PersistencePct:N0}%",
            $"Δvolume {r.VolGrowthPct:+0.0;-0.0;0}% · Δopen interest {r.OiGrowthPct:+0.0;-0.0;0}%"
        };
        if (a.Volatility == VolExpectation.Alta)
            parts.Add("⚠ Alta volatilità attesa: leva affollata e in aumento, possibile squeeze.");
        else if (a.Volatility == VolExpectation.Media)
            parts.Add("Volatilità attesa moderata.");
        a.Rationale = string.Join("  ·  ", parts);

        return a;
    }

    private static double Clamp01(double v) => Math.Max(0.0, Math.Min(1.0, v));
}
