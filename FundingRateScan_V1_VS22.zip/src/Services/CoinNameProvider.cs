using System.Text.Json;

namespace FundingRateScan.Services;

/// <summary>
/// Mappa simbolo → nome completo (es. BTC → Bitcoin) usando le prime pagine
/// per market cap di CoinGecko. Caricato una sola volta e messo in cache.
/// In caso di errore o rate-limit, i nomi mancanti ripiegano sul simbolo.
/// </summary>
public static class CoinNameProvider
{
    private static Dictionary<string, string>? _map;
    private static readonly SemaphoreSlim _gate = new(1, 1);

    public static async Task EnsureLoadedAsync(IProgress<string> log, CancellationToken ct)
    {
        if (_map != null) return;
        await _gate.WaitAsync(ct);
        try
        {
            if (_map != null) return;
            var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            for (int page = 1; page <= 3; page++)
            {
                var url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd" +
                          $"&order=market_cap_desc&per_page=250&page={page}&sparkline=false";
                using var doc = await HttpHelper.GetJsonAsync(url, ct);
                if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) break;

                int count = 0;
                foreach (var c in doc.RootElement.EnumerateArray())
                {
                    var sym = HttpHelper.GetString(c, "symbol").ToUpperInvariant();
                    var name = HttpHelper.GetString(c, "name");
                    if (sym.Length > 0 && name.Length > 0 && !map.ContainsKey(sym))
                        map[sym] = name;
                    count++;
                }
                if (count == 0) break;
                if (page < 3) await Task.Delay(1500, ct);   // rispetta i limiti di rate
            }

            _map = map;
            log.Report($"Nomi coin caricati da CoinGecko: {map.Count}");
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            _map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            log.Report($"Nomi coin non disponibili ({ex.Message}); userò i simboli.");
        }
        finally
        {
            _gate.Release();
        }
    }

    public static string GetName(string baseSymbol)
        => _map != null && _map.TryGetValue(baseSymbol, out var n) ? n : baseSymbol;
}
