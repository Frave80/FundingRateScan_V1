using System.Collections.Concurrent;
using System.Text.Json;
using FundingRateScan.Gems;
using FundingRateScan.Services;

namespace FundingRateScan.Meme;

/// <summary>
/// Implementazione di IMemeSignalSource che riusa i dati gia' raccolti e arricchiti
/// dalla pipeline gemme (DEX Screener + GoPlus/Ethplorer via GemEnrichmentService).
/// Per la dimensione "Derivati" tenta il funding del perpetuo su Binance.
/// Cosi' il modulo si innesta sull'esistente senza duplicare i client (cap. 10.2/10.3).
/// </summary>
public sealed class GemBackedMemeSignalSource : IMemeSignalSource
{
    private readonly IReadOnlyDictionary<string, GemCandidate> _byToken;
    private readonly IReadOnlyDictionary<string, SocialData> _social;
    private readonly ConcurrentDictionary<string, DerivativesSignal> _derivCache = new();

    private Dictionary<string, double>? _allFunding;
    private readonly SemaphoreSlim _fundLock = new(1, 1);

    // Cache bulk del miglior bid/ask (order book) di tutti i perpetui Binance (cap. 9.1).
    private Dictionary<string, (double bid, double ask)>? _allBook;
    private readonly SemaphoreSlim _bookLock = new(1, 1);

    public GemBackedMemeSignalSource(IEnumerable<GemCandidate> enrichedGems,
        IReadOnlyDictionary<string, SocialData>? social = null)
    {
        _byToken = enrichedGems
            .GroupBy(g => g.TokenAddress.ToLowerInvariant())
            .ToDictionary(g => g.Key, g => g.First());
        _social = social ?? new Dictionary<string, SocialData>();
    }

    private GemCandidate? Find(MemeCandidate c)
        => _byToken.TryGetValue(c.TokenAddress.ToLowerInvariant(), out var g) ? g : null;

    public async Task<LiquiditySignal?> GetLiquidityAsync(MemeCandidate c, CancellationToken ct)
    {
        var g = Find(c);
        if (g == null || g.LiquidityUsd <= 0) return null;
        return new LiquiditySignal
        {
            LiquidityUsd = g.LiquidityUsd,
            LiqToMcap = g.LiqToMcap,
            Volume24hUsd = g.Volume24hUsd,
            TurnoverRatio = g.TurnoverRatio,
            // Spread bid-ask reale (cap. 9.1) se la coin ha un mercato perpetuo su Binance.
            SpreadBps = await CexSpreadBpsAsync(c.Symbol, ct),
        };
    }

    public Task<HolderStats?> GetHolderStatsAsync(MemeCandidate c, CancellationToken ct)
    {
        var g = Find(c);
        if (g == null || (g.HolderCount == null && g.Top10HoldersPct == null))
            return Task.FromResult<HolderStats?>(null);
        return Task.FromResult<HolderStats?>(new HolderStats
        {
            HolderCount = g.HolderCount,
            Top10Pct = g.Top10HoldersPct,
            HolderGrowthPct = g.HolderGrowthPct,   // crescita vs snapshot precedente (cap. 9.2)
        });
    }

    public Task<ParticipationSignal?> GetParticipationAsync(MemeCandidate c, CancellationToken ct)
    {
        var g = Find(c);
        if (g == null || (g.Buys24 + g.Sells24) == 0) return Task.FromResult<ParticipationSignal?>(null);
        bool divergence = g.PriceChg6h > 15 && (g.BuyRatio < 0.5 || g.TurnoverRatio < 0.3);
        return Task.FromResult<ParticipationSignal?>(new ParticipationSignal
        {
            BuyRatio = g.BuyRatio,
            Velocity = g.TurnoverRatio,
            PriceChg6h = g.PriceChg6h,
            PriceWithoutParticipation = divergence,
        });
    }

    public Task<MarketMeta?> GetMarketMetaAsync(MemeCandidate c, CancellationToken ct)
    {
        var g = Find(c);
        if (g == null) return Task.FromResult<MarketMeta?>(null);

        _social.TryGetValue(c.TokenAddress.ToLowerInvariant(), out var sd);
        return Task.FromResult<MarketMeta?>(new MarketMeta
        {
            ExchangeCount = sd != null && sd.ExchangeCount > 0 ? sd.ExchangeCount : 1,
            CoinGeckoListed = sd?.CoinGeckoListed ?? g.CoinGeckoListed,
            CommunityScore = sd?.CommunityScore,
            DeveloperScore = sd?.DeveloperScore,
            NewListing = sd?.NewListing ?? false,
        });
    }

    public Task<SurvivalSignal?> GetSurvivalAsync(MemeCandidate c, CancellationToken ct)
    {
        var g = Find(c);
        if (g == null) return Task.FromResult<SurvivalSignal?>(null);
        return Task.FromResult<SurvivalSignal?>(new SurvivalSignal
        {
            AgeDays = g.AgeDays,
            LpLockedPct = g.LpLockedPct,
            IsHoneypot = g.IsHoneypot,
            PossibleSpam = g.PossibleSpam,
            ContinuityOk = g.Volume24hUsd > 0,
        });
    }

    public async Task<DerivativesSignal?> GetDerivativesAsync(MemeCandidate c, CancellationToken ct)
    {
        var sym = (c.Symbol ?? "").ToUpperInvariant();
        if (sym.Length == 0) return null;
        if (_derivCache.TryGetValue(sym, out var cached))
            return cached.Available ? cached : null;

        await EnsureFundingAsync(ct);
        var d = new DerivativesSignal { Available = false };

        // Trova il simbolo perp corrispondente (anche varianti 1000x delle meme)
        string? perp = null;
        foreach (var v in new[] { $"{sym}USDT", $"1000{sym}USDT", $"1000000{sym}USDT" })
            if (_allFunding!.ContainsKey(v)) { perp = v; break; }

        if (perp != null)
        {
            double rate = _allFunding![perp];
            d.Available = true;
            d.FundingApr = rate * 3 * 365 * 100;
            d.PersistencePct = await FundingPersistenceAsync(perp, ct);
            d.OiGrowthPct = await OiGrowthAsync(perp, ct);
        }
        _derivCache[sym] = d;
        return d.Available ? d : null;
    }

    /// <summary>Carica una sola volta tutti i funding correnti Binance (1 richiesta invece di N).</summary>
    private async Task EnsureFundingAsync(CancellationToken ct)
    {
        if (_allFunding != null) return;
        await _fundLock.WaitAsync(ct);
        try
        {
            if (_allFunding != null) return;
            var map = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            using var doc = await HttpHelper.GetJsonAsync("https://fapi.binance.com/fapi/v1/premiumIndex", ct);
            if (doc != null && doc.RootElement.ValueKind == JsonValueKind.Array)
                foreach (var p in doc.RootElement.EnumerateArray())
                    map[HttpHelper.GetString(p, "symbol")] = HttpHelper.GetDouble(p, "lastFundingRate");
            _allFunding = map;
        }
        catch { _allFunding = new Dictionary<string, double>(); }
        finally { _fundLock.Release(); }
    }

    /// <summary>
    /// Spread bid-ask (cap. 9.1) della coin sul mercato perpetuo Binance, in punti base.
    /// Restituisce null se la coin non ha un mercato CEX (caso comune delle micro-cap nuove):
    /// in quel caso la dimensione liquidità usa il proxy on-chain (profondità del pool).
    /// </summary>
    private async Task<double?> CexSpreadBpsAsync(string symbol, CancellationToken ct)
    {
        var sym = (symbol ?? "").ToUpperInvariant();
        if (sym.Length == 0) return null;
        await EnsureBookAsync(ct);

        foreach (var v in new[] { $"{sym}USDT", $"1000{sym}USDT", $"1000000{sym}USDT" })
            if (_allBook!.TryGetValue(v, out var q) && q.bid > 0 && q.ask > 0)
            {
                double mid = (q.bid + q.ask) / 2.0;
                if (mid <= 0) return null;
                return Math.Round((q.ask - q.bid) / mid * 10_000.0, 1);   // punti base
            }
        return null;
    }

    /// <summary>Carica una sola volta il miglior bid/ask di tutti i perpetui Binance (1 richiesta).</summary>
    private async Task EnsureBookAsync(CancellationToken ct)
    {
        if (_allBook != null) return;
        await _bookLock.WaitAsync(ct);
        try
        {
            if (_allBook != null) return;
            var map = new Dictionary<string, (double, double)>(StringComparer.OrdinalIgnoreCase);
            using var doc = await HttpHelper.GetJsonAsync("https://fapi.binance.com/fapi/v1/ticker/bookTicker", ct);
            if (doc != null && doc.RootElement.ValueKind == JsonValueKind.Array)
                foreach (var p in doc.RootElement.EnumerateArray())
                    map[HttpHelper.GetString(p, "symbol")] =
                        (HttpHelper.GetDouble(p, "bidPrice"), HttpHelper.GetDouble(p, "askPrice"));
            _allBook = map;
        }
        catch { _allBook = new Dictionary<string, (double, double)>(); }
        finally { _bookLock.Release(); }
    }

    /// <summary>Persistenza reale: quota di funding positivi nelle ultime ~90 osservazioni (8h).</summary>
    private static async Task<double> FundingPersistenceAsync(string perp, CancellationToken ct)
    {
        try
        {
            using var doc = await HttpHelper.GetJsonAsync(
                $"https://fapi.binance.com/fapi/v1/fundingRate?symbol={perp}&limit=90", ct);
            if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) return 50;
            int n = 0, pos = 0;
            foreach (var e in doc.RootElement.EnumerateArray())
            { n++; if (HttpHelper.GetDouble(e, "fundingRate") > 0) pos++; }
            return n > 0 ? Math.Round(100.0 * pos / n, 0) : 50;
        }
        catch { return 50; }
    }

    /// <summary>Crescita dell'open interest (prima vs ultima osservazione, periodo 1d, ~14 giorni).</summary>
    private static async Task<double> OiGrowthAsync(string perp, CancellationToken ct)
    {
        try
        {
            using var doc = await HttpHelper.GetJsonAsync(
                $"https://fapi.binance.com/futures/data/openInterestHist?symbol={perp}&period=1d&limit=14", ct);
            if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) return 0;
            var vals = new List<double>();
            foreach (var e in doc.RootElement.EnumerateArray())
                vals.Add(HttpHelper.GetDouble(e, "sumOpenInterestValue"));
            if (vals.Count < 2 || vals[0] <= 0) return 0;
            return Math.Round((vals[^1] - vals[0]) / vals[0] * 100.0, 0);
        }
        catch { return 0; }
    }
}
