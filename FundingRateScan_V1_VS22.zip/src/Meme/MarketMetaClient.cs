using System.Text.Json;
using FundingRateScan.Gems;
using FundingRateScan.Services;

namespace FundingRateScan.Meme;

/// <summary>
/// Estende l'uso di CoinGecko per il momentum sociale e di sviluppo (cap. 9.6, tab. 59).
/// Dato chain + contratto, recupera community/developer score, numero di exchange e
/// presenza su CoinGecko tramite l'endpoint /coins/{platform}/contract/{address}.
/// Best-effort e con rate limit; i token non quotati su CoinGecko restano "non coperti".
/// </summary>
public sealed class MarketMetaClient
{
    private static readonly Dictionary<string, string> Platform = new(StringComparer.OrdinalIgnoreCase)
    {
        ["ethereum"] = "ethereum", ["bsc"] = "binance-smart-chain", ["polygon"] = "polygon-pos",
        ["arbitrum"] = "arbitrum-one", ["base"] = "base", ["solana"] = "solana",
        ["optimism"] = "optimistic-ethereum", ["avalanche"] = "avalanche",
    };

    // Store riusato per gli snapshot del numero di exchange (rilevamento nuovo listing, cap. 9.5).
    private readonly MemeHolderStore _listingStore = new();

    /// <summary>Arricchisce con i segnali sociali le prime <paramref name="topN"/> gemme (per score di mercato).</summary>
    public async Task<Dictionary<string, SocialData>> EnrichSocialAsync(
        List<GemCandidate> gems, int topN, IProgress<string> log, CancellationToken ct)
    {
        var map = new Dictionary<string, SocialData>(StringComparer.OrdinalIgnoreCase);
        var top = gems.OrderByDescending(g => g.Score).Take(Math.Min(topN, gems.Count)).ToList();
        log.Report($"Momentum sociale: interrogo CoinGecko per {top.Count} coin...");

        int done = 0;
        foreach (var g in top)
        {
            ct.ThrowIfCancellationRequested();
            var sd = await FetchAsync(g.Chain, g.TokenAddress, ct);
            if (sd != null)
            {
                // Nuovo listing (cap. 9.5): il numero di exchange è cresciuto rispetto alla
                // scansione precedente → catalizzatore di liquidità/accesso. Riuso lo store
                // degli snapshot con una chiave dedicata ("listing_") per non confondere con gli holder.
                if (sd.ExchangeCount > 0)
                {
                    var delta = _listingStore.UpdateAndGetGrowth(g.Chain, "listing_" + g.TokenAddress, sd.ExchangeCount);
                    sd.NewListing = delta is > 0;
                }
                map[g.TokenAddress.ToLowerInvariant()] = sd;
            }
            if (++done % 5 == 0 || done == top.Count) log.Report($"  Sociale {done}/{top.Count}...");
            await Task.Delay(1500, ct);   // rispetto dei rate limit gratuiti CoinGecko
        }
        return map;
    }

    public async Task<SocialData?> FetchAsync(string chain, string contract, CancellationToken ct)
    {
        if (!Platform.TryGetValue(chain, out var platform) || string.IsNullOrWhiteSpace(contract))
            return null;

        var url = $"https://api.coingecko.com/api/v3/coins/{platform}/contract/{contract}" +
                  "?localization=false&tickers=true&market_data=false&community_data=true&developer_data=true&sparkline=false";
        using var doc = await HttpHelper.GetJsonAsync(url, ct);
        if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Object) return null;
        var root = doc.RootElement;
        if (!root.TryGetProperty("id", out _)) return null;   // 404/non quotata

        var sd = new SocialData { CoinGeckoListed = true };

        // Score nativi CoinGecko (quando presenti)
        double cg = HttpHelper.GetDouble(root, "community_score");
        double dg = HttpHelper.GetDouble(root, "developer_score");

        // Fallback: deriva dai dati grezzi community/developer
        if (cg <= 0 && root.TryGetProperty("community_data", out var cd) && cd.ValueKind == JsonValueKind.Object)
        {
            double followers = Math.Max(Math.Max(
                HttpHelper.GetDouble(cd, "twitter_followers"),
                HttpHelper.GetDouble(cd, "reddit_subscribers")),
                HttpHelper.GetDouble(cd, "telegram_channel_user_count"));
            if (followers > 0) cg = Clamp01(Math.Log10(1 + followers) / 6.0) * 100;   // 1M follower → 100
        }
        if (dg <= 0 && root.TryGetProperty("developer_data", out var dd) && dd.ValueKind == JsonValueKind.Object)
        {
            double stars = HttpHelper.GetDouble(dd, "stars");
            double commits = HttpHelper.GetDouble(dd, "commit_count_4_weeks");
            if (stars > 0 || commits > 0)
                dg = (0.6 * Clamp01(Math.Log10(1 + stars) / 4.0) + 0.4 * Clamp01(commits / 50.0)) * 100;
        }
        if (cg > 0) sd.CommunityScore = Math.Round(cg, 0);
        if (dg > 0) sd.DeveloperScore = Math.Round(dg, 0);

        // Numero di exchange (tickers distinti per market)
        if (root.TryGetProperty("tickers", out var tickers) && tickers.ValueKind == JsonValueKind.Array)
        {
            var markets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var t in tickers.EnumerateArray())
                if (t.TryGetProperty("market", out var m) && m.ValueKind == JsonValueKind.Object)
                    markets.Add(HttpHelper.GetString(m, "name"));
            sd.ExchangeCount = markets.Count;
        }
        return sd;
    }

    private static double Clamp01(double v) => Math.Max(0, Math.Min(1, v));
}
