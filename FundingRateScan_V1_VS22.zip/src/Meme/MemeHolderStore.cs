using System.Text.Json;

namespace FundingRateScan.Meme;

/// <summary>
/// Persistenza degli snapshot del numero di holder per misurare il tasso di crescita
/// fra una scansione e l'altra (cap. 9.2). La crescita degli holder è una misura diretta
/// di adozione autentica; è disponibile solo dalla seconda rilevazione in poi.
/// File JSON in %APPDATA%\FundingRateScan\meme\holders\{chain}_{token}.json.
/// </summary>
public sealed class MemeHolderStore
{
    private static readonly string Root =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "FundingRateScan", "meme", "holders");

    private static readonly JsonSerializerOptions Json = new() { WriteIndented = false };

    /// <summary>Intervallo minimo perché due rilevazioni siano confrontabili (evita confronti intra-sessione).</summary>
    private static readonly TimeSpan MinGap = TimeSpan.FromMinutes(30);

    private sealed record Snap(long T, long C);   // tempo unix (s), conteggio

    /// <summary>
    /// Registra il conteggio corrente e restituisce la crescita % rispetto allo snapshot
    /// precedente più recente (con almeno MinGap di distanza). Null se è la prima rilevazione
    /// o non c'è uno snapshot abbastanza vecchio.
    /// </summary>
    public double? UpdateAndGetGrowth(string chain, string token, long currentCount)
    {
        if (currentCount <= 0) return null;
        var path = PathFor(chain, token);
        var history = Load(path);
        long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

        double? growth = null;
        var prior = history
            .Where(s => now - s.T >= MinGap.TotalSeconds && s.C > 0)
            .OrderByDescending(s => s.T)
            .FirstOrDefault();
        if (prior != null)
            growth = Math.Round((currentCount - prior.C) / (double)prior.C * 100.0, 1);

        history.Add(new Snap(now, currentCount));
        if (history.Count > 60) history = history.OrderByDescending(s => s.T).Take(60).ToList();
        Save(path, history);
        return growth;
    }

    private static string PathFor(string chain, string token)
    {
        Directory.CreateDirectory(Root);
        var safe = $"{chain}_{token}".Replace("/", "_").Replace("\\", "_");
        return Path.Combine(Root, safe + ".json");
    }

    private static List<Snap> Load(string path)
    {
        try { return File.Exists(path) ? JsonSerializer.Deserialize<List<Snap>>(File.ReadAllText(path)) ?? new() : new(); }
        catch { return new(); }
    }

    private static void Save(string path, List<Snap> h)
    {
        try { File.WriteAllText(path, JsonSerializer.Serialize(h, Json)); } catch { }
    }
}
