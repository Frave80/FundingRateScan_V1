namespace FundingRateScan.Meme;

/// <summary>
/// Calcola il punteggio composito meco (cap. 8.4 / 9.9): combina i segnali in quattro
/// dimensioni (Liquidità & mercato, Adozione on-chain, Derivati, Momentum sociale),
/// applica la penalità di rischio moltiplicativa e classifica lo stato. I dati mancanti
/// non azzerano il punteggio: la dimensione viene esclusa dalla media e segnalata dalla
/// copertura (cap. 10.4). Consuma IMemeSignalSource senza modificare ScanService.
/// </summary>
public sealed class MemeScoringService
{
    private readonly MemeScoringSettings _s;

    public MemeScoringService(MemeScoringSettings settings) => _s = settings;

    public async Task<List<MemeScore>> ScoreAsync(
        IEnumerable<MemeCandidate> candidates, IMemeSignalSource source,
        IProgress<string> log, CancellationToken ct)
    {
        var results = new List<MemeScore>();
        var list = candidates.ToList();
        int i = 0;
        foreach (var c in list)
        {
            ct.ThrowIfCancellationRequested();
            results.Add(await ScoreOneAsync(c, source, ct));
            if (++i % 10 == 0 || i == list.Count) log.Report($"  Valutazione meme {i}/{list.Count}...");
        }
        return results.OrderByDescending(r => r.Composite).ToList();
    }

    public async Task<MemeScore> ScoreOneAsync(MemeCandidate c, IMemeSignalSource src, CancellationToken ct)
    {
        var liq = await src.GetLiquidityAsync(c, ct);
        var hold = await src.GetHolderStatsAsync(c, ct);
        var part = await src.GetParticipationAsync(c, ct);
        var meta = await src.GetMarketMetaAsync(c, ct);
        var surv = await src.GetSurvivalAsync(c, ct);
        var deriv = await src.GetDerivativesAsync(c, ct);

        var score = new MemeScore { Candidate = c };

        // ---- Dimensione 1: Liquidità & mercato (30%) -----------------------
        if (liq != null)
        {
            double liqAbs = C01(Math.Log10(Math.Max(1, liq.LiquidityUsd) / 10_000.0) / 2.0);
            double band = LiqBand(liq.LiqToMcap);
            double turn = C01(Math.Log10(1 + liq.TurnoverRatio) / Math.Log10(11));
            double exch = meta != null ? C01(meta.ExchangeCount / 5.0) : 0;

            double dim1;
            if (liq.SpreadBps.HasValue)
            {
                // Spread bid-ask reale (cap. 9.1): mercato più stretto = più liquido.
                // 0 bps → 1, 50 bps → 0. Sostituisce in parte il proxy quando il dato c'è.
                double spreadScore = C01((50.0 - liq.SpreadBps.Value) / 50.0);
                dim1 = 0.30 * liqAbs + 0.25 * band + 0.17 * turn + 0.13 * exch + 0.15 * spreadScore;
                score.Rationale.Add($"spread CEX {liq.SpreadBps.Value:N1} bps");
            }
            else
            {
                // Nessun mercato CEX: si usa il proxy on-chain (profondità del pool).
                dim1 = 0.35 * liqAbs + 0.30 * band + 0.20 * turn + 0.15 * exch;
            }

            // Catalizzatore "nuovo listing" (cap. 9.5): +8 punti, limitato a 100.
            if (meta?.NewListing == true) { dim1 = Math.Min(1.0, dim1 + 0.08); score.Rationale.Add("nuovo listing CEX rilevato (catalizzatore)"); }
            score.Liquidity = R(dim1);
            score.Rationale.Add($"Liquidità {liq.LiquidityUsd:N0}$ (liq/mcap {liq.LiqToMcap * 100:N1}%), turnover {liq.TurnoverRatio:N2}");
        }

        // ---- Dimensione 2: Adozione on-chain (30%) -------------------------
        var subs = new List<(double w, double v)>();
        if (hold != null)
        {
            if (hold.HolderCount.HasValue)
                subs.Add((0.5, C01(Math.Log10(Math.Max(1, hold.HolderCount.Value) / 100.0) / 2.0)));
            if (hold.Top10Pct.HasValue)
                subs.Add((0.5, C01((70.0 - hold.Top10Pct.Value) / 40.0)));   // meno concentrazione = meglio
            if (hold.HolderGrowthPct.HasValue)
                subs.Add((0.5, C01(hold.HolderGrowthPct.Value / 50.0)));
        }
        if (part != null)
        {
            subs.Add((0.6, C01((part.BuyRatio - 0.45) / 0.35)));
            subs.Add((0.4, C01(Math.Log10(1 + part.Velocity) / Math.Log10(11))));
        }
        if (subs.Count > 0)
        {
            double wsum = subs.Sum(x => x.w);
            double v = subs.Sum(x => x.w * x.v) / wsum;
            if (part?.PriceWithoutParticipation == true) v *= 0.8;   // divergenza prezzo/partecipazione
            score.Adoption = R(v);
            if (hold?.HolderCount != null)
            {
                string growth = hold.HolderGrowthPct switch
                {
                    null => "",
                    > 5 => $", holder +{hold.HolderGrowthPct:N1}% (accelerazione)",
                    < -2 => $", holder {hold.HolderGrowthPct:N1}% (declino)",
                    _ => $", holder {hold.HolderGrowthPct:N1}% (stallo)"
                };
                score.Rationale.Add($"{hold.HolderCount:N0} holders, top10 {hold.Top10Pct?.ToString("N1") ?? "n.d."}%{growth}");
            }
        }

        // ---- Dimensione 3: Derivati (25%) ----------------------------------
        if (deriv is { Available: true })
        {
            double fund = C01(deriv.FundingApr / 50.0) * (deriv.PersistencePct / 100.0);
            double oi = C01(deriv.OiGrowthPct / 40.0);
            score.Derivatives = R(0.7 * fund + 0.3 * oi);
            score.Rationale.Add($"Funding {deriv.FundingApr:N0}% APR (perp presente)");
        }

        // ---- Dimensione 4: Momentum sociale (15%) --------------------------
        var soc = new List<double>();
        if (meta != null)
        {
            if (meta.CommunityScore.HasValue) soc.Add(C01(meta.CommunityScore.Value / 100.0));
            if (meta.DeveloperScore.HasValue) soc.Add(C01(meta.DeveloperScore.Value / 100.0));
            if (meta.CoinGeckoListed.HasValue) soc.Add(meta.CoinGeckoListed.Value ? 0.7 : 0.2);
        }
        if (soc.Count > 0) score.Social = R(soc.Average());

        // ---- Penalità di rischio + filtro sopravvivenza (cap. 9.7) ---------
        double pen = 1.0;
        double minAgeDays = _s.MinAgeHoursSurvival / 24.0;
        if (surv != null)
        {
            if (surv.IsHoneypot == true) { pen = 0; score.SurvivalOk = false; score.RiskNotes.Add("HONEYPOT: vendita bloccata"); }
            if (surv.PossibleSpam == true) { pen *= 0.5; score.SurvivalOk = false; score.RiskNotes.Add("possibile spam"); }
            if (surv.LpLockedPct is < 20) { pen *= 0.8; score.RiskNotes.Add("LP poco bloccata (rug)"); }
            if (surv.AgeDays > 0 && surv.AgeDays < minAgeDays)
            { pen *= 0.7; score.SurvivalOk = false; score.RiskNotes.Add($"troppo giovane (<{_s.MinAgeHoursSurvival:N0}h)"); }
            if (!surv.ContinuityOk) { pen *= 0.7; score.SurvivalOk = false; score.RiskNotes.Add("attività interrotta (possibile rug)"); }
        }
        if (hold?.Top10Pct is >= 70) { pen *= 0.65; score.RiskNotes.Add("concentrazione estrema top10"); }
        else if (hold?.Top10Pct is >= 50) { pen *= 0.85; score.RiskNotes.Add("alta concentrazione top10"); }
        if (part?.PriceWithoutParticipation == true) { pen *= 0.85; score.RiskNotes.Add("prezzo senza partecipazione"); }
        score.RiskPenalty = Math.Round(Math.Clamp(pen, 0, 1), 2);

        // ---- Composito + copertura + stato ---------------------------------
        var dims = new List<(double w, double? v)>
        {
            (_s.WLiquidity, score.Liquidity),
            (_s.WAdoption, score.Adoption),
            (_s.WDerivatives, score.Derivatives),
            (_s.WSocial, score.Social),
        };
        var present = dims.Where(d => d.v.HasValue).ToList();
        score.CoveragePct = Math.Round(100.0 * present.Count / dims.Count, 0);

        if (present.Count > 0)
        {
            double wsum = present.Sum(d => d.w);
            double mean = present.Sum(d => d.w * d.v!.Value) / wsum;
            score.Composite = Math.Round(mean * score.RiskPenalty, 0);
        }

        score.State = Classify(score);
        return score;
    }

    private MemeState Classify(MemeScore s)
    {
        if (s.RiskPenalty < _s.RiskExcludeBelow) return MemeState.RischioElevato;
        // Filtro sopravvivenza (cap. 9.7): senza superarlo, non si accede ad "Alto potenziale".
        if (s.Composite >= _s.HighThreshold && s.RiskPenalty >= 0.7 && s.SurvivalOk) return MemeState.AltoPotenziale;
        if (s.Composite >= _s.EmergingThreshold) return MemeState.Emergente;
        return MemeState.DaOsservare;
    }

    /// <summary>
    /// Dimensione "Derivati" del punteggio meme (0..100) calcolabile dai soli dati funding,
    /// senza indirizzo del contratto. Usata per la colonna "Pot. meme" della tabella funding
    /// (integrazione opzionale cap. 10.2) e dalla scheda "Segnali meme" del dettaglio coin.
    /// </summary>
    public static double DerivativesDimension(double fundingApr, double persistencePct, double oiGrowthPct)
    {
        double fund = C01(fundingApr / 50.0) * C01(persistencePct / 100.0);
        double oi = C01(oiGrowthPct / 40.0);
        return R(0.7 * fund + 0.3 * oi);
    }

    private static double C01(double v) => Math.Max(0, Math.Min(1, v));
    private static double R(double unit01) => Math.Round(unit01 * 100.0, 0);

    private static double LiqBand(double ratio)
    {
        if (ratio <= 0) return 0;
        if (ratio < 0.02) return ratio / 0.02 * 0.3;
        if (ratio <= 0.20) return 1.0;
        if (ratio <= 0.60) return 1.0 - (ratio - 0.20) / 0.40 * 0.5;
        return 0.4;
    }
}
