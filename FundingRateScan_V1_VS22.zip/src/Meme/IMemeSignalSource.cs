namespace FundingRateScan.Meme;

/// <summary>
/// Contratto delle fonti di segnali meme (cap. 10.3, tab. 61). Speculare a
/// IExchangeClient ma per dati on-chain/di mercato. Convive con i contratti
/// esistenti senza modificarli: viene composto da MemeScoringService.
/// Ogni metodo restituisce null se il dato non e' disponibile (gestione copertura).
/// </summary>
public interface IMemeSignalSource
{
    Task<LiquiditySignal?> GetLiquidityAsync(MemeCandidate c, CancellationToken ct);
    Task<HolderStats?> GetHolderStatsAsync(MemeCandidate c, CancellationToken ct);
    Task<ParticipationSignal?> GetParticipationAsync(MemeCandidate c, CancellationToken ct);
    Task<MarketMeta?> GetMarketMetaAsync(MemeCandidate c, CancellationToken ct);
    Task<SurvivalSignal?> GetSurvivalAsync(MemeCandidate c, CancellationToken ct);
    Task<DerivativesSignal?> GetDerivativesAsync(MemeCandidate c, CancellationToken ct);
}
