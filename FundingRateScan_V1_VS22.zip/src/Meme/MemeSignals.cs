namespace FundingRateScan.Meme;

/// <summary>Stato meco composito (tab. 57 del documento).</summary>
public enum MemeState
{
    RischioElevato,   // ✕  penalità di rischio dominante
    DaOsservare,      // ◇  pochi segnali o rischio non trascurabile
    Emergente,        // ◆  segnali positivi parziali
    AltoPotenziale    // ★  punteggio elevato su più dimensioni, rischio basso
}

/// <summary>Coin candidata alla valutazione meme (token on-chain + eventuale simbolo perp).</summary>
public sealed class MemeCandidate
{
    public string Chain { get; set; } = "";
    public string TokenAddress { get; set; } = "";
    public string Symbol { get; set; } = "";
    public string Name { get; set; } = "";
    public string Url { get; set; } = "";
    public double MarketCapUsd { get; set; }
    public double AgeDays { get; set; }
}

// --- Segnali (cap. 9). Null = dato non disponibile (incide sulla copertura). ---

public sealed class LiquiditySignal
{
    public double LiquidityUsd { get; set; }
    public double LiqToMcap { get; set; }
    public double Volume24hUsd { get; set; }
    public double TurnoverRatio { get; set; }
    public double? SpreadBps { get; set; }   // spread bid-ask CEX in punti base (null = nessun mercato CEX) — cap. 9.1
}

public sealed class HolderStats
{
    public long? HolderCount { get; set; }
    public double? Top10Pct { get; set; }
    public double? HolderGrowthPct { get; set; }   // se misurabile su due snapshot
}

public sealed class ParticipationSignal
{
    public double BuyRatio { get; set; }           // acquisti / (acquisti+vendite)
    public double Velocity { get; set; }           // proxy: turnover (volume/mcap)
    public double PriceChg6h { get; set; }
    public bool PriceWithoutParticipation { get; set; }  // divergenza prezzo↑ ma partecipazione bassa
}

public sealed class MarketMeta
{
    public int ExchangeCount { get; set; }
    public bool? CoinGeckoListed { get; set; }
    public double? CommunityScore { get; set; }
    public double? DeveloperScore { get; set; }
    public bool NewListing { get; set; }   // n. exchange aumentato dall'ultima rilevazione (cap. 9.5)
}

/// <summary>Dati sociali/di mercato da CoinGecko (cap. 9.6, fonte MarketMetaClient).</summary>
public sealed class SocialData
{
    public bool CoinGeckoListed { get; set; }
    public double? CommunityScore { get; set; }   // 0..100
    public double? DeveloperScore { get; set; }    // 0..100
    public int ExchangeCount { get; set; }
    public bool NewListing { get; set; }           // nuovo listing rilevato (catalizzatore, cap. 9.5)
}

public sealed class SurvivalSignal
{
    public double AgeDays { get; set; }
    public double? LpLockedPct { get; set; }
    public bool? IsHoneypot { get; set; }
    public bool? PossibleSpam { get; set; }
    public bool ContinuityOk { get; set; } = true;  // attività non interrotta
}

public sealed class DerivativesSignal
{
    public bool Available { get; set; }
    public double FundingApr { get; set; }
    public double PersistencePct { get; set; }
    public double OiGrowthPct { get; set; }
}

/// <summary>Punteggio composito a 4 dimensioni con penalità di rischio e copertura (cap. 8.4 / 9.9).</summary>
public sealed class MemeScore
{
    public MemeCandidate Candidate { get; set; } = null!;

    // Dimensioni 0..100 (null = nessun dato → esclusa dalla media)
    public double? Liquidity { get; set; }
    public double? Adoption { get; set; }
    public double? Derivatives { get; set; }
    public double? Social { get; set; }

    public double RiskPenalty { get; set; } = 1.0;   // 0..1, moltiplicativa
    public double Composite { get; set; }             // 0..100 finale
    public double CoveragePct { get; set; }           // % dimensioni con dati
    public bool SurvivalOk { get; set; } = true;      // filtro anti-rug (cap. 9.7)
    public MemeState State { get; set; } = MemeState.DaOsservare;

    public List<string> RiskNotes { get; } = new();
    public List<string> Rationale { get; } = new();

    public string StateSymbol => State switch
    {
        MemeState.AltoPotenziale => "★ Alto potenziale",
        MemeState.Emergente => "◆ Emergente",
        MemeState.DaOsservare => "◇ Da osservare",
        _ => "✕ Rischio elevato"
    };
}

/// <summary>Pesi e soglie del punteggio meme (configurabili, persistiti in settings.json).</summary>
public sealed class MemeScoringSettings
{
    public double WLiquidity { get; set; } = 30;
    public double WAdoption { get; set; } = 30;
    public double WDerivatives { get; set; } = 25;
    public double WSocial { get; set; } = 15;

    public double HighThreshold { get; set; } = 65;       // ★ Alto potenziale
    public double EmergingThreshold { get; set; } = 45;   // ◆ Emergente
    public double RiskExcludeBelow { get; set; } = 0.40;  // ✕ se penalità sotto questa
    public double MinAgeHoursSurvival { get; set; } = 3;  // sotto: non eleggibile ad alto potenziale (anti One-Day coin)
    public double MaxMarketCapUsd { get; set; } = 10_000_000;
    public int DeepTopN { get; set; } = 25;               // quante coin arricchire on-chain
}
