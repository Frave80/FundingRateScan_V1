using System.Text.Json;
using FundingRateScan.Services;
using FundingRateScan.OnChain.Alerts;
using FundingRateScan.OnChain.Models;
using FundingRateScan.OnChain.Providers;
using FundingRateScan.OnChain.Repositories;
using FundingRateScan.OnChain.Scoring;

namespace FundingRateScan.OnChain.Services;

/// <summary>
/// Job di sincronizzazione on-chain: recupera dati dal provider, normalizza e
/// classifica, calcola aggregati e scoring, genera e salva alert. Correla i
/// flussi con il funding rate del simbolo (riuso del modulo funding esistente).
/// </summary>
public sealed class OnChainMonitor
{
    private readonly IOnChainDataProvider _provider;
    private readonly IOnChainRepository _repo;
    private readonly FlowAggregator _aggregator = new();
    private readonly FlowSignalService _scoring = new();
    private readonly AlertService _alertService = new();

    public OnChainMonitor(OnChainSettings settings, IOnChainRepository? repo = null)
    {
        _provider = new EvmOnChainProvider(settings);
        _repo = repo ?? new OnChainStore();
    }

    public async Task<OnChainResult> RunAsync(TokenMonitorConfig cfg, IProgress<string> log, CancellationToken ct)
    {
        var result = new OnChainResult();
        var query = cfg.ToQuery();

        log.Report($"Recupero metadati token su {cfg.ChainKey}...");
        var token = await _provider.GetTokenMetadataAsync(query, ct) ?? new TokenMetadata { Address = cfg.TokenAddress };
        if (cfg.Symbol.Length == 0 && token.Symbol.Length > 0) cfg.Symbol = token.Symbol;
        result.Token = token;
        result.Market = new MarketSnapshot
        {
            PriceUsd = token.PriceUsd,
            PriceChange24h = token.PriceChange24hPct,
            LiquidityUsd = token.LiquidityUsd,
            Volume24hUsd = token.Volume24hUsd,
        };
        log.Report($"  {token.Symbol} — prezzo {token.PriceUsd:N6} USD, liquidità {token.LiquidityUsd:N0} USD");

        // Funding (correlazione col modulo esistente)
        result.Funding = await FetchFundingAsync(cfg.Symbol, ct);
        if (result.Funding.Available)
            log.Report($"  Funding {cfg.Symbol}: {result.Funding.Apr:N1}% APR");

        // Top holder
        log.Report("Recupero top holder...");
        var holders = (await _provider.GetTopHoldersAsync(query, cfg.TopHolders, ct)).ToList();
        var millionaires = holders.Where(h => h.ValueUsd >= cfg.MillionaireUsdThreshold).ToList();
        var classifier = new WalletClassifier(token, millionaires, cfg.WhaleUsdThreshold);
        foreach (var h in holders)
        {
            var (type, label) = classifier.Classify(h.Address);
            h.Type = type; h.Label = label;
        }
        result.Holders = holders;
        log.Report($"  {holders.Count} holder ({millionaires.Count} milionari ≥ {cfg.MillionaireUsdThreshold:N0} USD)");

        // Trasferimenti
        log.Report("Recupero trasferimenti...");
        var transfers = (await _provider.GetTokenTransfersAsync(query, ct)).ToList();
        foreach (var t in transfers)
        {
            classifier.Classify(t);
            t.FundingRateAtEvent = result.Funding.Rate8h;
        }
        result.Transfers = transfers;
        log.Report($"  {transfers.Count} trasferimenti ({transfers.Count(x => x.IsWhaleMovement)} whale)");

        // Aggregati per finestra
        var windows = _aggregator.Aggregate(transfers, cfg.Windows);
        var (newMill, top10Delta) = _aggregator.HolderDelta(holders, _repo.LoadLastHolders(cfg.ChainKey, cfg.TokenAddress), cfg.MillionaireUsdThreshold);
        foreach (var w in windows) { w.NewMillionaireWallets = newMill; w.Top10HolderShareChangePct = top10Delta; }
        result.Windows = windows;

        // Finestra primaria per scoring: 24h se presente, altrimenti la più ampia
        var primary = windows.FirstOrDefault(w => w.WindowMinutes == 1440)
                      ?? windows.OrderByDescending(w => w.WindowMinutes).FirstOrDefault()
                      ?? new FlowSnapshot();
        result.Flow = primary;

        // Scoring
        result.Signal = _scoring.Evaluate(primary, result.Funding, result.Market);
        log.Report($"Punteggio flusso: {result.Signal.Score} ({result.Signal.Bias})");

        // Alert
        var newAlerts = _alertService.Generate(transfers, primary, token, cfg);
        _repo.AppendAlerts(cfg.ChainKey, cfg.TokenAddress, newAlerts);
        result.Alerts = _repo.LoadAlerts(cfg.ChainKey, cfg.TokenAddress);
        log.Report($"Alert generati: {newAlerts.Count} (storico: {result.Alerts.Count})");

        // Persistenza snapshot
        _repo.SaveTransfers(cfg.ChainKey, cfg.TokenAddress, transfers);
        _repo.SaveHolders(cfg.ChainKey, cfg.TokenAddress, holders);

        return result;
    }

    /// <summary>Funding corrente del simbolo da Binance (best-effort, perpetuo USDT).</summary>
    private static async Task<FundingSnapshot> FetchFundingAsync(string symbol, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(symbol)) return new FundingSnapshot { Available = false };
        var b = symbol.ToUpperInvariant();
        // Le meme coin spesso quotano come 1000XXX / 1000000XXX sui perpetui.
        foreach (var sym in new[] { $"{b}USDT", $"1000{b}USDT", $"1000000{b}USDT" })
        {
            try
            {
                using var doc = await HttpHelper.GetJsonAsync(
                    $"https://fapi.binance.com/fapi/v1/premiumIndex?symbol={sym}", ct);
                if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Object) continue;
                if (!doc.RootElement.TryGetProperty("lastFundingRate", out _)) continue;

                double rate = HttpHelper.GetDouble(doc.RootElement, "lastFundingRate");
                decimal apr = (decimal)(rate * 3 * 365 * 100);
                return new FundingSnapshot { Rate8h = (decimal)rate, Apr = apr, Available = true };
            }
            catch { /* prova la variante successiva */ }
        }
        return new FundingSnapshot { Available = false };
    }
}
