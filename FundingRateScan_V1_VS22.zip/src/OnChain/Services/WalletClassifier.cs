using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Services;

/// <summary>
/// Classifica indirizzi (exchange, LP, contract, whale...) e normalizza ogni
/// trasferimento in un <see cref="OnChainEventType"/> con i relativi flag.
/// </summary>
public sealed class WalletClassifier
{
    private readonly string _tokenAddress;
    private readonly HashSet<string> _lpAddresses;
    private readonly HashSet<string> _millionaireWallets;
    private readonly decimal _whaleUsd;

    public WalletClassifier(TokenMetadata token, IEnumerable<HolderInfo> millionaireHolders, decimal whaleUsd)
    {
        _tokenAddress = token.Address.ToLowerInvariant();
        _lpAddresses = new HashSet<string>(token.PairAddresses, StringComparer.OrdinalIgnoreCase);
        _millionaireWallets = new HashSet<string>(
            millionaireHolders.Select(h => h.Address), StringComparer.OrdinalIgnoreCase);
        _whaleUsd = whaleUsd;
    }

    public (WalletType Type, string Label) Classify(string address)
    {
        var a = (address ?? "").ToLowerInvariant();
        if (a == KnownAddresses.ZeroAddress || a == KnownAddresses.DeadAddress)
            return (WalletType.Burn, "Mint/Burn");
        if (a == _tokenAddress)
            return (WalletType.Contract, "Token contract");
        if (_lpAddresses.Contains(a))
            return (WalletType.LiquidityPool, "Liquidity Pool");
        if (KnownAddresses.Map.TryGetValue(a, out var known))
            return known;
        if (_millionaireWallets.Contains(a))
            return (WalletType.KnownWhale, "Wallet milionario");
        return (WalletType.Unknown, "");
    }

    /// <summary>Etichetta e tipizza un trasferimento (modifica l'oggetto in place).</summary>
    public void Classify(TokenTransferEvent t)
    {
        var (fromType, fromLabel) = Classify(t.FromAddress);
        var (toType, toLabel) = Classify(t.ToAddress);
        t.FromType = fromType; t.FromLabel = fromLabel;
        t.ToType = toType; t.ToLabel = toLabel;

        t.IsExchangeRelated = fromType == WalletType.Exchange || toType == WalletType.Exchange;
        t.IsWhaleMovement = t.AmountUsd >= _whaleUsd;
        t.IsMillionaireWalletMove =
            _millionaireWallets.Contains(t.FromAddress) || _millionaireWallets.Contains(t.ToAddress);

        t.EventType = DetermineEventType(fromType, toType);
    }

    private static OnChainEventType DetermineEventType(WalletType from, WalletType to)
    {
        if (from == WalletType.Burn) return OnChainEventType.Mint;
        if (to == WalletType.Burn) return OnChainEventType.Burn;

        // Verso exchange = potenziale pressione di vendita; da exchange = potenziale accumulo
        if (to == WalletType.Exchange) return OnChainEventType.CexDeposit;
        if (from == WalletType.Exchange) return OnChainEventType.CexWithdrawal;

        // Token che entra nell'LP ~ vendita; token che esce dall'LP ~ acquisto
        if (to == WalletType.LiquidityPool) return OnChainEventType.SwapSell;
        if (from == WalletType.LiquidityPool) return OnChainEventType.SwapBuy;

        return OnChainEventType.Transfer;
    }
}
