using System.Text.Json;
using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Repositories;

public interface IOnChainRepository
{
    List<HolderInfo>? LoadLastHolders(string chain, string token);
    void SaveHolders(string chain, string token, IReadOnlyList<HolderInfo> holders);
    void SaveTransfers(string chain, string token, IReadOnlyList<TokenTransferEvent> transfers);
    void AppendAlerts(string chain, string token, IReadOnlyList<WhaleAlert> alerts);
    List<WhaleAlert> LoadAlerts(string chain, string token);
}

/// <summary>
/// Persistenza su file JSON in %APPDATA%\FundingRateScan\onchain\{chain}_{token}\.
/// Coerente con la persistenza già usata dall'app; sostituibile con SQLite
/// implementando la stessa interfaccia.
/// </summary>
public sealed class OnChainStore : IOnChainRepository
{
    private static readonly string Root =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "FundingRateScan", "onchain");

    private static readonly JsonSerializerOptions Json = new() { WriteIndented = false };

    private static string Dir(string chain, string token)
    {
        var safe = $"{chain}_{token}".Replace("/", "_").Replace("\\", "_");
        var d = Path.Combine(Root, safe);
        Directory.CreateDirectory(d);
        return d;
    }

    public List<HolderInfo>? LoadLastHolders(string chain, string token)
        => Load<List<HolderInfo>>(Path.Combine(Dir(chain, token), "holders.json"));

    public void SaveHolders(string chain, string token, IReadOnlyList<HolderInfo> holders)
        => Save(Path.Combine(Dir(chain, token), "holders.json"), holders);

    public void SaveTransfers(string chain, string token, IReadOnlyList<TokenTransferEvent> transfers)
        => Save(Path.Combine(Dir(chain, token), "transfers.json"), transfers);

    public void AppendAlerts(string chain, string token, IReadOnlyList<WhaleAlert> alerts)
    {
        if (alerts.Count == 0) return;
        var path = Path.Combine(Dir(chain, token), "alerts.json");
        var existing = Load<List<WhaleAlert>>(path) ?? new List<WhaleAlert>();

        // de-dup per (TxHash + Title); mantiene gli ultimi 1000
        var seen = new HashSet<string>(existing.Select(a => a.TxHash + "|" + a.Title));
        foreach (var a in alerts)
            if (seen.Add(a.TxHash + "|" + a.Title))
                existing.Add(a);

        var trimmed = existing.OrderByDescending(a => a.CreatedAtUtc).Take(1000).ToList();
        Save(path, trimmed);
    }

    public List<WhaleAlert> LoadAlerts(string chain, string token)
        => Load<List<WhaleAlert>>(Path.Combine(Dir(chain, token), "alerts.json")) ?? new List<WhaleAlert>();

    private static T? Load<T>(string path)
    {
        try { return File.Exists(path) ? JsonSerializer.Deserialize<T>(File.ReadAllText(path)) : default; }
        catch { return default; }
    }

    private static void Save<T>(string path, T value)
    {
        try { File.WriteAllText(path, JsonSerializer.Serialize(value, Json)); }
        catch { /* persistenza best-effort */ }
    }
}
