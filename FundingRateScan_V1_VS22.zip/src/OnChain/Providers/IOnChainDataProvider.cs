using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Providers;

/// <summary>
/// Adapter verso una fonte dati on-chain. Il dominio dipende solo da questa
/// interfaccia, così il provider (Etherscan/Moralis/Bitquery...) è sostituibile.
/// </summary>
public interface IOnChainDataProvider
{
    string Name { get; }

    Task<TokenMetadata?> GetTokenMetadataAsync(TokenQuery query, CancellationToken ct);
    Task<IReadOnlyList<HolderInfo>> GetTopHoldersAsync(TokenQuery query, int limit, CancellationToken ct);
    Task<IReadOnlyList<TokenTransferEvent>> GetTokenTransfersAsync(TokenQuery query, CancellationToken ct);
    Task<IReadOnlyList<TokenSwapEvent>> GetTokenSwapsAsync(TokenQuery query, CancellationToken ct);
}
