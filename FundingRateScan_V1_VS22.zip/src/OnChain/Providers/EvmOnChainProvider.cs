using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Providers;

/// <summary>
/// Provider on-chain EVM "first version": compone Etherscan (trasferimenti),
/// Ethplorer (token info + top holder, solo Ethereum) e DEX Screener
/// (prezzo, liquidità, pair LP). Resiliente: in caso di errore restituisce vuoto.
/// </summary>
public sealed class EvmOnChainProvider : IOnChainDataProvider
{
    public string Name => "EVM (Etherscan + Ethplorer + DEXScreener)";

    private readonly EtherscanClient _etherscan;
    private readonly EthplorerClient _ethplorer;
    private readonly DexScreenerClient _dex = new();

    private TokenMetadata? _metaCache;

    public EvmOnChainProvider(OnChainSettings settings)
    {
        _etherscan = new EtherscanClient(settings.EtherscanApiKey);
        _ethplorer = new EthplorerClient(settings.EthplorerApiKey);
    }

    public async Task<TokenMetadata?> GetTokenMetadataAsync(TokenQuery query, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(query.TokenAddress)) return null;

        var token = new TokenMetadata { Address = query.TokenAddress.ToLowerInvariant() };

        var chain = ChainCatalog.Get(query.ChainKey);
        if (chain.HoldersSupported)   // Ethplorer = solo Ethereum
        {
            try { await _ethplorer.EnrichTokenInfoAsync(token, ct); } catch { }
        }
        try { await _dex.EnrichMarketAsync(token, query.ChainKey, ct); } catch { }

        _metaCache = token;
        return token;
    }

    public async Task<IReadOnlyList<HolderInfo>> GetTopHoldersAsync(TokenQuery query, int limit, CancellationToken ct)
    {
        var chain = ChainCatalog.Get(query.ChainKey);
        if (!chain.HoldersSupported) return Array.Empty<HolderInfo>();

        var token = (_metaCache != null && _metaCache.Address == query.TokenAddress.ToLowerInvariant())
            ? _metaCache
            : await GetTokenMetadataAsync(query, ct) ?? new TokenMetadata { Address = query.TokenAddress };

        try { return await _ethplorer.GetTopHoldersAsync(token, limit, ct); }
        catch { return Array.Empty<HolderInfo>(); }
    }

    public async Task<IReadOnlyList<TokenTransferEvent>> GetTokenTransfersAsync(TokenQuery query, CancellationToken ct)
    {
        List<TokenTransferEvent> transfers;
        try { transfers = await _etherscan.GetTransfersAsync(query, ct); }
        catch { return Array.Empty<TokenTransferEvent>(); }

        // Applica il prezzo USD corrente (stima dimensione economica del movimento)
        decimal price = _metaCache?.PriceUsd ?? 0m;
        if (price > 0)
            foreach (var t in transfers)
            {
                t.AmountUsd = t.TokenAmount * price;
                t.PriceAtEvent = price;
            }
        return transfers;
    }

    public Task<IReadOnlyList<TokenSwapEvent>> GetTokenSwapsAsync(TokenQuery query, CancellationToken ct)
    {
        // v1: gli swap vengono dedotti dai trasferimenti che coinvolgono i pair LP
        // (vedi WalletClassifier). Un provider dedicato (Moralis/Bitquery) potrà
        // popolare questo metodo in futuro.
        return Task.FromResult<IReadOnlyList<TokenSwapEvent>>(Array.Empty<TokenSwapEvent>());
    }
}
