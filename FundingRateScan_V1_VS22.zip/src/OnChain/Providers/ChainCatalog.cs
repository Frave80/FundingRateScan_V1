using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Providers;

/// <summary>Chain EVM supportate (id per Etherscan V2 multichain).</summary>
public static class ChainCatalog
{
    public static readonly IReadOnlyList<ChainInfo> Chains = new[]
    {
        new ChainInfo { Key = "ethereum", Display = "Ethereum",  ChainId = 1,     HoldersSupported = true  },
        new ChainInfo { Key = "bsc",      Display = "BNB Chain", ChainId = 56,    HoldersSupported = false },
        new ChainInfo { Key = "polygon",  Display = "Polygon",   ChainId = 137,   HoldersSupported = false },
        new ChainInfo { Key = "arbitrum", Display = "Arbitrum",  ChainId = 42161, HoldersSupported = false },
        new ChainInfo { Key = "base",     Display = "Base",      ChainId = 8453,  HoldersSupported = false },
        new ChainInfo { Key = "optimism", Display = "Optimism",  ChainId = 10,    HoldersSupported = false },
    };

    public static ChainInfo Get(string key)
        => Chains.FirstOrDefault(c => c.Key.Equals(key, StringComparison.OrdinalIgnoreCase)) ?? Chains[0];
}
