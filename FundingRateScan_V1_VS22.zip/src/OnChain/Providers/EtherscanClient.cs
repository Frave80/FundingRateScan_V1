using System.Globalization;
using System.Numerics;
using System.Text.Json;
using FundingRateScan.Services;
using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Providers;

/// <summary>
/// Etherscan V2 (multichain): trasferimenti ERC-20 di un token.
/// Richiede una API key gratuita (parametro configurabile).
/// </summary>
public sealed class EtherscanClient
{
    private const string Base = "https://api.etherscan.io/v2/api";
    private readonly string _apiKey;

    public EtherscanClient(string apiKey) => _apiKey = apiKey;

    public async Task<List<TokenTransferEvent>> GetTransfersAsync(TokenQuery q, CancellationToken ct)
    {
        var result = new List<TokenTransferEvent>();
        if (string.IsNullOrWhiteSpace(q.TokenAddress)) return result;

        int offset = Math.Clamp(q.MaxResults, 10, 1000);
        var url = $"{Base}?chainid={q.ChainId}&module=account&action=tokentx" +
                  $"&contractaddress={q.TokenAddress}&page=1&offset={offset}&sort=desc" +
                  $"&apikey={Uri.EscapeDataString(_apiKey)}";

        using var doc = await HttpHelper.GetJsonAsync(url, ct);
        if (doc == null) return result;
        if (!doc.RootElement.TryGetProperty("result", out var arr) || arr.ValueKind != JsonValueKind.Array)
            return result;

        foreach (var e in arr.EnumerateArray())
        {
            int decimals = (int)HttpHelper.ParseDouble(GetProp(e, "tokenDecimal"));
            decimal amount = RawToDecimal(HttpHelper.GetString(e, "value"), decimals);
            long ts = HttpHelper.GetLong(e, "timeStamp");

            result.Add(new TokenTransferEvent
            {
                TxHash = HttpHelper.GetString(e, "hash"),
                BlockNumber = HttpHelper.GetLong(e, "blockNumber"),
                ChainId = q.ChainId.ToString(),
                TokenAddress = q.TokenAddress.ToLowerInvariant(),
                FromAddress = HttpHelper.GetString(e, "from").ToLowerInvariant(),
                ToAddress = HttpHelper.GetString(e, "to").ToLowerInvariant(),
                TokenAmount = amount,
                TimestampUtc = DateTimeOffset.FromUnixTimeSeconds(ts),
            });
        }
        return result;
    }

    private static JsonElement GetProp(JsonElement el, string name)
        => el.TryGetProperty(name, out var v) ? v : default;

    /// <summary>Converte un valore intero grezzo (stringa) in decimale applicando i decimali del token.</summary>
    public static decimal RawToDecimal(string raw, int decimals)
    {
        if (string.IsNullOrEmpty(raw) || !BigInteger.TryParse(raw, NumberStyles.Integer,
                CultureInfo.InvariantCulture, out var bi))
            return 0m;
        if (decimals < 0 || decimals > 30) decimals = 18;

        var divisor = BigInteger.Pow(10, decimals);
        var whole = bi / divisor;
        var frac = bi - whole * divisor;

        try
        {
            decimal w = (decimal)whole;
            decimal f = (decimal)frac / (decimal)divisor;
            return w + f;
        }
        catch (OverflowException)
        {
            // valori enormi: ripiega su double
            return (decimal)Math.Min((double)decimal.MaxValue, (double)bi / Math.Pow(10, decimals));
        }
    }
}
