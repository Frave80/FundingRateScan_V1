using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Scoring;

/// <summary>
/// Calcola un punteggio operativo leggibile e motivato combinando flussi on-chain,
/// funding rate e contesto di mercato. NON dà segnali "compra/vendi" automatici:
/// ogni contributo al punteggio è spiegato nelle Reasons.
/// </summary>
public sealed class FlowSignalService
{
    public FlowSignal Evaluate(FlowSnapshot flow, FundingSnapshot funding, MarketSnapshot market)
    {
        int score = 0;
        var reasons = new List<string>();

        void Add(int pts, string why) { score += pts; reasons.Add($"{(pts >= 0 ? "+" : "")}{pts}  {why}"); }

        if (flow.NetWhaleBuyUsd > 1_000_000m)
            Add(20, $"Acquisti netti whale elevati ({flow.NetWhaleBuyUsd:N0} USD)");
        else if (flow.NetWhaleBuyUsd > 0)
            Add(8, $"Acquisti netti whale positivi ({flow.NetWhaleBuyUsd:N0} USD)");

        if (flow.CexOutUsd > flow.CexInUsd)
            Add(10, $"Deflusso netto dagli exchange ({flow.CexOutUsd - flow.CexInUsd:N0} USD): possibile accumulo");
        else if (flow.CexInUsd > flow.CexOutUsd)
            Add(-8, $"Afflusso netto verso exchange ({flow.CexInUsd - flow.CexOutUsd:N0} USD): possibile pressione di vendita");

        if (flow.NewMillionaireWallets >= 3)
            Add(15, $"{flow.NewMillionaireWallets} nuovi wallet milionari");
        else if (flow.NewMillionaireWallets > 0)
            Add(5, $"{flow.NewMillionaireWallets} nuovo/i wallet milionario/i");

        if (market.PriceChange24h <= 0 && flow.NetWhaleBuyUsd > 0)
            Add(8, "Acquisti whale con prezzo fermo/in calo: accumulo silenzioso");

        if (funding.Available && funding.Apr > 50m)
            Add(-10, $"Funding già molto alto ({funding.Apr:N0}% APR): rischio long affollati");
        else if (funding.Available && funding.Apr > 0 && flow.NetWhaleBuyUsd > 0)
            Add(6, $"Funding positivo moderato ({funding.Apr:N0}% APR) coerente con acquisti");

        if (flow.Top10HolderShareChangePct > 2)
            Add(-12, $"Concentrazione top 10 in aumento (+{flow.Top10HolderShareChangePct:N1} pp): maggiore fragilità");
        else if (flow.Top10HolderShareChangePct < -2)
            Add(6, $"Concentrazione top 10 in calo ({flow.Top10HolderShareChangePct:N1} pp): distribuzione più ampia");

        string bias = score switch
        {
            >= 25 => "Accumulo forte",
            >= 10 => "Accumulo moderato",
            <= -10 => "Rischio distribuzione",
            _ => "Neutro / ambiguo"
        };

        if (reasons.Count == 0) reasons.Add("Nessun segnale rilevante nei dati disponibili.");
        return new FlowSignal { Score = score, Bias = bias, Reasons = reasons };
    }
}
