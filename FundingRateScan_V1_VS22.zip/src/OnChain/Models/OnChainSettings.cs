namespace FundingRateScan.OnChain.Models;

/// <summary>
/// Impostazioni del modulo on-chain (persistite con le altre in settings.json).
/// Le soglie sono parametri, non valori fissi.
/// </summary>
public sealed class OnChainSettings
{
    public bool Enabled { get; set; } = true;
    public string DefaultChain { get; set; } = "ethereum";

    public decimal WhaleUsdThreshold { get; set; } = 250_000m;
    public decimal MillionaireWalletUsdThreshold { get; set; } = 1_000_000m;
    public int AlertMinScore { get; set; } = 15;
    public int MaxTransfers { get; set; } = 300;
    public int TopHolders { get; set; } = 50;

    /// <summary>Finestre di aggregazione in minuti (5m, 1h, 4h, 24h, 7d).</summary>
    public List<int> TrackWindowsMinutes { get; set; } = new() { 5, 60, 240, 1440, 10080 };

    // Chiavi API dei provider (gestite fuori dal codice sorgente, salvate dall'utente)
    public string EtherscanApiKey { get; set; } = "";
    public string EthplorerApiKey { get; set; } = "freekey";
    public string MoralisApiKey { get; set; } = "";
    public string BitqueryApiKey { get; set; } = "";

    /// <summary>Ultimo token monitorato (per ripristinare la finestra).</summary>
    public string LastTokenAddress { get; set; } = "";
    public string LastSymbol { get; set; } = "";
}

/// <summary>Configurazione di un monitoraggio (coin + chain + soglie).</summary>
public sealed class TokenMonitorConfig
{
    public string ChainKey { get; set; } = "ethereum";
    public int ChainId { get; set; } = 1;
    public string TokenAddress { get; set; } = "";
    public string Symbol { get; set; } = "";

    public decimal WhaleUsdThreshold { get; set; } = 250_000m;
    public decimal MillionaireUsdThreshold { get; set; } = 1_000_000m;
    public int MaxTransfers { get; set; } = 300;
    public int TopHolders { get; set; } = 50;
    public int AlertMinScore { get; set; } = 15;
    public List<int> Windows { get; set; } = new() { 5, 60, 240, 1440, 10080 };

    public TokenQuery ToQuery() => new()
    {
        ChainKey = ChainKey,
        ChainId = ChainId,
        TokenAddress = TokenAddress,
        MaxResults = MaxTransfers,
    };
}
