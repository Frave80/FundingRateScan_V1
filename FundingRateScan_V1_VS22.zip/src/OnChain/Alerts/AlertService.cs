using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Alerts;

/// <summary>Genera alert leggibili e con severità a partire da movimenti, flussi e delta holder.</summary>
public sealed class AlertService
{
    public List<WhaleAlert> Generate(
        IReadOnlyList<TokenTransferEvent> transfers,
        FlowSnapshot flow,
        TokenMetadata token,
        TokenMonitorConfig cfg)
    {
        var alerts = new List<WhaleAlert>();
        string sym = token.Symbol.Length > 0 ? token.Symbol : "TOKEN";

        // 1) Grandi movimenti singoli
        foreach (var t in transfers.Where(x => x.IsWhaleMovement).OrderByDescending(x => x.AmountUsd))
        {
            double ratio = cfg.WhaleUsdThreshold > 0 ? (double)(t.AmountUsd / cfg.WhaleUsdThreshold) : 1;
            int score = Math.Min(100, (int)(15 * ratio));
            var sev = ratio >= 20 ? AlertSeverity.Critical
                    : ratio >= 4 ? AlertSeverity.High
                    : AlertSeverity.Medium;

            string dir = t.EventType switch
            {
                OnChainEventType.CexDeposit => $"verso exchange {t.ToLabel} (possibile vendita)",
                OnChainEventType.CexWithdrawal => $"da exchange {t.FromLabel} (possibile accumulo)",
                OnChainEventType.SwapBuy => "acquisto su DEX",
                OnChainEventType.SwapSell => "vendita su DEX",
                _ => $"trasferimento {Short(t.FromAddress)} → {Short(t.ToAddress)}"
            };

            alerts.Add(new WhaleAlert
            {
                Title = $"Movimento whale {sym}: {t.AmountUsd:N0} USD",
                Description = $"{t.TokenAmount:N2} {sym} ({t.AmountUsd:N0} USD) {dir}.",
                Score = score,
                Severity = sev,
                TxHash = t.TxHash,
                AmountUsd = t.AmountUsd,
                CreatedAtUtc = t.TimestampUtc,
            });
        }

        // 2) Squilibrio flusso exchange (finestra)
        decimal cexImbalance = flow.CexOutUsd - flow.CexInUsd;
        if (Math.Abs(cexImbalance) >= cfg.WhaleUsdThreshold)
        {
            bool accumulo = cexImbalance > 0;
            alerts.Add(new WhaleAlert
            {
                Title = accumulo ? $"Deflusso netto dagli exchange ({sym})" : $"Afflusso netto verso exchange ({sym})",
                Description = $"Saldo flusso exchange: {cexImbalance:N0} USD nella finestra {flow.WindowMinutes} min. " +
                              (accumulo ? "Possibile accumulo." : "Possibile pressione di vendita."),
                Score = Math.Min(100, (int)(10 * (double)(Math.Abs(cexImbalance) / Math.Max(1, cfg.WhaleUsdThreshold)))),
                Severity = accumulo ? AlertSeverity.Medium : AlertSeverity.High,
                AmountUsd = Math.Abs(cexImbalance),
            });
        }

        // 3) Nuovi wallet milionari
        if (flow.NewMillionaireWallets > 0)
            alerts.Add(new WhaleAlert
            {
                Title = $"{flow.NewMillionaireWallets} nuovo/i wallet milionario/i ({sym})",
                Description = $"Rilevati {flow.NewMillionaireWallets} wallet con valore ≥ {cfg.MillionaireUsdThreshold:N0} USD rispetto allo snapshot precedente.",
                Score = 15 + flow.NewMillionaireWallets * 5,
                Severity = flow.NewMillionaireWallets >= 3 ? AlertSeverity.High : AlertSeverity.Medium,
            });

        // 4) Aumento concentrazione top 10
        if (flow.Top10HolderShareChangePct > 2)
            alerts.Add(new WhaleAlert
            {
                Title = $"Concentrazione top 10 in aumento ({sym})",
                Description = $"La quota dei primi 10 holder è cresciuta di {flow.Top10HolderShareChangePct:N1} punti %: maggiore fragilità del prezzo.",
                Score = 12 + (int)flow.Top10HolderShareChangePct,
                Severity = AlertSeverity.Medium,
            });

        return alerts
            .Where(a => a.Score >= cfg.AlertMinScore)
            .OrderByDescending(a => a.Severity)
            .ThenByDescending(a => a.Score)
            .ToList();
    }

    private static string Short(string addr)
        => addr.Length >= 10 ? $"{addr[..6]}…{addr[^4..]}" : addr;
}
