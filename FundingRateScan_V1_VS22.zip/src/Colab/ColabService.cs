namespace FundingRateScan.Colab;

/// <summary>
/// Replica fedele della pipeline di FundingRateHeatmap_v8.py:
/// CoinGecko top N → fetch storico funding (OKX/HL/Bitget/HTX/Gate) → DataFrame
/// giornaliero (con fallback 365→180→90) → analisi/classificazione.
/// </summary>
public sealed class ColabService
{
    private readonly int _topN;
    private readonly int[] _fallbackDays;

    public ColabService(int topN = ColabConfig.TopNCoins, int[]? fallbackDays = null)
    {
        _topN = topN;
        _fallbackDays = fallbackDays ?? new[] { ColabConfig.LookbackDays }.Concat(ColabConfig.FallbackDays).ToArray();
    }

    public async Task<ColabResult> RunAsync(IProgress<string> log, CancellationToken ct)
    {
        // 1) Lista coin
        var coins = await ColabCoinGecko.FetchAsync(_topN, log, ct);
        if (coins.Count == 0)
        {
            log.Report("Nessuna coin da CoinGecko (rate limit / rete).");
            return new ColabResult();
        }
        var info = coins.GroupBy(c => c.Symbol).ToDictionary(g => g.Key, g => g.First());
        var symbolsRanked = coins.OrderBy(c => c.Rank).Select(c => c.Symbol).Distinct().ToList();

        // 2) Init fetcher (una volta sola)
        log.Report("Init exchange fetcher (OKX · Hyperliquid · Bitget · HTX · Gate.io)...");
        var fetchers = new ColabFetcherSet();
        await fetchers.InitAsync(log, ct);

        // 3) Fallback automatico 365 → 180 → 90
        FundingFrame frame = new();
        int actualDays = _fallbackDays[0];
        foreach (var days in _fallbackDays)
        {
            actualDays = days;
            var (start, end) = TsRange(days);
            log.Report($"Provo {days} giorni ({DateTimeOffset.FromUnixTimeMilliseconds(start).UtcDateTime:yyyy-MM-dd} → {DateTimeOffset.FromUnixTimeMilliseconds(end).UtcDateTime:yyyy-MM-dd})...");
            frame = await BuildFrameAsync(symbolsRanked, fetchers, start, end, log, ct);
            if (frame.ValidCoins > 0)
            {
                log.Report($"  Dati trovati con {days} giorni ({frame.ValidCoins} coin)");
                break;
            }
            log.Report("  0 dati — provo intervallo minore");
        }

        // 4) Analisi
        var analysis = Analyze(frame, info, actualDays);

        // 5) Riepilogo
        var allVals = frame.Rows.Values.SelectMany(r => r).Where(v => v.HasValue).Select(v => v!.Value).ToList();
        var result = new ColabResult
        {
            Frame = frame,
            Analysis = analysis,
            ActualDays = actualDays,
            CoinsLoaded = frame.ValidCoins,
            AprMean = allVals.Count > 0 ? allVals.Average() : 0,
            AprMedian = Median(allVals),
            SourceCounts = frame.Sources.Values.Where(s => s != "none")
                .GroupBy(s => s).ToDictionary(g => g.Key, g => g.Count()),
        };
        log.Report($"Completato: {result.CoinsLoaded} coin con dati, periodo {actualDays}gg, APR medio {result.AprMean:N1}% / mediana {result.AprMedian:N1}%.");
        return result;
    }

    // -------------------------------------------------- Build DataFrame
    private async Task<FundingFrame> BuildFrameAsync(
        List<string> symbols, ColabFetcherSet fetchers, long startMs, long endMs,
        IProgress<string> log, CancellationToken ct)
    {
        var frame = new FundingFrame();
        // indice date giornaliero (estremi inclusi, come pd.date_range)
        var startDate = DateTimeOffset.FromUnixTimeMilliseconds(startMs).UtcDateTime.Date;
        var endDate = DateTimeOffset.FromUnixTimeMilliseconds(endMs).UtcDateTime.Date;
        for (var d = startDate; d <= endDate; d = d.AddDays(1)) frame.Dates.Add(d);
        var dateIndex = frame.Dates.Select((d, i) => (d, i)).ToDictionary(x => x.d, x => x.i);
        int nDates = frame.Dates.Count;

        int done = 0, ok = 0;
        using var sem = new SemaphoreSlim(8);
        var gate = new object();

        var tasks = symbols.Select(async sym =>
        {
            await sem.WaitAsync(ct);
            try
            {
                var (series, src) = await fetchers.FetchOneAsync(sym, startMs, endMs, ct);
                var row = new double?[nDates];   // NaN di default

                if (series.Count > 0)
                {
                    // resample giornaliero: media per data
                    var daily = series.GroupBy(p => p.Ts.Date)
                                      .ToDictionary(g => g.Key, g => g.Average(p => p.Val));
                    foreach (var kv in daily)
                        if (dateIndex.TryGetValue(kv.Key, out var idx))
                            row[idx] = kv.Value;
                }

                lock (gate)
                {
                    frame.Rows[sym] = row;
                    frame.Sources[sym] = series.Count > 0 ? src : "none";
                    if (series.Count > 0) ok++;
                    done++;
                    if (done % 25 == 0 || done == symbols.Count)
                        log.Report($"  Download {done}/{symbols.Count} ({ok} con dati)...");
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
            catch
            {
                lock (gate) { frame.Rows[sym] = new double?[nDates]; frame.Sources[sym] = "error"; done++; }
            }
            finally { sem.Release(); }
        });
        await Task.WhenAll(tasks);
        return frame;
    }

    // -------------------------------------------------- Analyze
    private static List<ColabAnalysisRow> Analyze(FundingFrame frame, Dictionary<string, ColabCoin> info, int daysTotal)
    {
        var rows = new List<ColabAnalysisRow>();
        if (frame.Dates.Count == 0) return rows;

        int days90 = Math.Min(90, daysTotal);
        int days30 = Math.Min(30, daysTotal);
        var now = frame.Dates[^1];                 // ultima data = oggi (mezzanotte UTC)
        var cut90 = now.AddDays(-days90);
        var cut30 = now.AddDays(-days30);

        foreach (var sym in frame.Rows.Keys)
        {
            var vals = frame.Rows[sym];
            // serie (data, valore) senza NaN
            var full = new List<(DateTime d, double v)>();
            for (int i = 0; i < vals.Length; i++)
                if (vals[i].HasValue) full.Add((frame.Dates[i], vals[i]!.Value));
            if (full.Count < ColabConfig.MinDataDays) continue;

            var s90 = full.Where(x => x.d >= cut90).Select(x => x.v).ToList();
            var s30 = full.Where(x => x.d >= cut30).Select(x => x.v).ToList();

            double avgAll = full.Average(x => x.v);
            double avg90 = s90.Count > 0 ? s90.Average() : avgAll;
            double avg30 = s30.Count > 0 ? s30.Average() : avgAll;
            double peak = full.Max(x => x.v);
            double std = SampleStd(full.Select(x => x.v).ToList());

            var ci = info.TryGetValue(sym, out var c) ? c : new ColabCoin { Symbol = sym, Name = sym };
            double change1y = ci.Change1y ?? 0;
            double change30d = ci.Change30d ?? 0;

            bool highFull = avgAll >= ColabConfig.HighAprThresh;
            bool highRecent = avg30 >= ColabConfig.HighAprRecent;
            bool priceReacted = Math.Abs(change30d) > ColabConfig.PriceReactionPct;

            string status;
            if (highRecent && !priceReacted) status = "OPPORTUNITÀ";
            else if (highFull && change1y > ColabConfig.PriceReactionPct * 5) status = "ESPLOSA";
            else if (highFull && change1y > ColabConfig.PriceReactionPct) status = "POMPATA";
            else if (highFull && change1y < -20) status = "DELUSA";
            else if (highRecent) status = "WATCH";
            else if (highFull) status = "STABILE";
            else continue;

            string name = (ci.Name.Length > 0 ? ci.Name : sym);
            if (name.Length > 18) name = name[..18];

            rows.Add(new ColabAnalysisRow
            {
                Symbol = sym,
                Name = name,
                Status = status,
                AprMedio = Round1(avgAll),
                Apr90 = Round1(avg90),
                Apr30 = Round1(avg30),
                AprPicco = Round1(peak),
                Volatilita = Round1(std),
                Pr1a = ci.Change1y.HasValue ? Round1(ci.Change1y.Value) : null,
                Pr30 = ci.Change30d.HasValue ? Round1(ci.Change30d.Value) : null,
                Pr7 = ci.Change7d.HasValue ? Round1(ci.Change7d.Value) : null,
                Prezzo = ci.PriceUsd,
            });
        }

        // sort_values(['status','apr_30gg'], ascending=[True, False])
        return rows.OrderBy(r => r.Status, StringComparer.Ordinal)
                   .ThenByDescending(r => r.Apr30)
                   .ToList();
    }

    // -------------------------------------------------- Helper
    private static (long start, long end) TsRange(int days)
    {
        var end = DateTime.UtcNow.Date;                 // oggi mezzanotte UTC
        var start = end.AddDays(-days);
        long endMs = new DateTimeOffset(end, TimeSpan.Zero).ToUnixTimeMilliseconds();
        long startMs = new DateTimeOffset(start, TimeSpan.Zero).ToUnixTimeMilliseconds();
        return (startMs, endMs);
    }

    private static double Round1(double v) => Math.Round(v, 1, MidpointRounding.AwayFromZero);

    private static double Median(List<double> v)
    {
        if (v.Count == 0) return 0;
        var s = v.OrderBy(x => x).ToList();
        int m = s.Count / 2;
        return s.Count % 2 == 1 ? s[m] : (s[m - 1] + s[m]) / 2.0;
    }

    private static double SampleStd(List<double> v)
    {
        if (v.Count < 2) return 0;
        double mean = v.Average();
        double sum = v.Sum(x => (x - mean) * (x - mean));
        return Math.Sqrt(sum / (v.Count - 1));   // ddof=1, come pandas
    }
}
