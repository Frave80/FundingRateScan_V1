using System.Text.Json;
using FundingRateScan.Services;

namespace FundingRateScan.Colab;

/// <summary>Punto della serie (timestamp UTC + valore).</summary>
public readonly record struct SeriesPoint(DateTime Ts, double Val);

/// <summary>
/// Replica fedele dei fetcher Python (OKX, Hyperliquid, Bitget, HTX, Gate.io):
/// scarica lo storico funding e lo converte in APR con la stessa logica di to_apr,
/// poi unisce le fonti come _fetch_one (concat + media per timestamp).
/// </summary>
public sealed class ColabFetcherSet
{
    private Dictionary<string, string> _okxMap = new();      // BASE -> instId
    private HashSet<string> _hlCoins = new();
    private Dictionary<string, string> _gateMap = new();     // BASE -> contract
    private bool _gateDirect;

    public async Task InitAsync(IProgress<string> log, CancellationToken ct)
    {
        await InitOkx(log, ct);
        await InitHyperliquid(log, ct);
        await InitGate(log, ct);
    }

    // ---------------------------------------------------------------- Init
    private async Task InitOkx(IProgress<string> log, CancellationToken ct)
    {
        using var doc = await HttpHelper.GetJsonAsync(
            "https://www.okx.com/api/v5/public/instruments?instType=SWAP", ct);
        if (doc != null && doc.RootElement.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array)
            foreach (var it in data.EnumerateArray())
            {
                var inst = HttpHelper.GetString(it, "instId");
                if (inst.EndsWith("-USDT-SWAP") && HttpHelper.GetString(it, "state") == "live")
                    _okxMap[inst.Split('-')[0]] = inst;
            }
        log.Report($"  [OKX] {_okxMap.Count} swap USDT");
    }

    private async Task InitHyperliquid(IProgress<string> log, CancellationToken ct)
    {
        using var doc = await HttpHelper.PostJsonAsync("https://api.hyperliquid.xyz/info", "{\"type\":\"meta\"}", ct);
        if (doc != null && doc.RootElement.TryGetProperty("universe", out var u) && u.ValueKind == JsonValueKind.Array)
            foreach (var it in u.EnumerateArray())
                _hlCoins.Add(HttpHelper.GetString(it, "name"));
        log.Report($"  [Hyperliquid] {_hlCoins.Count} perp");
    }

    private async Task InitGate(IProgress<string> log, CancellationToken ct)
    {
        foreach (var limit in new[] { 100, 50 })
        {
            var map = new Dictionary<string, string>();
            int off = 0;
            for (int i = 0; i < 20; i++)
            {
                using var doc = await HttpHelper.GetJsonAsync(
                    $"https://api.gateio.ws/api/v4/futures/usdt/contracts?limit={limit}&offset={off}", ct);
                if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) break;
                int n = 0;
                foreach (var it in doc.RootElement.EnumerateArray())
                {
                    n++;
                    var name = HttpHelper.GetString(it, "name");
                    if (name.Contains("_USDT")) map[name.Replace("_USDT", "")] = name;
                }
                if (n < limit) break;
                off += limit;
                await Task.Delay(300, ct);
            }
            if (map.Count > 0) { _gateMap = map; break; }
        }
        _gateDirect = _gateMap.Count == 0;
        log.Report($"  [Gate.io] {_gateMap.Count} contratti{(_gateDirect ? " (direct)" : "")}");
    }

    // ---------------------------------------------------------- FetchOne
    public async Task<(List<SeriesPoint> series, string src)> FetchOneAsync(
        string sym, long startMs, long endMs, CancellationToken ct)
    {
        var parts = new List<List<SeriesPoint>>();
        var srcs = new List<string>();

        async Task TryAdd(Func<Task<List<SeriesPoint>>> fetch, double interval, string name)
        {
            try
            {
                var raw = await fetch();
                if (raw.Count > 0) { parts.Add(ToApr(raw, interval)); srcs.Add(name); }
            }
            catch { /* fonte saltata */ }
        }

        await TryAdd(() => FetchOkx(sym, startMs, endMs, ct), ColabConfig.IntervalOkx, "OKX");
        await TryAdd(() => FetchHyperliquid(sym, startMs, endMs, ct), ColabConfig.IntervalHyperliquid, "HL");
        await TryAdd(() => FetchBitget(sym, startMs, endMs, ct), ColabConfig.IntervalBitget, "Bitget");
        await TryAdd(() => FetchHtx(sym, startMs, endMs, ct), ColabConfig.IntervalHtx, "HTX");

        if (parts.Count == 0)
            await TryAdd(() => FetchGate(sym, startMs, endMs, ct), ColabConfig.IntervalGate, "Gate");

        if (parts.Count == 0) return (new List<SeriesPoint>(), "none");
        if (parts.Count == 1) return (parts[0], srcs[0]);

        // Merge come concat(parts).groupby(timestamp).mean()
        var acc = new Dictionary<DateTime, (double sum, int n)>();
        foreach (var p in parts)
            foreach (var pt in p)
            {
                var cur = acc.TryGetValue(pt.Ts, out var e) ? e : (0.0, 0);
                acc[pt.Ts] = (cur.Item1 + pt.Val, cur.Item2 + 1);
            }
        var merged = acc.Select(kv => new SeriesPoint(kv.Key, kv.Value.sum / kv.Value.n))
                        .OrderBy(p => p.Ts).ToList();
        return (merged, string.Join("+", srcs));
    }

    // ------------------------------------------------------- to_apr
    private static List<SeriesPoint> ToApr(List<SeriesPoint> raw, double defaultH)
    {
        if (raw.Count == 0) return raw;
        raw.Sort((a, b) => a.Ts.CompareTo(b.Ts));

        double ih = defaultH;
        if (raw.Count >= 2)
        {
            var diffs = new List<double>();
            for (int i = 1; i < raw.Count; i++)
                diffs.Add((raw[i].Ts - raw[i - 1].Ts).TotalHours);
            double m = Median(diffs);
            if (m > 0.1 && m < 24) ih = m;
        }
        double factor = (24.0 / ih) * 365.0 * 100.0;
        return raw.Select(p => new SeriesPoint(p.Ts, p.Val * factor)).ToList();
    }

    private static double Median(List<double> v)
    {
        if (v.Count == 0) return 0;
        var s = v.OrderBy(x => x).ToList();
        int m = s.Count / 2;
        return s.Count % 2 == 1 ? s[m] : (s[m - 1] + s[m]) / 2.0;
    }

    private static DateTime FromMs(long ms) => DateTimeOffset.FromUnixTimeMilliseconds(ms).UtcDateTime;

    // ------------------------------------------------------- Fetchers
    private async Task<List<SeriesPoint>> FetchOkx(string sym, long startMs, long endMs, CancellationToken ct)
    {
        var rec = new List<SeriesPoint>();
        if (!_okxMap.TryGetValue(sym, out var inst)) return rec;
        string? cursor = null;

        for (int i = 0; i < 60; i++)
        {
            var url = $"https://www.okx.com/api/v5/public/funding-rate-history?instId={inst}&limit=100";
            if (cursor != null) url += $"&after={cursor}";
            using var doc = await HttpHelper.GetJsonAsync(url, ct);
            if (doc == null || HttpHelper.GetString(doc.RootElement, "code") != "0") break;
            if (!doc.RootElement.TryGetProperty("data", out var items) || items.ValueKind != JsonValueKind.Array) break;
            if (items.GetArrayLength() == 0) break;

            long oldest = long.MaxValue; int n = 0;
            foreach (var it in items.EnumerateArray())
            {
                long t = HttpHelper.GetLong(it, "fundingTime");
                if (t < oldest) oldest = t;
                n++;
                if (t >= startMs && t <= endMs)
                    rec.Add(new SeriesPoint(FromMs(t), HttpHelper.GetDouble(it, "fundingRate")));
            }
            if (oldest < startMs || n < 100) break;
            cursor = oldest.ToString();
        }
        return rec;
    }

    private async Task<List<SeriesPoint>> FetchHyperliquid(string sym, long startMs, long endMs, CancellationToken ct)
    {
        var rec = new List<SeriesPoint>();
        if (!_hlCoins.Contains(sym)) return rec;
        long cur = startMs;

        for (int i = 0; i < 100; i++)
        {
            var body = $"{{\"type\":\"fundingHistory\",\"coin\":\"{sym}\",\"startTime\":{cur}}}";
            using var doc = await HttpHelper.PostJsonAsync("https://api.hyperliquid.xyz/info", body, ct);
            if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) break;
            int batch = doc.RootElement.GetArrayLength();
            if (batch == 0) break;

            int inRange = 0; long last = cur;
            foreach (var it in doc.RootElement.EnumerateArray())
            {
                long t = HttpHelper.GetLong(it, "time");
                last = t;
                if (t <= endMs)
                {
                    rec.Add(new SeriesPoint(FromMs(t), HttpHelper.GetDouble(it, "fundingRate")));
                    inRange++;
                }
            }
            if (inRange == 0 || inRange < batch || batch < 500) break;
            cur = last + 1;
        }
        return rec;
    }

    private async Task<List<SeriesPoint>> FetchBitget(string sym, long startMs, long endMs, CancellationToken ct)
    {
        var rec = new List<SeriesPoint>();
        for (int page = 1; page <= 40; page++)
        {
            var url = "https://api.bitget.com/api/v2/mix/market/funding-rate-history" +
                      $"?symbol={sym}USDT&productType=USDT-FUTURES&pageSize=100&pageNo={page}";
            using var doc = await HttpHelper.GetJsonAsync(url, ct);
            if (doc == null || HttpHelper.GetString(doc.RootElement, "code") != "00000") break;
            if (!doc.RootElement.TryGetProperty("data", out var data)
                || !data.TryGetProperty("fundingRates", out var rates) || rates.ValueKind != JsonValueKind.Array) break;
            int n = rates.GetArrayLength();
            if (n == 0) break;

            foreach (var r in rates.EnumerateArray())
            {
                long t = HttpHelper.GetLong(r, "settleTime");
                if (t >= startMs && t <= endMs)
                    rec.Add(new SeriesPoint(FromMs(t), HttpHelper.GetDouble(r, "fundingRate")));
            }
            if (n < 100) break;
        }
        return rec;
    }

    private async Task<List<SeriesPoint>> FetchHtx(string sym, long startMs, long endMs, CancellationToken ct)
    {
        var rec = new List<SeriesPoint>();
        for (int page = 1; page <= 30; page++)
        {
            var url = "https://api.hbdm.com/linear-swap-api/v1/swap_historical_funding_rate" +
                      $"?contract_code={sym}-USDT&page_index={page}&page_size=50";
            using var doc = await HttpHelper.GetJsonAsync(url, ct);
            if (doc == null || HttpHelper.GetString(doc.RootElement, "status") != "ok") break;
            if (!doc.RootElement.TryGetProperty("data", out var data)
                || !data.TryGetProperty("data", out var items) || items.ValueKind != JsonValueKind.Array) break;
            if (items.GetArrayLength() == 0) break;

            foreach (var it in items.EnumerateArray())
            {
                long t = HttpHelper.GetLong(it, "settlement_time");
                if (t >= startMs && t <= endMs)
                    rec.Add(new SeriesPoint(FromMs(t), HttpHelper.GetDouble(it, "funding_rate")));
            }
            int totalPage = (int)HttpHelper.GetDouble(data, "total_page");
            if (page >= totalPage) break;
        }
        return rec;
    }

    private async Task<List<SeriesPoint>> FetchGate(string sym, long startMs, long endMs, CancellationToken ct)
    {
        var rec = new List<SeriesPoint>();
        string? contract = _gateDirect ? $"{sym}_USDT" : (_gateMap.TryGetValue(sym, out var c) ? c : null);
        if (contract == null) return rec;

        long cur = startMs / 1000;
        long to = endMs / 1000;
        for (int i = 0; i < 5; i++)
        {
            var url = $"https://api.gateio.ws/api/v4/futures/usdt/funding_rate_records?contract={contract}&from={cur}&to={to}&limit=1000";
            using var doc = await HttpHelper.GetJsonAsync(url, ct);
            if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) break;
            int n = doc.RootElement.GetArrayLength();
            if (n == 0) break;

            long lastT = cur;
            foreach (var it in doc.RootElement.EnumerateArray())
            {
                long t = HttpHelper.GetLong(it, "t");
                lastT = t;
                rec.Add(new SeriesPoint(FromMs(t * 1000), HttpHelper.GetDouble(it, "r")));
            }
            if (n < 1000) break;
            cur = lastT + 1;
        }
        return rec;
    }
}
