using FundingRateScan.Models;
using FundingRateScan.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// Finestra di scaricamento: l'utente sceglie la soglia di affollamento long,
/// gli altri parametri, e configura le API di ogni exchange.
/// </summary>
public class DownloadForm : AppForm
{
    private readonly AppSettings _settings;

    private NumericUpDown _numFunding = null!;
    private NumericUpDown _numPersistence = null!;
    private NumericUpDown _numLookback = null!;
    private NumericUpDown _numTopN = null!;
    private NumericUpDown _numVolGrowth = null!;
    private NumericUpDown _numOiGrowth = null!;
    private NumericUpDown _numMinVol = null!;
    private DataGridView _grid = null!;

    /// <summary>Parametri scelti, validi dopo DialogResult.OK.</summary>
    public ScanParameters Parameters { get; private set; } = new();

    public DownloadForm(AppSettings settings)
    {
        _settings = settings;
        Parameters = settings.LastParameters;
        BuildUi();
        LoadValues();
    }

    private void BuildUi()
    {
        Text = "Scarica dati — Configurazione scansione";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = false;
        MaximizeBox = false;
        ClientSize = new Size(760, 620);
        Font = new Font("Segoe UI", 9f);

        // ---- GroupBox parametri ------------------------------------------------
        var gbParams = new GroupBox
        {
            Text = "Parametri di scansione",
            Location = new Point(12, 12),
            Size = new Size(736, 210)
        };
        Controls.Add(gbParams);

        int y = 28;
        _numFunding = AddParam(gbParams, "Soglia affollamento long (Funding APR ≥ %):", ref y,
            0, 1000, 1, "Solo le coin con funding annualizzato sopra questa soglia (longs che pagano).");
        _numPersistence = AddParam(gbParams, "Persistenza minima funding (% periodi positivi):", ref y,
            0, 100, 0, "Quota minima di periodi con funding positivo nello storico.");
        _numLookback = AddParam(gbParams, "Giorni di storico da analizzare:", ref y,
            7, 90, 0, "Finestra temporale per persistenza, volumi e open interest.");
        _numTopN = AddParam(gbParams, "Numero massimo di coin candidate:", ref y,
            10, 500, 0, "Limite di coin da arricchire con dati storici (controlla la durata).");

        // seconda colonna
        int y2 = 28;
        _numVolGrowth = AddParam(gbParams, "Crescita minima volume (%):", ref y2,
            -100, 1000, 1, "Crescita volume per il pattern attivo.", 380);
        _numOiGrowth = AddParam(gbParams, "Crescita minima open interest (%):", ref y2,
            -100, 1000, 1, "Crescita OI per il pattern attivo.", 380);
        _numMinVol = AddParam(gbParams, "Volume minimo 24h (USD):", ref y2,
            0, 1_000_000_000, 0, "Esclude coin illiquide.", 380);
        _numMinVol.Increment = 500_000;

        // ---- GroupBox exchange/API --------------------------------------------
        var gbEx = new GroupBox
        {
            Text = "Exchange e API (le chiavi sono opzionali: i dati di mercato sono pubblici)",
            Location = new Point(12, 232),
            Size = new Size(736, 290)
        };
        Controls.Add(gbEx);

        _grid = new DataGridView
        {
            Location = new Point(12, 24),
            Size = new Size(712, 252),
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.CellSelect,
            EditMode = DataGridViewEditMode.EditOnEnter,
            BackgroundColor = SystemColors.Window
        };
        gbEx.Controls.Add(_grid);

        _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Usa", Name = "Enabled", FillWeight = 8 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Exchange", Name = "Name", ReadOnly = true, FillWeight = 16 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "API Key", Name = "ApiKey", FillWeight = 26 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "API Secret", Name = "ApiSecret", FillWeight = 26 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Passphrase", Name = "Passphrase", FillWeight = 16 });

        // ---- Pulsanti ----------------------------------------------------------
        var btnSelectAll = new Button { Text = "Seleziona tutti", Location = new Point(12, 532), Size = new Size(110, 30) };
        btnSelectAll.Click += (_, _) => SetAll(true);
        var btnSelectNone = new Button { Text = "Deseleziona tutti", Location = new Point(128, 532), Size = new Size(120, 30) };
        btnSelectNone.Click += (_, _) => SetAll(false);

        var btnStart = new Button { Text = "Avvia scaricamento", Location = new Point(498, 532), Size = new Size(140, 34) };
        btnStart.Click += BtnStart_Click;
        var btnCancel = new Button { Text = "Annulla", Location = new Point(648, 532), Size = new Size(100, 34), DialogResult = DialogResult.Cancel };

        Controls.Add(btnSelectAll);
        Controls.Add(btnSelectNone);
        Controls.Add(btnStart);
        Controls.Add(btnCancel);

        AcceptButton = btnStart;
        CancelButton = btnCancel;
    }

    private NumericUpDown AddParam(GroupBox gb, string label, ref int y,
        decimal min, decimal max, int decimals, string tip, int x = 0)
    {
        var lbl = new Label { Text = label, Location = new Point(x + 12, y + 3), AutoSize = true, MaximumSize = new Size(260, 0) };
        var num = new NumericUpDown
        {
            Location = new Point(x + 276, y),
            Size = new Size(88, 24),
            Minimum = min,
            Maximum = max,
            DecimalPlaces = decimals,
            ThousandsSeparator = true
        };
        var tt = new ToolTip();
        tt.SetToolTip(num, tip);
        tt.SetToolTip(lbl, tip);
        gb.Controls.Add(lbl);
        gb.Controls.Add(num);
        y += 36;
        return num;
    }

    private void LoadValues()
    {
        var p = Parameters;
        _numFunding.Value = (decimal)Math.Clamp(p.FundingAprThreshold, 0, 1000);
        _numPersistence.Value = (decimal)Math.Clamp(p.MinPersistencePct, 0, 100);
        _numLookback.Value = Math.Clamp(p.LookbackDays, 7, 90);
        _numTopN.Value = Math.Clamp(p.TopN, 10, 500);
        _numVolGrowth.Value = (decimal)Math.Clamp(p.VolGrowthMinPct, -100, 1000);
        _numOiGrowth.Value = (decimal)Math.Clamp(p.OiGrowthMinPct, -100, 1000);
        _numMinVol.Value = (decimal)Math.Clamp(p.MinVolumeUsd, 0, 1_000_000_000);

        foreach (var cfg in _settings.Exchanges)
        {
            int i = _grid.Rows.Add();
            var row = _grid.Rows[i];
            row.Cells["Enabled"].Value = cfg.Enabled;
            row.Cells["Name"].Value = cfg.Name;
            row.Cells["ApiKey"].Value = cfg.ApiKey;
            row.Cells["ApiSecret"].Value = cfg.ApiSecret;
            row.Cells["Passphrase"].Value = cfg.Passphrase;
        }
    }

    private void SetAll(bool value)
    {
        _grid.EndEdit();
        foreach (DataGridViewRow row in _grid.Rows)
            row.Cells["Enabled"].Value = value;
    }

    private void BtnStart_Click(object? sender, EventArgs e)
    {
        _grid.EndEdit();

        // Salva i parametri
        Parameters = new ScanParameters
        {
            FundingAprThreshold = (double)_numFunding.Value,
            MinPersistencePct = (double)_numPersistence.Value,
            LookbackDays = (int)_numLookback.Value,
            TopN = (int)_numTopN.Value,
            VolGrowthMinPct = (double)_numVolGrowth.Value,
            OiGrowthMinPct = (double)_numOiGrowth.Value,
            MinVolumeUsd = (double)_numMinVol.Value,
        };

        // Aggiorna le config exchange
        foreach (DataGridViewRow row in _grid.Rows)
        {
            var name = row.Cells["Name"].Value?.ToString() ?? "";
            var cfg = _settings.Exchanges.FirstOrDefault(c => c.Name == name);
            if (cfg == null) continue;
            cfg.Enabled = row.Cells["Enabled"].Value is bool b && b;
            cfg.ApiKey = row.Cells["ApiKey"].Value?.ToString() ?? "";
            cfg.ApiSecret = row.Cells["ApiSecret"].Value?.ToString() ?? "";
            cfg.Passphrase = row.Cells["Passphrase"].Value?.ToString() ?? "";
        }

        if (!_settings.Exchanges.Any(c => c.Enabled))
        {
            MessageBox.Show(this, "Seleziona almeno un exchange.", "Attenzione",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _settings.LastParameters = Parameters;
        SettingsManager.Save(_settings);
        DialogResult = DialogResult.OK;
        Close();
    }
}
