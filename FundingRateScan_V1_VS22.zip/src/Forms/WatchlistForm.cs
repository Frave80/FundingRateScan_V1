using System.Globalization;
using FundingRateScan.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// Elenco delle coin salvate dall'utente (« scoperte »). Mostra tutte le coin spuntate nelle
/// varie ricerche, con fonte e data di salvataggio; permette di rimuoverle e di aprire la
/// pagina di quotazione (doppio clic). Si aggiorna automaticamente quando la watchlist cambia.
/// </summary>
public sealed class WatchlistForm : AppForm
{
    private static readonly CultureInfo Ci = CultureInfo.InvariantCulture;
    private DataGridView _grid = null!;
    private Label _count = null!;

    public WatchlistForm()
    {
        BuildUi();
        Fill();
        // Si aggiorna se l'utente spunta/rimuove coin da un'altra finestra mentre questa è aperta.
        WatchlistService.Changed += OnChanged;
    }

    private void BuildUi()
    {
        Text = "Scoperte salvate (watchlist)";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(820, 560);
        MinimumSize = new Size(620, 360);
        Font = new Font("Segoe UI", 9f);

        var bar = new Panel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(8, 6, 8, 4) };
        var btnOpen = new Button { Text = "Apri quotazione", Location = new Point(8, 5), Size = new Size(130, 28) };
        btnOpen.Click += (_, _) => OpenSelected();
        var btnRemove = new Button { Text = "Rimuovi selezionata", Location = new Point(144, 5), Size = new Size(150, 28) };
        btnRemove.Click += (_, _) => RemoveSelected();
        var hint = new Label { Text = "Doppio clic su una riga = apri quotazione · Canc = rimuovi", Location = new Point(306, 11), AutoSize = true, ForeColor = Color.DimGray };
        bar.Controls.AddRange(new Control[] { btnOpen, btnRemove, hint });

        _grid = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false, BackgroundColor = SystemColors.Window, BorderStyle = BorderStyle.None, EnableHeadersVisualStyles = false
        };
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(40, 44, 60);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.ColumnHeadersDefaultCellStyle.Font = UiFonts.Bold9;
        AddCol("Fonte", 90);
        AddCol("Coin", 70);
        AddCol("Nome", 150);
        AddCol("Chain", 90);
        AddCol("Contratto", 200);
        AddCol("Salvata il", 110);
        _grid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) OpenRow(_grid.Rows[e.RowIndex]); };
        _grid.KeyDown += (_, e) => { if (e.KeyCode == Keys.Delete) { RemoveSelected(); e.Handled = true; } };

        _count = new Label
        {
            Dock = DockStyle.Bottom, Height = 26, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(10, 0, 0, 0),
            BackColor = Color.FromArgb(17, 24, 39), ForeColor = Color.Gainsboro, Font = new Font("Consolas", 9.5f)
        };

        Controls.Add(_grid);
        Controls.Add(bar);
        Controls.Add(_count);
    }

    private void AddCol(string header, int w)
        => _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = header, FillWeight = w });

    private void OnChanged()
    {
        if (IsDisposed) return;
        if (InvokeRequired) { BeginInvoke(Fill); return; }
        Fill();
    }

    private void Fill()
    {
        var all = WatchlistService.All();
        _grid.SuspendLayout();
        _grid.Rows.Clear();
        foreach (var c in all)
        {
            int i = _grid.Rows.Add(c.Source, c.Symbol, c.Name, c.Chain,
                c.Contract.Length > 0 ? c.Contract : "—",
                c.SavedUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm", Ci));
            _grid.Rows[i].Tag = c;
        }
        _grid.ResumeLayout();
        _count.Text = all.Count == 0
            ? "Nessuna coin salvata. Spunta la casella ★ nelle ricerche per aggiungerle."
            : $"{all.Count} coin salvate nella watchlist.";
    }

    private void OpenSelected() { if (_grid.CurrentRow != null) OpenRow(_grid.CurrentRow); }

    private void OpenRow(DataGridViewRow row)
    {
        if (row.Tag is not WatchedCoin c) return;
        // Coin on-chain (con contratto) → DEX Screener; coin da CEX → CoinMarketCap/TradingView.
        if (!string.IsNullOrWhiteSpace(c.Url)) QuoteLinks.OpenDex(c.Url);
        else if (!string.IsNullOrWhiteSpace(c.Contract)) QuoteLinks.OpenDexSearch(c.Contract);
        else _ = QuoteLinks.OpenSymbolAsync(c.Symbol, c.Name, preferDexFallback: false, null, CancellationToken.None);
    }

    private void RemoveSelected()
    {
        if (_grid.CurrentRow?.Tag is not WatchedCoin c) return;
        WatchlistService.Remove(c.Key);   // l'evento Changed ricarica la lista
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        WatchlistService.Changed -= OnChanged;   // evita riferimenti pendenti
        base.OnFormClosing(e);
    }
}
