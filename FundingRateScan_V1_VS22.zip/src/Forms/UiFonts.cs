namespace FundingRateScan.Forms;

/// <summary>
/// Font condivisi e immutabili usati nelle griglie e nelle viste.
///
/// MOTIVO (bug GDI+): assegnare « new Font(...) » allo stile di ogni cella dentro i cicli di
/// riempimento creava un nuovo handle GDI+ per ogni riga a ogni aggiornamento della tabella.
/// Su molte scansioni/ri-filtri gli handle si accumulano (perdita di risorse) fino al degrado
/// del rendering. Un Font è immutabile e può essere condiviso da più celle in sicurezza: qui
/// se ne creano poche istanze statiche, riusate ovunque, eliminando le allocazioni per riga.
/// </summary>
internal static class UiFonts
{
    /// <summary>Segoe UI 9pt grassetto — intestazioni e celle evidenziate.</summary>
    public static readonly Font Bold9 = new("Segoe UI", 9f, FontStyle.Bold);

    /// <summary>Segoe UI 9pt sottolineato — simboli cliccabili (link alla quotazione).</summary>
    public static readonly Font Underline9 = new("Segoe UI", 9f, FontStyle.Underline);

    /// <summary>Segoe UI 9.5pt grassetto — valori in risalto.</summary>
    public static readonly Font Bold95 = new("Segoe UI", 9.5f, FontStyle.Bold);
}
