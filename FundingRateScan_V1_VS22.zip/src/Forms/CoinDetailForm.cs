using System.Globalization;
using FundingRateScan.Models;
using FundingRateScan.Services;

namespace FundingRateScan.Forms;


/// <summary>
/// Dettaglio di una singola coin: dati numerici + heatmap calendario dei funding
/// rate (media giornaliera, nero → rosso), e schede per volume e open interest.
/// </summary>
public class CoinDetailForm : AppForm
{
    private static readonly CultureInfo It = CultureInfo.GetCultureInfo("it-IT");

    private readonly CoinResult _r;
    private readonly AppSettings? _settings;
    private readonly double _aprFactor;
    private readonly CancellationTokenSource _cts = new();
    private readonly Dictionary<int, List<TrendPoint>> _fundingCache = new();
    private int _requestedDays = -1;   // ultimo periodo richiesto: scarta le risposte tardive (anti-race UI-005)

    private HeatmapControl _fundingHeatmap = null!;
    private Label _fundingStatus = null!;
    private ComboBox _cmbPeriod = null!;

    // Periodi selezionabili: etichetta → giorni
    private static readonly (string Label, int Days)[] Periods =
    {
        ("1 mese", 31), ("2 mesi", 62), ("6 mesi", 186), ("12 mesi", 372)
    };

    public CoinDetailForm(CoinResult result, AppSettings? settings = null)
    {
        _r = result;
        _settings = settings;
        double interval = result.Representative?.FundingIntervalHours ?? 8.0;
        _aprFactor = 24.0 / interval * 365.0 * 100.0;
        BuildUi();
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        LoadFundingPeriod(Periods[0].Days);   // carica "1 mese" all'apertura
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        _cts.Cancel();
        base.OnFormClosing(e);
    }

    private void BuildUi()
    {
        Text = $"Dettaglio {_r.Base} — {(_r.Name.Length > 0 ? _r.Name + " — " : "")}{StatoText(_r.Classification)}";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1000, 720);
        MinimumSize = new Size(760, 560);
        Font = new Font("Segoe UI", 9f);

        Controls.Add(BuildTabs());      // Dock Fill (aggiunto per primo, riempie il resto)
        Controls.Add(BuildNumericPanel());
    }

    // ----------------------------------------------------- Pannello numerico
    private Control BuildNumericPanel()
    {
        var panel = new Panel { Dock = DockStyle.Top, Height = 162, Padding = new Padding(10, 8, 10, 8) };

        var title = new Label
        {
            Text = $"{_r.Base}{(_r.Name.Length > 0 ? "  ·  " + _r.Name : "")}   ({StatoText(_r.Classification)})",
            Font = new Font("Segoe UI", 13f, FontStyle.Bold),
            ForeColor = StatoColor(_r.Classification),
            AutoSize = true,
            Location = new Point(10, 6)
        };
        panel.Controls.Add(title);

        var ci = CultureInfo.InvariantCulture;
        var fields = new (string, string)[]
        {
            ("Funding APR",       $"{_r.FundingApr.ToString("N1", ci)} %"),
            ("Funding corrente",  $"{(_r.FundingRateRaw * 100).ToString("N4", ci)} %"),
            ("Persistenza",       $"{_r.PersistencePct.ToString("N0", ci)} %  ({_r.FundingSamples} campioni)"),
            ("Δ Volume",          $"{_r.VolGrowthPct.ToString("N1", ci)} %"),
            ("Δ Open Interest",   $"{_r.OiGrowthPct.ToString("N1", ci)} %"),
            ("Volume 24h",        $"{_r.Volume24hUsd.ToString("N0", ci)} USD"),
            ("Open Interest",     $"{_r.OpenInterestUsd.ToString("N0", ci)} USD"),
            ("Prezzo",            $"{_r.LastPrice.ToString("G6", ci)} USD"),
            ("Exchange",          _r.Exchanges),
            ("Riferimento dati",  $"{_r.RepresentativeExchange} ({_r.RepresentativeSymbol})"),
        };

        int col0X = 10, col1X = 520;
        int rowY = 40, rowH = 22;
        for (int i = 0; i < fields.Length; i++)
        {
            int x = i < 5 ? col0X : col1X;
            int y = rowY + (i % 5) * rowH;

            var lbl = new Label
            {
                Text = fields[i].Item1 + ":",
                Location = new Point(x, y),
                AutoSize = true,
                ForeColor = Color.DimGray
            };
            var val = new Label
            {
                Text = fields[i].Item2,
                Location = new Point(x + 130, y),
                AutoSize = true,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };
            panel.Controls.Add(lbl);
            panel.Controls.Add(val);
        }
        return panel;
    }

    // ------------------------------------------------------------- Schede
    private Control BuildTabs()
    {
        var tabs = new TabControl { Dock = DockStyle.Fill };

        // 1) Heatmap funding — calendario (mesi × giorni), media giornaliera nero→rosso
        var tabFunding = new TabPage("Heatmap funding");
        tabFunding.Controls.Add(BuildFundingTab());
        tabs.TabPages.Add(tabFunding);

        // 2) Volume storico
        var tabVol = new TabPage("Volume storico");
        tabVol.Controls.Add(BuildSeriesHeatmap(
            _r.Representative?.VolumeHistory, "USD", HeatmapPalette.Sequential,
            "Nessuno storico di volume disponibile (l'exchange di riferimento non lo espone)."));
        tabs.TabPages.Add(tabVol);

        // 3) Open interest storico
        var tabOi = new TabPage("Open interest storico");
        tabOi.Controls.Add(BuildSeriesHeatmap(
            _r.Representative?.OiHistory, "USD", HeatmapPalette.Sequential,
            "Nessuno storico di open interest disponibile (l'exchange di riferimento non lo espone)."));
        tabs.TabPages.Add(tabOi);

        // 4) Segnali meme (cap. 10.2): dimensione Derivati calcolabile da questa coin
        var tabMeme = new TabPage("Segnali meme");
        tabMeme.Controls.Add(BuildMemeSignalsTab());
        tabs.TabPages.Add(tabMeme);

        return tabs;
    }

    /// <summary>
    /// Scheda "Segnali meme" (cap. 10.2): per una coin con perpetuo la dimensione
    /// Derivati del punteggio meme è calcolabile direttamente da funding/persistenza/OI.
    /// Le altre dimensioni (liquidità, adozione, sociale) richiedono l'indirizzo del
    /// contratto e si calcolano dalla Scoperta meme on-chain.
    /// </summary>
    private Control BuildMemeSignalsTab()
    {
        var ci = CultureInfo.InvariantCulture;
        var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 14, 16, 14) };

        double fundComp = Math.Clamp(_r.FundingApr / 50.0, 0, 1) * Math.Clamp(_r.PersistencePct / 100.0, 0, 1);
        double oiComp = Math.Clamp(_r.OiGrowthPct / 40.0, 0, 1);
        double deriv = Math.Round((0.7 * fundComp + 0.3 * oiComp) * 100.0, 0);

        var title = new Label
        {
            Text = "Dimensione Derivati del punteggio meme",
            Font = new Font("Segoe UI", 12f, FontStyle.Bold), ForeColor = Color.FromArgb(150, 90, 200),
            AutoSize = true, Location = new Point(4, 4)
        };
        host.Controls.Add(title);

        var rows = new (string, string)[]
        {
            ("Funding APR", $"{_r.FundingApr.ToString("N1", ci)} %"),
            ("Persistenza funding", $"{_r.PersistencePct.ToString("N0", ci)} %"),
            ("Δ Open Interest", $"{_r.OiGrowthPct.ToString("N1", ci)} %"),
            ("Punteggio Derivati", $"{deriv.ToString("N0", ci)} / 100"),
        };
        int y = 44;
        foreach (var (k, v) in rows)
        {
            host.Controls.Add(new Label { Text = k + ":", Location = new Point(8, y), AutoSize = true, ForeColor = Color.DimGray });
            host.Controls.Add(new Label { Text = v, Location = new Point(220, y), AutoSize = true, Font = new Font("Segoe UI", 10f, FontStyle.Bold) });
            y += 28;
        }

        y += 10;
        host.Controls.Add(new Label
        {
            Text = "Le dimensioni Liquidità & mercato, Adozione on-chain e Momentum sociale richiedono\n" +
                   "l'indirizzo del contratto on-chain: usa la Scoperta meme per il punteggio composito completo\n" +
                   "(★ Alto potenziale / ◆ Emergente / ◇ Da osservare / ✕ Rischio elevato).",
            Location = new Point(8, y), AutoSize = true, ForeColor = Color.DimGray, Font = new Font("Segoe UI", 9f),
            UseMnemonic = false
        });
        y += 70;

        if (_settings != null)
        {
            var btn = new Button { Text = "Apri Scoperta meme on-chain...", Location = new Point(8, y), Size = new Size(230, 30) };
            btn.Click += (_, _) => new MemeDiscoveryForm(_settings).Show(this);
            host.Controls.Add(btn);
        }
        return host;
    }

    /// <summary>
    /// Scheda funding: barra con selettore di periodo (1/2/6/12 mesi) e la heatmap
    /// calendario. Ogni cella è un giorno colorato come media giornaliera del funding
    /// (nero = basso/negativo, rosso = funding elevato).
    /// </summary>
    private Control BuildFundingTab()
    {
        var host = new Panel { Dock = DockStyle.Fill };

        var bar = new Panel { Dock = DockStyle.Top, Height = 36, Padding = new Padding(8, 6, 8, 4) };

        var lblP = new Label { Text = "Periodo:", Location = new Point(8, 9), AutoSize = true };
        _cmbPeriod = new ComboBox
        {
            Location = new Point(66, 5),
            Size = new Size(110, 24),
            DropDownStyle = ComboBoxStyle.DropDownList
        };
        foreach (var p in Periods) _cmbPeriod.Items.Add(p.Label);
        _cmbPeriod.SelectedIndex = 0;
        _cmbPeriod.SelectedIndexChanged += (_, _) => LoadFundingPeriod(Periods[_cmbPeriod.SelectedIndex].Days);

        _fundingStatus = new Label { Location = new Point(190, 9), AutoSize = true, ForeColor = Color.DimGray };

        bar.Controls.Add(lblP);
        bar.Controls.Add(_cmbPeriod);
        bar.Controls.Add(_fundingStatus);

        _fundingHeatmap = new HeatmapControl
        {
            Dock = DockStyle.Fill,
            Palette = HeatmapPalette.FundingBlackRed,
            Unit = "%",
            EmptyText = "Caricamento dati funding..."
        };

        host.Controls.Add(_fundingHeatmap);
        host.Controls.Add(bar);
        return host;
    }

    /// <summary>Scarica (con cache) i funding del periodo e aggiorna la heatmap calendario.</summary>
    private async void LoadFundingPeriod(int days)
    {
        // Registra il periodo richiesto: se l'utente cambia rapidamente 1/2/6/12 mesi, solo la
        // risposta del periodo selezionato per ULTIMO verrà disegnata (le altre sono scartate).
        _requestedDays = days;
        _fundingStatus.Text = "Caricamento...";
        _fundingHeatmap.EmptyText = "Caricamento dati funding...";
        _fundingHeatmap.Clear();

        try
        {
            List<TrendPoint> hist;
            if (_fundingCache.TryGetValue(days, out var cached))
            {
                hist = cached;
            }
            else
            {
                hist = new List<TrendPoint>();
                var client = ScanService.CreateClient(_r.RepresentativeExchange);
                if (client != null && !string.IsNullOrEmpty(_r.RepresentativeSymbol))
                    hist = await client.FetchFundingHistoryAsync(_r.RepresentativeSymbol, days, _cts.Token);

                // Ripiego sui dati già raccolti durante la scansione, se il fetch è vuoto.
                if (hist.Count == 0 && _r.Representative != null)
                    hist = _r.Representative.FundingHistory;

                _fundingCache[days] = hist;
            }

            // Scarta la risposta se nel frattempo è stato richiesto un altro periodo (anti-race).
            if (_cts.IsCancellationRequested || days != _requestedDays) return;

            var matrix = BuildCalendarMatrix(hist);
            if (matrix == null)
            {
                _fundingHeatmap.EmptyText = "Nessuno storico funding disponibile per questa coin.";
                _fundingHeatmap.Clear();
                _fundingStatus.Text = "";
                return;
            }

            _fundingHeatmap.SetData(matrix.Value.cells, matrix.Value.rows, matrix.Value.cols);
            _fundingStatus.Text = $"{hist.Count} valori · media giornaliera del funding (APR %) · {_r.RepresentativeExchange}";
        }
        catch (OperationCanceledException) { /* form chiuso */ }
        catch (Exception ex)
        {
            _fundingHeatmap.EmptyText = "Errore nel caricamento: " + ex.Message;
            _fundingHeatmap.Clear();
            _fundingStatus.Text = "Errore.";
        }
    }

    /// <summary>
    /// Costruisce la matrice calendario: righe = mesi, colonne = giorni del mese (1..31).
    /// Ogni cella è la media giornaliera del funding APR.
    /// </summary>
    private (double?[,] cells, string[] rows, string[] cols)? BuildCalendarMatrix(List<TrendPoint> raw)
    {
        if (raw == null || raw.Count == 0) return null;

        // Media giornaliera (APR %) per ogni data di calendario.
        var daily = raw
            .GroupBy(t => t.Time.Date)
            .Select(g => (Day: g.Key, Apr: g.Average(t => t.Value) * _aprFactor))
            .OrderBy(x => x.Day)
            .ToList();
        if (daily.Count == 0) return null;

        var minDay = daily[0].Day;
        var maxDay = daily[^1].Day;

        // Elenco mesi continuo da minDay a maxDay.
        var months = new List<DateTime>();
        var cur = new DateTime(minDay.Year, minDay.Month, 1);
        var end = new DateTime(maxDay.Year, maxDay.Month, 1);
        while (cur <= end) { months.Add(cur); cur = cur.AddMonths(1); }

        var monthIdx = months
            .Select((m, i) => (key: m.Year * 12 + m.Month - 1, i))
            .ToDictionary(x => x.key, x => x.i);

        var cells = new double?[months.Count, 31];
        foreach (var d in daily)
        {
            int mi = monthIdx[d.Day.Year * 12 + d.Day.Month - 1];
            cells[mi, d.Day.Day - 1] = d.Apr;
        }

        var rows = months.Select(m => m.ToString("MMM yyyy", It)).ToArray();
        var cols = Enumerable.Range(1, 31).Select(i => i.ToString()).ToArray();
        return (cells, rows, cols);
    }

    /// <summary>Heatmap a riga singola (per data) per una serie sempre positiva.</summary>
    private Control BuildSeriesHeatmap(List<TrendPoint>? series, string unit, HeatmapPalette palette, string emptyText)
    {
        var hm = new HeatmapControl { Dock = DockStyle.Fill, Palette = palette, Unit = "", EmptyText = emptyText };
        if (series == null || series.Count == 0) return hm;

        var ordered = series.OrderBy(t => t.Time).ToList();
        var cells = new double?[1, ordered.Count];
        for (int i = 0; i < ordered.Count; i++) cells[0, i] = ordered[i].Value;

        var rowLabels = new[] { "" };
        var colLabels = ordered.Select(t => t.Time.ToString("dd MMM", CultureInfo.InvariantCulture)).ToArray();

        hm.SetData(cells, rowLabels, colLabels);
        return hm;
    }

    // ------------------------------------------------------------- Helper
    private static string StatoText(Classification c) => c switch
    {
        Classification.PatternActive => "Pattern attivo",
        Classification.Watch => "Da osservare",
        _ => "Neutra"
    };

    private static Color StatoColor(Classification c) => c switch
    {
        Classification.PatternActive => Color.FromArgb(0, 140, 60),
        Classification.Watch => Color.FromArgb(190, 130, 0),
        _ => Color.DimGray
    };
}
