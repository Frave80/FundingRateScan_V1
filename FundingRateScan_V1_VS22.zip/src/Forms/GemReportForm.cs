using System.Text;
using FundingRateScan.Gems;

namespace FundingRateScan.Forms;

/// <summary>
/// Visualizza il dossier di approfondimento di una gemma (documento Markdown)
/// con possibilità di salvarlo come .md / .txt o copiarlo negli appunti.
/// </summary>
public sealed class GemReportForm : AppForm
{
    private readonly GemCandidate _gem;
    private readonly string _report;
    private TextBox _txt = null!;

    public GemReportForm(GemCandidate gem)
    {
        _gem = gem;
        _report = GemReportBuilder.Build(gem);
        BuildUi();
    }

    private void BuildUi()
    {
        Text = $"Dossier — {_gem.Symbol} ({_gem.Name}) · MoonScore {_gem.MoonScore:N0}/100";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(860, 680);
        MinimumSize = new Size(640, 480);
        Font = new Font("Segoe UI", 9f);

        // Barra pulsanti (in basso)
        var pnl = new Panel { Dock = DockStyle.Bottom, Height = 44, Padding = new Padding(8) };

        var btnMd = new Button { Text = "Salva .md", Location = new Point(8, 8), Size = new Size(110, 28) };
        btnMd.Click += (_, _) => Save("Markdown (*.md)|*.md", ".md");

        var btnTxt = new Button { Text = "Salva .txt", Location = new Point(126, 8), Size = new Size(110, 28) };
        btnTxt.Click += (_, _) => Save("Testo (*.txt)|*.txt", ".txt");

        var btnCopy = new Button { Text = "Copia negli appunti", Location = new Point(244, 8), Size = new Size(150, 28) };
        btnCopy.Click += (_, _) =>
        {
            try { Clipboard.SetText(_report); }
            catch { /* clipboard occupata */ }
        };

        var btnClose = new Button { Text = "Chiudi", Location = new Point(402, 8), Size = new Size(90, 28) };
        btnClose.Click += (_, _) => Close();

        pnl.Controls.AddRange(new Control[] { btnMd, btnTxt, btnCopy, btnClose });

        // Documento
        _txt = new TextBox
        {
            Dock = DockStyle.Fill,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Both,
            WordWrap = true,
            BackColor = Color.FromArgb(252, 252, 250),
            ForeColor = Color.FromArgb(25, 28, 35),
            Font = new Font("Consolas", 9.5f),
            Text = _report   // AppendLine genera già \r\n su Windows
        };

        Controls.Add(_txt);
        Controls.Add(pnl);

        // Evita che tutto il testo risulti selezionato all'apertura
        Shown += (_, _) => { _txt.SelectionStart = 0; _txt.SelectionLength = 0; };
    }

    private void Save(string filter, string ext)
    {
        using var sfd = new SaveFileDialog
        {
            Filter = filter,
            FileName = $"dossier_{_gem.Symbol}_{DateTime.Now:yyyyMMdd_HHmm}{ext}"
        };
        if (sfd.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            File.WriteAllText(sfd.FileName, _report, new UTF8Encoding(true));
            MessageBox.Show(this, "Dossier salvato:\n" + sfd.FileName, "Dossier",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore salvataggio", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
