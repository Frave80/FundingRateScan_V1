using System.Drawing.Drawing2D;

namespace FundingRateScan.Forms;

/// <summary>
/// Fabbrica di icone disegnate a runtime con GDI+ (nessun file immagine esterno da
/// distribuire). Ogni metodo restituisce una <see cref="Bitmap"/> trasparente con un
/// glifo semplice, riconoscibile e coerente con la palette dell'applicazione.
///
/// Uso tipico:
///   <c>var b = new ToolStripButton { Image = Icons.Scan(), ImageScaling = ... };</c>
///
/// Le bitmap sono memorizzate in cache per coppia (nome, dimensione): vengono disegnate
/// una sola volta e poi riutilizzate, così la toolbar e i menu non ridisegnano a ogni uso.
/// </summary>
public static class Icons
{
    // --- Palette condivisa (gli stessi colori usati nelle altre viste) ---------
    private static readonly Color Blue = Color.FromArgb(46, 117, 182);   // azione neutra / scansione
    private static readonly Color Green = Color.FromArgb(33, 150, 83);    // avvio / conferma
    private static readonly Color Red = Color.FromArgb(200, 60, 55);      // stop / pericolo
    private static readonly Color Purple = Color.FromArgb(150, 90, 200);  // meme / scoperta
    private static readonly Color Teal = Color.FromArgb(0, 150, 170);     // on-chain
    private static readonly Color Cyan = Color.FromArgb(40, 170, 215);    // gemme
    private static readonly Color Orange = Color.FromArgb(224, 138, 30);  // PRO / 100x
    private static readonly Color Slate = Color.FromArgb(90, 100, 120);   // strumenti / documenti
    private static readonly Color Gold = Color.FromArgb(230, 180, 40);    // priorità

    // Cache: chiave = "nome_dimensione"
    private static readonly Dictionary<string, Bitmap> _cache = new();

    /// <summary>
    /// Crea (o recupera dalla cache) una bitmap quadrata trasparente e vi disegna il glifo
    /// tramite il delegato <paramref name="draw"/>, che riceve il contesto grafico e la
    /// dimensione in pixel come float (per calcolare le coordinate in proporzione).
    /// </summary>
    private static Bitmap Make(string name, int size, Action<Graphics, float> draw)
    {
        var key = $"{name}_{size}";
        if (_cache.TryGetValue(key, out var cached)) return cached;

        var bmp = new Bitmap(size, size);
        using (var g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;     // bordi morbidi
            g.Clear(Color.Transparent);
            draw(g, size);
        }
        _cache[key] = bmp;
        return bmp;
    }

    // ======================================================================
    //  ICONE  (dimensione predefinita 24px per la toolbar; 16px per i menu)
    // ======================================================================

    /// <summary>Lente d'ingrandimento — "Nuova scansione".</summary>
    public static Bitmap Scan(int size = 24) => Make("scan", size, (g, s) =>
    {
        using var pen = new Pen(Green, Math.Max(2f, s / 11f)) { StartCap = LineCap.Round, EndCap = LineCap.Round };
        float d = s * 0.5f, p = s * 0.14f;
        g.DrawEllipse(pen, p, p, d, d);                                  // cerchio della lente
        g.DrawLine(pen, p + d * 0.78f, p + d * 0.78f, s * 0.86f, s * 0.86f); // manico
    });

    /// <summary>Freccia circolare — "Aggiorna".</summary>
    public static Bitmap Refresh(int size = 24) => Make("refresh", size, (g, s) =>
    {
        using var pen = new Pen(Blue, Math.Max(2f, s / 11f)) { StartCap = LineCap.Round, EndCap = LineCap.Round };
        float m = s * 0.16f;
        var rect = new RectangleF(m, m, s - 2 * m, s - 2 * m);
        g.DrawArc(pen, rect, 30, 290);                                   // arco quasi completo
        // Punta di freccia alla fine dell'arco (in alto a destra)
        float cx = s / 2f, cy = s / 2f, r = (s - 2 * m) / 2f;
        double a = (30 + 290) * Math.PI / 180.0;
        float ex = cx + (float)Math.Cos(a) * r, ey = cy + (float)Math.Sin(a) * r;
        using var br = new SolidBrush(Blue);
        g.FillPolygon(br, new[]
        {
            new PointF(ex, ey - s * 0.16f),
            new PointF(ex + s * 0.14f, ey),
            new PointF(ex - s * 0.06f, ey + s * 0.06f),
        });
    });

    /// <summary>Quadrato arrotondato rosso — "Interrompi".</summary>
    public static Bitmap Stop(int size = 24) => Make("stop", size, (g, s) =>
    {
        using var br = new SolidBrush(Red);
        float m = s * 0.22f;
        using var path = Rounded(new RectangleF(m, m, s - 2 * m, s - 2 * m), s * 0.08f);
        g.FillPath(br, path);
    });

    /// <summary>Freccia verso il basso su un vassoio — "Esporta CSV".</summary>
    public static Bitmap Export(int size = 24) => Make("export", size, (g, s) =>
    {
        using var pen = new Pen(Blue, Math.Max(2f, s / 11f)) { StartCap = LineCap.Round };
        using var br = new SolidBrush(Blue);
        float cx = s / 2f;
        g.DrawLine(pen, cx, s * 0.18f, cx, s * 0.55f);                   // asta della freccia
        g.FillPolygon(br, new[]                                          // punta verso il basso
        {
            new PointF(cx - s * 0.16f, s * 0.5f),
            new PointF(cx + s * 0.16f, s * 0.5f),
            new PointF(cx, s * 0.72f),
        });
        g.DrawLine(pen, s * 0.22f, s * 0.82f, s * 0.78f, s * 0.82f);     // base / vassoio
    });

    /// <summary>Imbuto — "Applica filtro".</summary>
    public static Bitmap Filter(int size = 24) => Make("filter", size, (g, s) =>
    {
        using var br = new SolidBrush(Blue);
        g.FillPolygon(br, new[]
        {
            new PointF(s * 0.18f, s * 0.22f), new PointF(s * 0.82f, s * 0.22f),
            new PointF(s * 0.56f, s * 0.52f), new PointF(s * 0.56f, s * 0.80f),
            new PointF(s * 0.44f, s * 0.70f), new PointF(s * 0.44f, s * 0.52f),
        });
    });

    /// <summary>Barre crescenti (podio) — "Aree decisionali / Priorità".</summary>
    public static Bitmap Areas(int size = 24) => Make("areas", size, (g, s) =>
    {
        float w = s * 0.2f, baseY = s * 0.82f;
        Fill(g, Gold, s * 0.14f, baseY - s * 0.30f, w, s * 0.30f);       // 1ª barra
        Fill(g, Green, s * 0.40f, baseY - s * 0.52f, w, s * 0.52f);      // 2ª barra (più alta)
        Fill(g, Blue, s * 0.66f, baseY - s * 0.40f, w, s * 0.40f);       // 3ª barra
    });

    /// <summary>Griglia colorata 3×3 — "Dettaglio / Heatmap".</summary>
    public static Bitmap Heatmap(int size = 24) => Make("heatmap", size, (g, s) =>
    {
        Color[] cols =
        {
            Color.FromArgb(40, 40, 50), Red, Orange,
            Red, Orange, Gold,
            Orange, Gold, Green,
        };
        float m = s * 0.16f, cell = (s - 2 * m) / 3f, gap = cell * 0.12f;
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 3; c++)
                Fill(g, cols[r * 3 + c], m + c * cell, m + r * cell, cell - gap, cell - gap);
    });

    /// <summary>Diamante — "Caccia gemme".</summary>
    public static Bitmap Gem(int size = 24) => Make("gem", size, (g, s) =>
    {
        using var br = new SolidBrush(Cyan);
        using var pen = new Pen(Color.FromArgb(20, 110, 150), Math.Max(1f, s / 18f));
        var pts = new[]
        {
            new PointF(s * 0.5f, s * 0.18f), new PointF(s * 0.82f, s * 0.42f),
            new PointF(s * 0.5f, s * 0.84f), new PointF(s * 0.18f, s * 0.42f),
        };
        g.FillPolygon(br, pts);
        g.DrawPolygon(pen, pts);
        g.DrawLine(pen, s * 0.18f, s * 0.42f, s * 0.82f, s * 0.42f);     // faccetta orizzontale
        g.DrawLine(pen, s * 0.5f, s * 0.18f, s * 0.5f, s * 0.84f);       // faccetta verticale
    });

    /// <summary>Razzo — "Scoperta meme coin" / segnali ad alto potenziale.</summary>
    public static Bitmap Rocket(int size = 24, bool warm = false) => Make(warm ? "rocketw" : "rocket", size, (g, s) =>
    {
        var body = warm ? Orange : Purple;
        using var bodyBr = new SolidBrush(body);
        using var flameBr = new SolidBrush(Color.FromArgb(240, 160, 30));
        using var winBr = new SolidBrush(Color.White);
        // Corpo (capsula) con punta in alto
        g.FillPolygon(bodyBr, new[]
        {
            new PointF(s * 0.5f, s * 0.12f),
            new PointF(s * 0.66f, s * 0.40f),
            new PointF(s * 0.66f, s * 0.68f),
            new PointF(s * 0.34f, s * 0.68f),
            new PointF(s * 0.34f, s * 0.40f),
        });
        // Pinne laterali
        g.FillPolygon(bodyBr, new[] { new PointF(s * 0.34f, s * 0.52f), new PointF(s * 0.20f, s * 0.72f), new PointF(s * 0.34f, s * 0.68f) });
        g.FillPolygon(bodyBr, new[] { new PointF(s * 0.66f, s * 0.52f), new PointF(s * 0.80f, s * 0.72f), new PointF(s * 0.66f, s * 0.68f) });
        // Oblò
        g.FillEllipse(winBr, s * 0.42f, s * 0.38f, s * 0.16f, s * 0.16f);
        // Fiamma
        g.FillPolygon(flameBr, new[] { new PointF(s * 0.42f, s * 0.68f), new PointF(s * 0.58f, s * 0.68f), new PointF(s * 0.5f, s * 0.90f) });
    });

    /// <summary>Due anelli di catena — "On-Chain Monitor".</summary>
    public static Bitmap Chain(int size = 24) => Make("chain", size, (g, s) =>
    {
        using var pen = new Pen(Teal, Math.Max(2f, s / 9f)) { StartCap = LineCap.Round, EndCap = LineCap.Round };
        float w = s * 0.34f, h = s * 0.22f;
        using var p1 = Rounded(new RectangleF(s * 0.14f, s * 0.30f, w, h), h / 2);
        using var p2 = Rounded(new RectangleF(s * 0.52f, s * 0.48f, w, h), h / 2);
        g.DrawPath(pen, p1);
        g.DrawPath(pen, p2);
    });

    /// <summary>Grafico a barre — "Replica Python (Colab)".</summary>
    public static Bitmap Chart(int size = 24) => Make("chart", size, (g, s) =>
    {
        using var axis = new Pen(Slate, Math.Max(1.5f, s / 14f));
        g.DrawLine(axis, s * 0.18f, s * 0.16f, s * 0.18f, s * 0.84f);    // asse Y
        g.DrawLine(axis, s * 0.18f, s * 0.84f, s * 0.86f, s * 0.84f);    // asse X
        float baseY = s * 0.84f, w = s * 0.14f;
        Fill(g, Blue, s * 0.26f, baseY - s * 0.30f, w, s * 0.30f);
        Fill(g, Teal, s * 0.46f, baseY - s * 0.50f, w, s * 0.50f);
        Fill(g, Green, s * 0.66f, baseY - s * 0.38f, w, s * 0.38f);
    });

    /// <summary>Documento con angolo piegato — "Documentazione".</summary>
    public static Bitmap Document(int size = 24) => Make("doc", size, (g, s) =>
    {
        using var fill = new SolidBrush(Color.White);
        using var pen = new Pen(Slate, Math.Max(1.5f, s / 16f));
        using var line = new Pen(Slate, Math.Max(1f, s / 20f));
        float x = s * 0.22f, y = s * 0.14f, w = s * 0.5f, h = s * 0.72f, fold = s * 0.16f;
        var page = new[]
        {
            new PointF(x, y), new PointF(x + w - fold, y), new PointF(x + w, y + fold),
            new PointF(x + w, y + h), new PointF(x, y + h),
        };
        g.FillPolygon(fill, page);
        g.DrawPolygon(pen, page);
        for (int i = 0; i < 3; i++)                                      // righe di testo
            g.DrawLine(line, x + s * 0.06f, y + h * 0.4f + i * s * 0.12f, x + w - s * 0.06f, y + h * 0.4f + i * s * 0.12f);
    });

    /// <summary>Ingranaggio — "Impostazioni".</summary>
    public static Bitmap Gear(int size = 24) => Make("gear", size, (g, s) =>
    {
        using var br = new SolidBrush(Slate);
        float cx = s / 2f, cy = s / 2f, outer = s * 0.34f, tooth = s * 0.12f;
        var state = g.Save();
        g.TranslateTransform(cx, cy);
        for (int i = 0; i < 8; i++)                                      // 8 denti
        {
            g.FillRectangle(br, -tooth / 2, -outer - tooth * 0.5f, tooth, tooth * 1.4f);
            g.RotateTransform(45);
        }
        g.Restore(state);
        g.FillEllipse(br, cx - outer * 0.78f, cy - outer * 0.78f, outer * 1.56f, outer * 1.56f); // corpo
        using var hole = new SolidBrush(Color.Transparent);
        g.CompositingMode = CompositingMode.SourceCopy;                  // "buca" il centro
        g.FillEllipse(hole, cx - s * 0.12f, cy - s * 0.12f, s * 0.24f, s * 0.24f);
    });

    /// <summary>Segnalibro dorato con stella — "Scoperte salvate (watchlist)".</summary>
    public static Bitmap Bookmark(int size = 24) => Make("bookmark", size, (g, s) =>
    {
        using var br = new SolidBrush(Gold);
        using var star = new SolidBrush(Color.White);
        // Corpo del segnalibro con tacca a V in basso
        g.FillPolygon(br, new[]
        {
            new PointF(s * 0.28f, s * 0.14f), new PointF(s * 0.72f, s * 0.14f),
            new PointF(s * 0.72f, s * 0.86f), new PointF(s * 0.5f, s * 0.68f),
            new PointF(s * 0.28f, s * 0.86f),
        });
        // Piccola stella a 5 punte al centro
        var pts = new PointF[10];
        float cx = s * 0.5f, cy = s * 0.40f, ro = s * 0.13f, ri = s * 0.055f;
        for (int i = 0; i < 10; i++)
        {
            double ang = -Math.PI / 2 + i * Math.PI / 5;
            float r = (i % 2 == 0) ? ro : ri;
            pts[i] = new PointF(cx + (float)Math.Cos(ang) * r, cy + (float)Math.Sin(ang) * r);
        }
        g.FillPolygon(star, pts);
    });

    /// <summary>Cerchio blu con "i" — "Informazioni".</summary>
    public static Bitmap Info(int size = 24) => Make("info", size, (g, s) =>
    {
        using var br = new SolidBrush(Blue);
        using var wp = new SolidBrush(Color.White);
        g.FillEllipse(br, s * 0.14f, s * 0.14f, s * 0.72f, s * 0.72f);
        g.FillEllipse(wp, s * 0.46f, s * 0.28f, s * 0.08f, s * 0.08f);   // puntino della i
        g.FillRectangle(wp, s * 0.46f, s * 0.42f, s * 0.08f, s * 0.30f); // asta della i
    });

    // ----------------------------------------------------------------- helper
    /// <summary>Riempie un rettangolo con il colore indicato (scorciatoia leggibile).</summary>
    private static void Fill(Graphics g, Color c, float x, float y, float w, float h)
    {
        using var br = new SolidBrush(c);
        g.FillRectangle(br, x, y, w, h);
    }

    /// <summary>Costruisce un percorso rettangolare con angoli arrotondati di raggio <paramref name="r"/>.</summary>
    private static GraphicsPath Rounded(RectangleF rc, float r)
    {
        var p = new GraphicsPath();
        float d = r * 2;
        p.AddArc(rc.X, rc.Y, d, d, 180, 90);
        p.AddArc(rc.Right - d, rc.Y, d, d, 270, 90);
        p.AddArc(rc.Right - d, rc.Bottom - d, d, d, 0, 90);
        p.AddArc(rc.X, rc.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }
}
