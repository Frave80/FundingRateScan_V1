using System.Diagnostics;
// rev: fusione Colab + CMC/fallback grafico + gemme PRO
using System.Globalization;
using System.Text;
using FundingRateScan.Colab;
using FundingRateScan.Models;
using FundingRateScan.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// Finestra principale: menu superiori, barra strumenti, pannello indicatori
/// regolabili, tabella risultati e log di avanzamento.
/// </summary>
public class MainForm : AppForm
{
    private AppSettings _settings;
    private List<CoinResult> _results = new();
    private List<CoinResult> _colabResults = new();   // coin selezionate SOLO dalla pipeline Python/Colab
    private CancellationTokenSource? _cts;

    // Indicatori regolabili
    private NumericUpDown _numFunding = null!;
    private NumericUpDown _numPersistence = null!;
    private NumericUpDown _numVolGrowth = null!;
    private NumericUpDown _numOiGrowth = null!;
    private ComboBox _cmbView = null!;

    private DataGridView _grid = null!;
    private TextBox _log = null!;
    private ToolStripStatusLabel _status = null!;
    private ToolStripProgressBar _progress = null!;
    private ToolStripButton _btnScan = null!;
    private ToolStripButton _btnStop = null!;
    private ToolStripButton _btnExport = null!;

    public MainForm()
    {
        _settings = SettingsManager.Load();
        BuildUi();
        UpdateStatus("Pronto. Avvia una scansione da \"Scansione → Nuova scansione\".");
    }

    // ====================================================================== UI
    private void BuildUi()
    {
        Text = "FundingRateScan — Scanner funding rate multi-exchange";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1280, 760);
        MinimumSize = new Size(1000, 600);
        Font = new Font("Segoe UI", 9f);

        // Ordine di aggiunta importante per il docking: i controlli aggiunti per
        // ultimi vengono ancorati per primi al bordo esterno. Quindi: prima il
        // Fill (griglia), poi gli ancoraggi dal piu' interno al piu' esterno,
        // così il menu resta in cima senza coprire la prima riga.
        BuildGrid();            // Dock.Fill (centro)
        BuildIndicatorPanel();  // Dock.Top interno
        BuildToolbar();         // Dock.Top
        BuildMenu();            // Dock.Top esterno (in cima)
        BuildLog();             // Dock.Bottom interno
        BuildStatusBar();       // Dock.Bottom esterno (in fondo)
    }

    // =====================================================================
    //  MENU SUPERIORE
    //  Organizzato per sezioni: File, Scansione, Visualizza, On-Chain, Meme,
    //  Aiuto. Ogni voce ha un'icona coerente con quelle della toolbar e, dove
    //  utile, una scorciatoia da tastiera. È il punto d'accesso testuale a tutte
    //  le sezioni dell'applicazione (la toolbar ne è la controparte a icone).
    // =====================================================================
    private void BuildMenu()
    {
        var menu = new MenuStrip();

        // --- File -------------------------------------------------------------
        var mFile = new ToolStripMenuItem("&File");
        mFile.DropDownItems.Add(Mi("E&sci", null, Close, Keys.Alt | Keys.F4));

        // --- Scansione (funzioni del motore di scansione funding) -------------
        var mScan = new ToolStripMenuItem("S&cansione");
        mScan.DropDownItems.Add(Mi("&Nuova scansione...", Icons.Scan(16), NewScan, Keys.Control | Keys.N));
        mScan.DropDownItems.Add(Mi("&Aggiorna (ultimi parametri)", Icons.Refresh(16), () => RunScan(_settings.LastParameters), Keys.F5));
        mScan.DropDownItems.Add(new ToolStripSeparator());
        mScan.DropDownItems.Add(Mi("&Interrompi", Icons.Stop(16), () => _cts?.Cancel()));
        mScan.DropDownItems.Add(Mi("&Esporta CSV...", Icons.Export(16), ExportCsv));
        mScan.DropDownItems.Add(new ToolStripSeparator());
        mScan.DropDownItems.Add(Mi("&Replica Python (Colab)...", Icons.Chart(16), OpenColabReplica, Keys.Control | Keys.R));

        // --- Visualizza (filtri e viste di dettaglio) ------------------------
        var mView = new ToolStripMenuItem("&Visualizza");
        mView.DropDownItems.Add(Mi("Applica &filtro indicatori", Icons.Filter(16), ApplyFilter, Keys.Control | Keys.F));
        mView.DropDownItems.Add(Mi("&Ripristina indicatori predefiniti", Icons.Refresh(16), ResetIndicators));
        mView.DropDownItems.Add(new ToolStripSeparator());
        mView.DropDownItems.Add(Mi("&Aree decisionali / Priorità...", Icons.Areas(16), OpenDecisionAreas, Keys.Control | Keys.P));
        mView.DropDownItems.Add(Mi("&Dettaglio coin selezionata (heatmap)...", Icons.Heatmap(16), OpenDetail, Keys.Control | Keys.D));
        mView.DropDownItems.Add(new ToolStripSeparator());
        mView.DropDownItems.Add(Mi("Scoperte salvate (&watchlist)...", Icons.Bookmark(16), OpenWatchlist, Keys.Control | Keys.W));

        // --- On-Chain (monitor flussi e scoperta gemme) ----------------------
        var mOnChain = new ToolStripMenuItem("&On-Chain");
        mOnChain.DropDownItems.Add(Mi("&Monitor flussi on-chain...", Icons.Chain(16), OpenOnChain, Keys.Control | Keys.O));
        mOnChain.DropDownItems.Add(Mi("&Impostazioni provider...", Icons.Gear(16), OpenOnChainSettings));
        mOnChain.DropDownItems.Add(new ToolStripSeparator());
        mOnChain.DropDownItems.Add(Mi("&Caccia gemme (coin esplosive)...", Icons.Gem(16), OpenEarlyGems, Keys.Control | Keys.G));
        mOnChain.DropDownItems.Add(Mi("Caccia gemme &PRO (scanner 100x)...", Icons.Rocket(16, warm: true), OpenMoonGems, Keys.Control | Keys.Shift | Keys.G));

        // --- Meme (modulo di scoperta meme coin ad alto potenziale) ----------
        var mMeme = new ToolStripMenuItem("&Meme");
        mMeme.DropDownItems.Add(Mi("&Scoperta meme coin (alto potenziale)...", Icons.Rocket(16), OpenMemeDiscovery, Keys.Control | Keys.M));

        // --- Aiuto ------------------------------------------------------------
        var mHelp = new ToolStripMenuItem("&Aiuto");
        mHelp.DropDownItems.Add(Mi("&Guida rapida", Icons.Info(16), ShowHelp));
        mHelp.DropDownItems.Add(new ToolStripSeparator());
        mHelp.DropDownItems.Add(Mi("Documentazione Scanner &Gemme PRO (apri)...", Icons.Document(16), () => Services.DocResources.OpenGemDoc(this)));
        mHelp.DropDownItems.Add(Mi("&Scarica documentazione (.docx)...", Icons.Export(16), () => Services.DocResources.SaveGemDoc(this)));
        mHelp.DropDownItems.Add(new ToolStripSeparator());
        mHelp.DropDownItems.Add(Mi("&Info", Icons.Info(16), ShowAbout));

        menu.Items.AddRange(new ToolStripItem[] { mFile, mScan, mView, mOnChain, mMeme, mHelp });
        MainMenuStrip = menu;
        Controls.Add(menu);
    }

    /// <summary>
    /// Costruisce una voce di menu con testo, icona facoltativa, azione al click e
    /// scorciatoia facoltativa. Riduce la verbosità e mantiene uniforme lo stile.
    /// </summary>
    private static ToolStripMenuItem Mi(string text, Image? icon, Action onClick, Keys keys = Keys.None)
    {
        var item = new ToolStripMenuItem(text, icon, (_, _) => onClick());
        if (keys != Keys.None) item.ShortcutKeys = keys;
        return item;
    }

    // =====================================================================
    //  TOOLBAR A ICONE
    //  Sostituisce i vecchi pulsanti testuali con una barra di sole icone (24px),
    //  più pulita e immediata. Le voci sono raggruppate per sezione e separate da
    //  separatori verticali; l'etichetta di ciascuna è nel tooltip e nel menu.
    //  Gruppi: Scansione | Analisi | Scoperta | Strumenti | Aiuto.
    // =====================================================================
    private int _iconPx = 24;   // dimensione icone toolbar, scalata col DPI (BUG-EXTRA-007)

    private void BuildToolbar()
    {
        // Scala le icone in base al DPI del monitor: a 150%/200% restano nitide e proporzionate,
        // perché vengono disegnate alla dimensione in pixel corretta anziché a 24px fissi.
        _iconPx = Math.Max(20, (int)Math.Round(24 * (DeviceDpi / 96.0)));
        var tb = new ToolStrip
        {
            GripStyle = ToolStripGripStyle.Hidden,
            ImageScalingSize = new Size(_iconPx, _iconPx),
            Padding = new Padding(4, 2, 4, 2),
            RenderMode = ToolStripRenderMode.System,
        };

        // --- Sezione "Scansione" ---------------------------------------------
        _btnScan = TbButton(Icons.Scan(_iconPx), "Nuova scansione (Ctrl+N)", NewScan);
        var btnRefresh = TbButton(Icons.Refresh(_iconPx), "Aggiorna con gli ultimi parametri (F5)", () => RunScan(_settings.LastParameters));
        _btnStop = TbButton(Icons.Stop(_iconPx), "Interrompi la scansione", () => _cts?.Cancel());
        _btnStop.Enabled = false;
        _btnExport = TbButton(Icons.Export(_iconPx), "Esporta i risultati in CSV", ExportCsv);
        tb.Items.AddRange(new ToolStripItem[] { _btnScan, btnRefresh, _btnStop, _btnExport, new ToolStripSeparator() });

        // --- Sezione "Analisi" -----------------------------------------------
        tb.Items.Add(TbButton(Icons.Areas(_iconPx), "Aree decisionali / Priorità (Ctrl+P)", OpenDecisionAreas));
        tb.Items.Add(TbButton(Icons.Heatmap(_iconPx), "Dettaglio coin con heatmap (Ctrl+D)", OpenDetail));
        tb.Items.Add(TbButton(Icons.Bookmark(_iconPx), "Scoperte salvate — watchlist (Ctrl+W)", OpenWatchlist));
        tb.Items.Add(new ToolStripSeparator());

        // --- Sezione "Scoperta" ----------------------------------------------
        tb.Items.Add(TbButton(Icons.Gem(_iconPx), "Caccia gemme — coin esplosive (Ctrl+G)", OpenEarlyGems));
        tb.Items.Add(TbButton(Icons.Rocket(_iconPx, warm: true), "Caccia gemme PRO — scanner 100x (Ctrl+Shift+G)", OpenMoonGems));
        tb.Items.Add(TbButton(Icons.Rocket(_iconPx), "Scoperta meme coin ad alto potenziale (Ctrl+M)", OpenMemeDiscovery));
        tb.Items.Add(TbButton(Icons.Chain(_iconPx), "On-Chain Monitor — flussi e whale (Ctrl+O)", OpenOnChain));
        tb.Items.Add(new ToolStripSeparator());

        // --- Sezione "Strumenti" ---------------------------------------------
        tb.Items.Add(TbButton(Icons.Chart(_iconPx), "Replica Python (Colab) (Ctrl+R)", OpenColabReplica));
        tb.Items.Add(new ToolStripSeparator());

        // --- Sezione "Aiuto" -------------------------------------------------
        tb.Items.Add(TbButton(Icons.Document(_iconPx), "Documentazione Scanner Gemme PRO", () => Services.DocResources.OpenGemDoc(this)));
        tb.Items.Add(TbButton(Icons.Info(_iconPx), "Informazioni sull'applicazione", ShowAbout));

        Controls.Add(tb);
    }

    /// <summary>
    /// Crea un pulsante della toolbar a sola icona (senza testo) con tooltip descrittivo
    /// e azione al click. La descrizione testuale resta nel tooltip e nel menu.
    /// </summary>
    private ToolStripButton TbButton(Image icon, string tip, Action onClick)
    {
        var b = new ToolStripButton
        {
            Image = icon,
            ToolTipText = tip,
            DisplayStyle = ToolStripItemDisplayStyle.Image,
            ImageScaling = ToolStripItemImageScaling.None,
            AutoSize = false,
            Size = new Size(_iconPx + 12, _iconPx + 8),   // pulsante proporzionato all'icona (DPI)
        };
        b.Click += (_, _) => onClick();
        return b;
    }

    private void BuildIndicatorPanel()
    {
        var panel = new Panel { Dock = DockStyle.Top, Height = 70, Padding = new Padding(8, 6, 8, 6) };

        var lblTitle = new Label
        {
            Text = "Indicatori regolabili:",
            Location = new Point(10, 6),
            AutoSize = true,
            Font = UiFonts.Bold9
        };
        panel.Controls.Add(lblTitle);

        int x = 10;
        _numFunding = AddIndicator(panel, "Funding APR ≥ %", ref x, 0, 1000, 1, 10);
        _numPersistence = AddIndicator(panel, "Persistenza ≥ %", ref x, 0, 100, 0, 60);
        _numVolGrowth = AddIndicator(panel, "Crescita volume ≥ %", ref x, -100, 1000, 1, 5);
        _numOiGrowth = AddIndicator(panel, "Crescita OI ≥ %", ref x, -100, 1000, 1, 5);

        var lblView = new Label { Text = "Mostra", Location = new Point(x + 4, 30), AutoSize = true };
        panel.Controls.Add(lblView);
        _cmbView = new ComboBox
        {
            Location = new Point(x + 56, 27),
            Size = new Size(170, 24),
            DropDownStyle = ComboBoxStyle.DropDownList
        };
        _cmbView.Items.AddRange(new object[] { "Solo pattern attivo", "Pattern + da osservare", "Tutte le candidate" });
        _cmbView.SelectedIndex = 1;
        _cmbView.SelectedIndexChanged += (_, _) => ApplyFilter();
        panel.Controls.Add(_cmbView);

        var btnApply = new Button { Text = "Applica filtro", Location = new Point(x + 236, 25), Size = new Size(110, 28) };
        btnApply.Click += (_, _) => ApplyFilter();
        panel.Controls.Add(btnApply);

        Controls.Add(panel);
    }

    private NumericUpDown AddIndicator(Panel panel, string label, ref int x,
        decimal min, decimal max, int decimals, decimal def)
    {
        var lbl = new Label { Text = label, Location = new Point(x, 30), AutoSize = true };
        panel.Controls.Add(lbl);
        int w = TextRenderer.MeasureText(label, lbl.Font).Width + 6;
        var num = new NumericUpDown
        {
            Location = new Point(x + w, 27),
            Size = new Size(70, 24),
            Minimum = min,
            Maximum = max,
            DecimalPlaces = decimals,
            Value = def
        };
        panel.Controls.Add(num);
        x += w + 90;
        return num;
    }

    private void BuildGrid()
    {
        _grid = new DataGridView
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false,
            AllowUserToResizeColumns = true,
            AllowUserToResizeRows = false,
            BackgroundColor = SystemColors.Window,
            // Bordo esterno e righe-guida visibili: ogni colonna (compresa l'ultima « ★ »)
            // mostra il proprio delimitatore destro, così le intestazioni si leggono nette.
            BorderStyle = BorderStyle.FixedSingle,
            CellBorderStyle = DataGridViewCellBorderStyle.SingleVertical,
            GridColor = Color.FromArgb(208, 212, 222),
            RowTemplate = { Height = 24 },
            EnableHeadersVisualStyles = false
        };
        _grid.ColumnHeadersDefaultCellStyle.Font = UiFonts.Bold9;
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(40, 44, 60);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        _grid.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;
        _grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
        _grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        _grid.ColumnHeadersHeight = 46;

        AddCol("Base", "Coin", 65);
        AddCol("Name", "Nome", 120);
        AddCol("Fonte", "Fonte", 65);
        AddCol("StatusColab", "Status Colab", 90);
        AddCol("AprColab30", "APR Colab 30g", 85, "N1");
        AddCol("Stato", "Stato", 110);
        AddCol("Priorita", "Priorità", 70);
        AddCol("VolAttesa", "Vol. attesa", 80);
        AddCol("PotMeme", "Pot. meme", 70, "N0");   // dimensione Derivati del punteggio meme (cap. 10.2)
        AddCol("FundingApr", "Funding APR %", 95, "N1");
        AddCol("FundingRaw", "Funding %", 80, "N4");
        AddCol("Persistence", "Persistenza %", 90, "N0");
        AddCol("VolGrowth", "Δ Volume %", 85, "N1");
        AddCol("OiGrowth", "Δ OI %", 75, "N1");
        AddCol("Volume", "Volume 24h", 110, "N0");
        AddCol("Oi", "Open Interest", 110, "N0");
        AddCol("Price", "Prezzo", 85, "G");
        AddCol("Exchanges", "Exchange", 170);

        // Pulsante "Dettagli" per ogni riga: criteri di scelta + probabilità volatilità.
        var btnCol = new DataGridViewButtonColumn
        {
            Name = "Dettagli",
            HeaderText = "Dettagli",
            Text = "Dettagli",
            UseColumnTextForButtonValue = true,
            FillWeight = 80,
            MinimumWidth = 78
        };
        _grid.Columns.Add(btnCol);

        // Colonna watchlist « ★ »: spuntandola la coin viene salvata in modo permanente
        // (caricata all'avvio); le coin già salvate appaiono spuntate ed evidenziate.
        WatchlistColumn.Attach(_grid, WatchFromRow);

        // Rende la casella « ★ » ben visibile: larghezza minima adeguata, casella centrata
        // e delimitatore destro marcato (la colonna è l'ultima della griglia).
        if (_grid.Columns.Contains(WatchlistColumn.ColName))
        {
            var star = _grid.Columns[WatchlistColumn.ColName];
            star.MinimumWidth = 46;
            star.FillWeight = 38;
            star.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            star.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            star.HeaderCell.Style.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            star.DividerWidth = 2;
        }

        _grid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) OpenDetail(); };
        _grid.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { OpenDetail(); e.Handled = true; } };

        // Clic sul simbolo → CoinMarketCap; clic su "Dettagli" → criteri & volatilità.
        _grid.CellClick += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (_grid.Rows[e.RowIndex].Tag is not CoinResult r) return;
            switch (_grid.Columns[e.ColumnIndex].Name)
            {
                case "Base": OpenCoinMarketCap(r); break;
                case "Dettagli": OpenCriteria(r); break;
            }
        };
        _grid.CellMouseMove += (_, e) =>
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && _grid.Columns[e.ColumnIndex].Name == "Base")
                _grid.Cursor = Cursors.Hand;
            else
                _grid.Cursor = Cursors.Default;
        };

        Controls.Add(_grid);
    }

    /// <summary>
    /// Apre la pagina di quotazione della coin selezionata. La logica di
    /// instradamento (CoinMarketCap → TradingView/DEX Screener) è centralizzata in
    /// <see cref="QuoteLinks"/>, condivisa con tutte le altre finestre di ricerca.
    /// Le coin senza perpetuo di riferimento (es. solo-Colab) preferiscono DEX Screener.
    /// </summary>
    private void OpenCoinMarketCap(CoinResult r)
    {
        string name = string.IsNullOrWhiteSpace(r.Name) ? CoinNameProvider.GetName(r.Base) : r.Name;
        bool preferDex = r.Source == "Colab" || string.IsNullOrWhiteSpace(r.RepresentativeSymbol);
        _ = QuoteLinks.OpenSymbolAsync(r.Base, name, preferDex, new Progress<string>(UpdateStatus), CancellationToken.None);
    }

    /// <summary>Apre la finestra Dettagli: criteri di scelta + probabilità volatilità 30/60/120gg.</summary>
    private void OpenCriteria(CoinResult r)
    {
        using var f = new CoinCriteriaForm(r, ReadIndicators());
        f.ShowDialog(this);
    }

    private void OpenDetail()
    {
        if (_grid.CurrentRow?.Tag is not CoinResult r)
        {
            MessageBox.Show(this, "Seleziona una coin nella tabella.", "FundingRateScan",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (r.Source == "Colab")
        {
            // Nessun exchange di riferimento nativo: mostra i dettagli criteri/volatilità.
            OpenCriteria(r);
            return;
        }
        using var f = new CoinDetailForm(r, _settings);
        f.ShowDialog(this);
    }

    private void OpenOnChain()
    {
        // Pre-compila il simbolo con la coin selezionata (per correlare col funding).
        string? prefill = _grid.CurrentRow?.Tag is CoinResult r ? r.Base : null;
        var f = new OnChainForm(_settings, prefill);
        f.Show(this);   // non modale: può restare aperto accanto alla scansione funding
    }

    private void OpenOnChainSettings()
    {
        using var dlg = new OnChainSettingsForm(_settings.OnChain);
        if (dlg.ShowDialog(this) == DialogResult.OK)
            SettingsManager.Save(_settings);
    }

    private void OpenColabReplica()
    {
        var f = new ColabReplicaForm();
        f.Show(this);   // non modale: il confronto con Colab può restare aperto
    }

    private void OpenEarlyGems()
    {
        var f = new EarlyGemsForm();
        f.Show(this);   // non modale
    }

    private void OpenMemeDiscovery()
    {
        var f = new MemeDiscoveryForm(_settings);
        f.Show(this);   // non modale: convive con la scansione funding
    }

    private void OpenWatchlist()
    {
        var f = new WatchlistForm();
        f.Show(this);   // non modale: l'elenco delle scoperte resta consultabile durante le ricerche
    }

    private void OpenMoonGems()
    {
        var f = new MoonGemsForm(_settings);
        f.Show(this);   // non modale: lo scanner 100x può restare aperto
    }

    private void OpenDecisionAreas()
    {
        if (_results.Count(r => r.Classification != Classification.Neutral) == 0)
        {
            MessageBox.Show(this, "Esegui prima una scansione: nessuna coin candidata da valutare.",
                "Aree decisionali", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var f = new DecisionAreasForm(_results, ReadIndicators());
        f.ShowDialog(this);
    }

    private void AddCol(string name, string header, int width, string? format = null)
    {
        var c = new DataGridViewTextBoxColumn
        {
            Name = name,
            HeaderText = header,
            FillWeight = width,
            // Larghezza minima calcolata sull'intestazione (in grassetto) + margine: così
            // su schermi stretti le colonne non si comprimono fino a tagliare il testo, ma
            // compare una barra di scorrimento orizzontale. Su monitor ampi restano a Fill.
            MinimumWidth = Math.Max(width, MeasureHeader(header))
        };
        if (format != null)
        {
            c.DefaultCellStyle.Format = format;
            c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            c.DefaultCellStyle.FormatProvider = CultureInfo.InvariantCulture;
        }
        _grid.Columns.Add(c);
    }

    /// <summary>Larghezza in pixel necessaria a mostrare l'intestazione su una riga, con margine.</summary>
    private static int MeasureHeader(string header)
        => TextRenderer.MeasureText(header, UiFonts.Bold9).Width + 22;

    private void BuildLog()
    {
        _log = new TextBox
        {
            Dock = DockStyle.Bottom,
            Multiline = true,
            ScrollBars = ScrollBars.Vertical,
            ReadOnly = true,
            Height = 120,
            BackColor = Color.FromArgb(20, 22, 30),
            ForeColor = Color.Gainsboro,
            Font = new Font("Consolas", 9f)
        };
        Controls.Add(_log);
    }

    private void BuildStatusBar()
    {
        var strip = new StatusStrip();
        _status = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _progress = new ToolStripProgressBar { Style = ProgressBarStyle.Marquee, Visible = false, Width = 160 };
        strip.Items.Add(_status);
        strip.Items.Add(_progress);
        Controls.Add(strip);
    }

    // ================================================================= Azioni
    private void NewScan()
    {
        using var dlg = new DownloadForm(_settings);
        if (dlg.ShowDialog(this) == DialogResult.OK)
        {
            SyncIndicatorsFromParams(dlg.Parameters);
            RunScan(dlg.Parameters);
        }
    }

    private async void RunScan(ScanParameters p)
    {
        if (_cts != null)
        {
            MessageBox.Show(this, "Una scansione è già in corso.", "FundingRateScan",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        _cts = new CancellationTokenSource();
        SetBusy(true);
        _log.Clear();

        var progress = new Progress<string>(msg => AppendLog(msg));
        var service = new ScanService(_settings.Exchanges);

        try
        {
            // ----- Fase 1: scansione nativa (mostrata subito) -----------------
            UpdateStatus("Fase 1/2 — Scansione nativa in corso...");
            _results = await service.RunAsync(p, progress, _cts.Token);
            _colabResults.Clear();
            ApplyFilter();
            int active = _results.Count(r => r.Classification == Classification.PatternActive);
            int watch = _results.Count(r => r.Classification == Classification.Watch);
            UpdateStatus($"Fase 1 completata — {_results.Count} candidate | {active} pattern attivo | {watch} da osservare. Avvio fase Colab...");

            // ----- Fase 2: selezione Python (Colab), appesa in coda -----------
            AppendLog("");
            AppendLog("=== Fase 2: selezione Python (Colab) — CoinGecko top 500 + storico funding 365→180→90gg ===");
            var colabService = new ColabService();
            var colabResult = await colabService.RunAsync(progress, _cts.Token);
            MergeColab(colabResult);
            ApplyFilter();
            int both = _results.Count(r => r.Source == "Entrambi");
            UpdateStatus($"Completato — {_results.Count} native ({both} anche Colab) + {_colabResults.Count} solo Colab | {active} pattern attivo | {watch} da osservare");
        }
        catch (OperationCanceledException)
        {
            UpdateStatus("Scansione interrotta dall'utente.");
            AppendLog("** Interrotta **");
        }
        catch (Exception ex)
        {
            UpdateStatus("Errore durante la scansione.");
            AppendLog("ERRORE: " + ex.Message);
            MessageBox.Show(this, ex.Message, "Errore scansione",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _cts.Dispose();
            _cts = null;
            SetBusy(false);
        }
    }

    /// <summary>
    /// Fonde i risultati della pipeline Python (Colab) con quelli nativi:
    /// le coin presenti in entrambi vengono marcate "Entrambi" e arricchite con
    /// status/APR Colab; quelle trovate solo dal Colab vanno in _colabResults
    /// e compaiono in tabella DOPO le native.
    /// </summary>
    private void MergeColab(ColabResult cres)
    {
        _colabResults.Clear();
        foreach (var row in cres.Analysis)
        {
            var native = _results.FirstOrDefault(r =>
                r.Base.Equals(row.Symbol, StringComparison.OrdinalIgnoreCase));
            if (native != null)
            {
                native.Source = "Entrambi";
                native.ColabStatus = row.Status;
                native.ColabAprMedio = row.AprMedio;
                native.ColabApr30 = row.Apr30;
            }
            else
            {
                string fullName = CoinNameProvider.GetName(row.Symbol);
                _colabResults.Add(new CoinResult
                {
                    Base = row.Symbol,
                    Name = string.IsNullOrWhiteSpace(fullName) ? row.Name : fullName,
                    Source = "Colab",
                    ColabStatus = row.Status,
                    ColabAprMedio = row.AprMedio,
                    ColabApr30 = row.Apr30,
                    FundingApr = row.Apr30,   // uso interno (stima volatilità); non mostrato in colonna nativa
                    LastPrice = row.Prezzo,
                    Exchanges = cres.Frame.Sources.TryGetValue(row.Symbol, out var src) ? src : "",
                });
            }
        }
        int both = _results.Count(r => r.Source == "Entrambi");
        AppendLog($"Fusione completata: {both} coin in entrambe le selezioni, {_colabResults.Count} solo Colab (aggiunte in coda).");
    }

    private void ApplyFilter()
    {
        // Riclassifica con gli indicatori correnti senza riscaricare i dati.
        var p = ReadIndicators();
        foreach (var r in _results)
            ScanService.Classify(r, p);

        IEnumerable<CoinResult> view = _results;
        switch (_cmbView.SelectedIndex)
        {
            case 0: view = _results.Where(r => r.Classification == Classification.PatternActive); break;
            case 1: view = _results.Where(r => r.Classification != Classification.Neutral); break;
            default: break; // tutte
        }

        var ordered = view
            .OrderByDescending(r => r.Classification)
            .ThenByDescending(r => r.FundingApr)
            .ToList();

        // Prima le coin del nativo, poi quelle selezionate solo dal Python (Colab),
        // nell'ordine della pipeline Colab (status, poi APR 30gg).
        var merged = new List<CoinResult>(ordered);
        merged.AddRange(_colabResults);

        FillGrid(merged);
        UpdateStatus(_colabResults.Count > 0
            ? $"Mostrate {merged.Count} coin: {ordered.Count} native/entrambi (di {_results.Count} candidate) + {_colabResults.Count} solo Colab."
            : $"Mostrate {ordered.Count} coin (di {_results.Count} candidate).");
    }

    private void FillGrid(List<CoinResult> rows)
    {
        var p = ReadIndicators();
        _grid.SuspendLayout();
        _grid.Rows.Clear();
        foreach (var r in rows)
        {
            bool colabOnly = r.Source == "Colab";
            var a = colabOnly ? null : DecisionAdvisor.Evaluate(r, p);
            int i = _grid.Rows.Add(
                r.Base,
                r.Name,
                r.Source,
                r.ColabStatus,
                (object?)r.ColabApr30,
                colabOnly ? "—" : StatoText(r.Classification),
                colabOnly ? "—" : a!.PriorityLabel,
                colabOnly ? "—" : a!.VolatilityLabel,
                colabOnly ? null : (object)Meme.MemeScoringService.DerivativesDimension(r.FundingApr, r.PersistencePct, r.OiGrowthPct),
                colabOnly ? null : (object)r.FundingApr,
                colabOnly ? null : (object)(r.FundingRateRaw * 100.0),
                colabOnly ? null : (object)r.PersistencePct,
                colabOnly ? null : (object)r.VolGrowthPct,
                colabOnly ? null : (object)r.OiGrowthPct,
                colabOnly ? null : (object)r.Volume24hUsd,
                colabOnly ? null : (object)r.OpenInterestUsd,
                r.LastPrice,
                r.Exchanges);

            var row = _grid.Rows[i];
            row.Tag = r;

            // Simbolo come link (clic → CoinMarketCap)
            row.Cells["Base"].Style.ForeColor = Color.RoyalBlue;
            row.Cells["Base"].Style.Font = UiFonts.Underline9;
            row.Cells["Base"].ToolTipText = "Clic: apri su CoinMarketCap";

            // Status Colab evidenziato
            if (r.ColabStatus == "OPPORTUNITÀ")
            {
                row.Cells["StatusColab"].Style.ForeColor = Color.FromArgb(0, 120, 40);
                row.Cells["StatusColab"].Style.Font = UiFonts.Bold9;
            }
            else if (r.ColabStatus == "ESPLOSA" || r.ColabStatus == "POMPATA")
                row.Cells["StatusColab"].Style.ForeColor = Color.Firebrick;

            if (colabOnly)
            {
                // Riga proveniente solo dalla selezione Python: sfondo azzurro chiaro
                row.DefaultCellStyle.BackColor = Color.FromArgb(225, 238, 252);
                row.Cells["Fonte"].Style.Font = UiFonts.Bold9;
                row.Cells["Fonte"].Style.ForeColor = Color.FromArgb(20, 80, 160);
                continue;
            }

            // Priorità in grassetto; volatilità attesa Alta evidenziata in rosso
            row.Cells["Priorita"].Style.Font = UiFonts.Bold9;
            if (a!.Volatility == VolExpectation.Alta)
            {
                row.Cells["VolAttesa"].Style.ForeColor = Color.White;
                row.Cells["VolAttesa"].Style.BackColor = Color.Firebrick;
                row.Cells["VolAttesa"].Style.Font = UiFonts.Bold9;
            }
            else if (a.Volatility == VolExpectation.Media)
                row.Cells["VolAttesa"].Style.ForeColor = Color.FromArgb(180, 90, 0);

            switch (r.Classification)
            {
                case Classification.PatternActive:
                    row.DefaultCellStyle.BackColor = Color.FromArgb(214, 245, 214);
                    row.Cells["Stato"].Style.ForeColor = Color.FromArgb(0, 120, 40);
                    row.Cells["Stato"].Style.Font = UiFonts.Bold9;
                    break;
                case Classification.Watch:
                    row.DefaultCellStyle.BackColor = Color.FromArgb(255, 246, 214);
                    row.Cells["Stato"].Style.ForeColor = Color.FromArgb(170, 110, 0);
                    break;
            }
            if (r.FundingApr >= 100) row.Cells["FundingApr"].Style.ForeColor = Color.Firebrick;
        }
        _grid.ResumeLayout();

        // Aggiorna le caselle ★: spunta ed evidenzia le coin già presenti nella watchlist.
        WatchlistColumn.Refresh(_grid, WatchFromRow);
    }

    /// <summary>Costruisce la voce di watchlist dalla riga della tabella funding (Tag = CoinResult).</summary>
    private static Services.WatchedCoin? WatchFromRow(DataGridViewRow row)
    {
        if (row.Tag is not CoinResult r || string.IsNullOrWhiteSpace(r.Base)) return null;
        return new Services.WatchedCoin
        {
            Key = Services.WatchedCoin.MakeKey(null, null, r.Base),
            Symbol = r.Base,
            Name = r.Name,
            Source = r.Source == "Colab" ? "Colab" : "Funding",
        };
    }

    private static string StatoText(Classification c) => c switch
    {
        Classification.PatternActive => "● Pattern attivo",
        Classification.Watch => "○ Da osservare",
        _ => "Neutra"
    };

    private void ExportCsv()
    {
        if (_grid.Rows.Count == 0)
        {
            MessageBox.Show(this, "Nessun dato da esportare.", "FundingRateScan",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var sfd = new SaveFileDialog
        {
            Filter = "CSV (*.csv)|*.csv",
            FileName = $"fundingratescan_{DateTime.Now:yyyyMMdd_HHmm}.csv"
        };
        if (sfd.ShowDialog(this) != DialogResult.OK) return;

        // BUG-CORE-010 / T10: export pensato per Excel sul sistema dell'utente.
        // Separatore « ; » (separatore di elenco predefinito in Italia) e numeri formattati
        // nella CULTURA CORRENTE (decimale « , » in IT), così Excel li riconosce come numeri
        // e non come testo. (La Replica Colab usa invece InvariantCulture, perché serve a pandas.)
        var ci = CultureInfo.CurrentCulture;
        var sb = new StringBuilder();
        var headers = _grid.Columns.Cast<DataGridViewColumn>().Select(c => c.HeaderText);
        sb.AppendLine(string.Join(";", headers));
        foreach (DataGridViewRow row in _grid.Rows)
        {
            var cells = row.Cells.Cast<DataGridViewCell>()
                .Select(c => Convert.ToString(c.Value, ci)?.Replace(";", ",") ?? "");
            sb.AppendLine(string.Join(";", cells));
        }
        try
        {
            File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
            UpdateStatus($"Esportato: {sfd.FileName}");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore export", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    // ============================================================ Indicatori
    private ScanParameters ReadIndicators()
    {
        var p = _settings.LastParameters;
        return new ScanParameters
        {
            FundingAprThreshold = (double)_numFunding.Value,
            MinPersistencePct = (double)_numPersistence.Value,
            VolGrowthMinPct = (double)_numVolGrowth.Value,
            OiGrowthMinPct = (double)_numOiGrowth.Value,
            LookbackDays = p.LookbackDays,
            TopN = p.TopN,
            MinVolumeUsd = p.MinVolumeUsd,
        };
    }

    private void SyncIndicatorsFromParams(ScanParameters p)
    {
        _numFunding.Value = (decimal)Math.Clamp(p.FundingAprThreshold, 0, 1000);
        _numPersistence.Value = (decimal)Math.Clamp(p.MinPersistencePct, 0, 100);
        _numVolGrowth.Value = (decimal)Math.Clamp(p.VolGrowthMinPct, -100, 1000);
        _numOiGrowth.Value = (decimal)Math.Clamp(p.OiGrowthMinPct, -100, 1000);
    }

    private void ResetIndicators()
    {
        _numFunding.Value = 10;
        _numPersistence.Value = 60;
        _numVolGrowth.Value = 5;
        _numOiGrowth.Value = 5;
        _cmbView.SelectedIndex = 1;
        ApplyFilter();
    }

    // ================================================================ Helper
    private void SetBusy(bool busy)
    {
        _btnScan.Enabled = !busy;
        _btnExport.Enabled = !busy;
        _btnStop.Enabled = busy;
        _progress.Visible = busy;
    }

    private void AppendLog(string msg)
    {
        if (_log.InvokeRequired) { _log.BeginInvoke(() => AppendLog(msg)); return; }
        _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
    }

    private void UpdateStatus(string text)
    {
        if (_status.GetCurrentParent()?.InvokeRequired == true)
        { BeginInvoke(() => _status.Text = text); return; }
        _status.Text = text;
    }

    private void ShowHelp()
    {
        MessageBox.Show(this,
            "FundingRateScan cerca le coin con forte affollamento long (funding rate positivo e persistente)\n" +
            "su più exchange centralizzati e DEX, e verifica se mostrano volumi e open interest crescenti.\n\n" +
            "1. Scansione → Nuova scansione: scegli la soglia di funding, la persistenza, gli exchange e (opzionale) le API.\n" +
            "2. Le coin candidate vengono arricchite con lo storico e classificate:\n" +
            "   • Pattern attivo = funding persistente + volume crescente + OI crescente\n" +
            "   • Da osservare = funding persistente ma volume/OI non ancora confermati\n" +
            "3. Usa gli indicatori regolabili in alto per ricalibrare la classificazione senza riscaricare i dati.\n" +
            "4. Esporta i risultati in CSV.\n\n" +
            "Nota: i dati di mercato sono pubblici; le API key servono solo per limiti di rate più alti.",
            "Guida rapida", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void ShowAbout()
    {
        MessageBox.Show(this,
            "FundingRateScan 1.0\n\n" +
            "Scanner funding rate / volumi / open interest multi-exchange.\n" +
            "Exchange supportati: Binance, Bybit, OKX, Bitget, Gate.io, HTX, Hyperliquid.",
            "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        _cts?.Cancel();
        SettingsManager.Save(_settings);
        base.OnFormClosing(e);
    }
}
