using FundingRateScan.OnChain.Models;

namespace FundingRateScan.Forms;

/// <summary>Impostazioni del modulo on-chain: chiavi provider e soglie (parametri).</summary>
public sealed class OnChainSettingsForm : AppForm
{
    private readonly OnChainSettings _s;

    private TextBox _etherscan = null!, _ethplorer = null!, _moralis = null!, _bitquery = null!;
    private NumericUpDown _whale = null!, _millionaire = null!, _minScore = null!, _maxTransfers = null!, _topHolders = null!;

    public OnChainSettingsForm(OnChainSettings settings)
    {
        _s = settings;
        BuildUi();
        Load_();
    }

    private void BuildUi()
    {
        Text = "On-Chain — Impostazioni provider e soglie";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = MaximizeBox = false;
        ClientSize = new Size(560, 430);
        Font = new Font("Segoe UI", 9f);

        var gbKeys = new GroupBox { Text = "Chiavi API provider (memorizzate localmente)", Location = new Point(12, 10), Size = new Size(536, 170) };
        Controls.Add(gbKeys);
        int y = 26;
        _etherscan = AddKey(gbKeys, "Etherscan V2 (trasferimenti):", ref y, "Gratuita su etherscan.io/apis");
        _ethplorer = AddKey(gbKeys, "Ethplorer (holders, Ethereum):", ref y, "‘freekey’ funziona con limiti; chiave su ethplorer.io");
        _moralis = AddKey(gbKeys, "Moralis (opzionale):", ref y, "Provider alternativo multi-chain");
        _bitquery = AddKey(gbKeys, "Bitquery (opzionale):", ref y, "Provider alternativo / streaming");

        var gbTh = new GroupBox { Text = "Soglie (parametri)", Location = new Point(12, 188), Size = new Size(536, 180) };
        Controls.Add(gbTh);
        int y2 = 26;
        _whale = AddNum(gbTh, "Soglia whale (USD):", ref y2, 1000, 100_000_000, 50_000);
        _millionaire = AddNum(gbTh, "Wallet milionario (USD):", ref y2, 1000, 1_000_000_000, 50_000);
        _minScore = AddNum(gbTh, "Score minimo alert:", ref y2, 0, 100, 1);
        _maxTransfers = AddNum(gbTh, "Max trasferimenti per sync:", ref y2, 50, 1000, 50);
        _topHolders = AddNum(gbTh, "Numero top holder:", ref y2, 5, 100, 5);

        var ok = new Button { Text = "Salva", DialogResult = DialogResult.OK, Location = new Point(348, 388), Size = new Size(95, 30) };
        ok.Click += (_, _) => Save_();
        var cancel = new Button { Text = "Annulla", DialogResult = DialogResult.Cancel, Location = new Point(452, 388), Size = new Size(95, 30) };
        Controls.Add(ok); Controls.Add(cancel);
        AcceptButton = ok; CancelButton = cancel;
    }

    private TextBox AddKey(GroupBox gb, string label, ref int y, string tip)
    {
        var lbl = new Label { Text = label, Location = new Point(12, y + 3), AutoSize = true };
        var tb = new TextBox { Location = new Point(230, y), Size = new Size(296, 23), UseSystemPasswordChar = false };
        var tt = new ToolTip(); tt.SetToolTip(tb, tip); tt.SetToolTip(lbl, tip);
        gb.Controls.Add(lbl); gb.Controls.Add(tb);
        y += 34;
        return tb;
    }

    private NumericUpDown AddNum(GroupBox gb, string label, ref int y, decimal min, decimal max, decimal inc)
    {
        var lbl = new Label { Text = label, Location = new Point(12, y + 3), AutoSize = true };
        var num = new NumericUpDown
        {
            Location = new Point(230, y), Size = new Size(160, 23),
            Minimum = min, Maximum = max, Increment = inc, ThousandsSeparator = true
        };
        gb.Controls.Add(lbl); gb.Controls.Add(num);
        y += 30;
        return num;
    }

    private void Load_()
    {
        _etherscan.Text = _s.EtherscanApiKey;
        _ethplorer.Text = _s.EthplorerApiKey;
        _moralis.Text = _s.MoralisApiKey;
        _bitquery.Text = _s.BitqueryApiKey;
        _whale.Value = Clamp(_s.WhaleUsdThreshold, _whale);
        _millionaire.Value = Clamp(_s.MillionaireWalletUsdThreshold, _millionaire);
        _minScore.Value = Math.Clamp(_s.AlertMinScore, 0, 100);
        _maxTransfers.Value = Math.Clamp(_s.MaxTransfers, 50, 1000);
        _topHolders.Value = Math.Clamp(_s.TopHolders, 5, 100);
    }

    private void Save_()
    {
        _s.EtherscanApiKey = _etherscan.Text.Trim();
        _s.EthplorerApiKey = string.IsNullOrWhiteSpace(_ethplorer.Text) ? "freekey" : _ethplorer.Text.Trim();
        _s.MoralisApiKey = _moralis.Text.Trim();
        _s.BitqueryApiKey = _bitquery.Text.Trim();
        _s.WhaleUsdThreshold = _whale.Value;
        _s.MillionaireWalletUsdThreshold = _millionaire.Value;
        _s.AlertMinScore = (int)_minScore.Value;
        _s.MaxTransfers = (int)_maxTransfers.Value;
        _s.TopHolders = (int)_topHolders.Value;
    }

    private static decimal Clamp(decimal v, NumericUpDown n) => Math.Clamp(v, n.Minimum, n.Maximum);
}
