using System.Diagnostics;
using System.Globalization;
using System.Text;
using FundingRateScan.Gems;
using FundingRateScan.Models;
using FundingRateScan.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// Caccia gemme PRO — scanner professionale per nuove coin con potenziale 100x/200x
/// (stile PEPE · BONK · TURBO). Combina la scoperta DEX Screener con i controlli di
/// sicurezza multi-provider (gratuiti e con API key, ognuna nel campo abbinato al
/// fornitore) e genera per ogni coin un dossier di approfondimento.
/// </summary>
public sealed class MoonGemsForm : AppForm
{
    private static readonly CultureInfo Ci = CultureInfo.InvariantCulture;
    private static readonly (string disp, string id)[] Chains =
    {
        ("Tutte", "all"), ("Ethereum", "ethereum"), ("Solana", "solana"), ("Base", "base"),
        ("BNB Chain", "bsc"), ("Arbitrum", "arbitrum"), ("Polygon", "polygon")
    };

    private readonly AppSettings _settings;
    private CancellationTokenSource? _cts;
    private List<GemCandidate> _gems = new();

    private DataGridView _gridProviders = null!;
    private ComboBox _cmbChain = null!;
    private NumericUpDown _numMaxMcap = null!, _numMinLiq = null!, _numMinVol = null!, _numMaxAge = null!, _numDeep = null!;
    private CheckBox _chkExcludeHp = null!;
    private TextBox _txtSearch = null!, _log = null!;
    private Button _btnScan = null!, _btnStop = null!, _btnExport = null!, _btnSaveKeys = null!;
    private ToolStripStatusLabel _status = null!;
    private ToolStripProgressBar _progress = null!;
    private DataGridView _grid = null!;

    public MoonGemsForm(AppSettings settings)
    {
        _settings = settings;
        BuildUi();
        LoadProviders();
    }

    // ====================================================================== UI
    private void BuildUi()
    {
        Text = "Caccia gemme PRO — Scanner 100x/200x (stile PEPE · BONK · TURBO)";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1380, 840);
        MinimumSize = new Size(1100, 680);
        Font = new Font("Segoe UI", 9f);

        BuildGrid();         // Fill
        BuildFilters();      // Top (interno)
        BuildProviders();    // Top (esterno)
        BuildLog();          // Bottom
        BuildStatusBar();    // Bottom esterno
    }

    // ------------------------------------------------ Pannello provider/chiavi
    private void BuildProviders()
    {
        var grp = new GroupBox
        {
            Dock = DockStyle.Top,
            Height = 178,
            Text = "Fornitori di dati — servizi gratuiti e con API key (inserisci la chiave nel campo abbinato al fornitore)",
            Padding = new Padding(8, 4, 8, 6),
            Font = UiFonts.Bold9
        };

        _gridProviders = new DataGridView
        {
            Dock = DockStyle.Fill,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.CellSelect,
            MultiSelect = false,
            BackgroundColor = SystemColors.Window,
            BorderStyle = BorderStyle.None,
            EnableHeadersVisualStyles = false,
            Font = new Font("Segoe UI", 9f),
            ColumnHeadersHeight = 26
        };
        _gridProviders.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(40, 44, 60);
        _gridProviders.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _gridProviders.ColumnHeadersDefaultCellStyle.Font = UiFonts.Bold9;

        var colOn = new DataGridViewCheckBoxColumn { Name = "On", HeaderText = "Attivo", FillWeight = 45 };
        var colName = new DataGridViewTextBoxColumn { Name = "Provider", HeaderText = "Provider", FillWeight = 110, ReadOnly = true };
        var colType = new DataGridViewTextBoxColumn { Name = "Tipo", HeaderText = "Tipo", FillWeight = 70, ReadOnly = true };
        var colKey = new DataGridViewTextBoxColumn { Name = "ApiKey", HeaderText = "API key (se richiesta)", FillWeight = 220 };
        var colNote = new DataGridViewTextBoxColumn { Name = "Note", HeaderText = "Descrizione servizio", FillWeight = 420, ReadOnly = true };
        _gridProviders.Columns.AddRange(colOn, colName, colType, colKey, colNote);

        var pnlBtn = new Panel { Dock = DockStyle.Right, Width = 120, Padding = new Padding(6) };
        _btnSaveKeys = new Button { Text = "Salva chiavi", Location = new Point(6, 8), Size = new Size(104, 30) };
        _btnSaveKeys.Click += (_, _) => { SaveProviders(); _status.Text = "Chiavi e provider salvati."; };
        pnlBtn.Controls.Add(_btnSaveKeys);

        grp.Controls.Add(_gridProviders);
        grp.Controls.Add(pnlBtn);
        Controls.Add(grp);
    }

    private void LoadProviders()
    {
        _gridProviders.Rows.Clear();
        foreach (var (name, requiresKey, note) in GemProviders.Catalog)
        {
            var cfg = _settings.GemHunter.Providers.FirstOrDefault(p => p.Name == name)
                      ?? new GemProviderConfig { Name = name };
            int i = _gridProviders.Rows.Add(cfg.Enabled, name,
                requiresKey ? "API key" : "Gratuito", cfg.ApiKey, note);
            var row = _gridProviders.Rows[i];
            if (!requiresKey)
            {
                row.Cells["Tipo"].Style.ForeColor = Color.SeaGreen;
                if (name == GemProviders.DexScreener || name == GemProviders.GeckoTerminal
                    || name == GemProviders.Honeypot)
                    row.Cells["ApiKey"].ReadOnly = true;   // nessuna chiave prevista
            }
            else
                row.Cells["Tipo"].Style.ForeColor = Color.FromArgb(20, 80, 160);
        }
    }

    private void SaveProviders()
    {
        _gridProviders.EndEdit();
        foreach (DataGridViewRow row in _gridProviders.Rows)
        {
            var name = Convert.ToString(row.Cells["Provider"].Value) ?? "";
            var cfg = _settings.GemHunter.Providers.FirstOrDefault(p => p.Name == name);
            if (cfg == null)
            {
                cfg = new GemProviderConfig { Name = name };
                _settings.GemHunter.Providers.Add(cfg);
            }
            cfg.Enabled = row.Cells["On"].Value is true;
            cfg.ApiKey = Convert.ToString(row.Cells["ApiKey"].Value)?.Trim() ?? "";
        }
        _settings.GemHunter.DeepSecurityTopN = (int)_numDeep.Value;
        SettingsManager.Save(_settings);
    }

    // ------------------------------------------------------------ Filtri
    private void BuildFilters()
    {
        var p = new Panel { Dock = DockStyle.Top, Height = 86, Padding = new Padding(8, 6, 8, 4) };

        var lblChain = new Label { Text = "Chain:", Location = new Point(8, 11), AutoSize = true };
        _cmbChain = new ComboBox { Location = new Point(54, 7), Size = new Size(115, 24), DropDownStyle = ComboBoxStyle.DropDownList };
        foreach (var c in Chains) _cmbChain.Items.Add(c.disp);
        _cmbChain.SelectedIndex = 0;

        var lblMc = new Label { Text = "Max market cap $:", Location = new Point(182, 11), AutoSize = true };
        _numMaxMcap = Num(292, 8, 100_000, 1_000_000_000, 500_000, 10_000_000);

        var lblLiq = new Label { Text = "Min liquidità $:", Location = new Point(426, 11), AutoSize = true };
        _numMinLiq = Num(522, 8, 0, 100_000_000, 5_000, 15_000);

        var lblVol = new Label { Text = "Min volume 24h $:", Location = new Point(648, 11), AutoSize = true };
        _numMinVol = Num(760, 8, 0, 100_000_000, 10_000, 30_000);

        var lblAge = new Label { Text = "Max età (giorni):", Location = new Point(894, 11), AutoSize = true };
        _numMaxAge = Num(996, 8, 0, 365, 1, 45);
        _numMaxAge.ThousandsSeparator = false;
        _numMaxAge.Size = new Size(70, 24);

        var lblDeep = new Label { Text = "Sicurezza top N:", Location = new Point(1080, 11), AutoSize = true };
        _numDeep = Num(1180, 8, 5, 100, 5, Math.Clamp(_settingsDeepN(), 5, 100));
        _numDeep.ThousandsSeparator = false;
        _numDeep.Size = new Size(60, 24);

        // riga 2
        _chkExcludeHp = new CheckBox { Text = "Escludi honeypot", Location = new Point(10, 50), AutoSize = true, Checked = true };

        var lblSearch = new Label { Text = "Ricerca:", Location = new Point(150, 51), AutoSize = true };
        _txtSearch = new TextBox { Location = new Point(206, 48), Size = new Size(160, 23), PlaceholderText = "simbolo/parola (opz.)" };

        _btnScan = new Button { Text = "Scansiona gemme 100x", Location = new Point(390, 46), Size = new Size(160, 28) };
        _btnScan.Click += (_, _) => Run();
        _btnStop = new Button { Text = "Interrompi", Location = new Point(556, 46), Size = new Size(90, 28), Enabled = false };
        _btnStop.Click += (_, _) => _cts?.Cancel();
        _btnExport = new Button { Text = "Esporta CSV", Location = new Point(652, 46), Size = new Size(100, 28), Enabled = false };
        _btnExport.Click += (_, _) => ExportCsv();

        var lblHint = new Label
        {
            Text = "MoonScore = mercato 65% + sicurezza 35% · Potenziale = multiplo verso ~250M$ (classe TURBO) · pulsante Dossier = approfondimento completo",
            Location = new Point(770, 51), AutoSize = true, ForeColor = Color.DimGray, Font = new Font("Segoe UI", 8.25f)
        };

        p.Controls.AddRange(new Control[] { lblChain, _cmbChain, lblMc, _numMaxMcap, lblLiq, _numMinLiq,
            lblVol, _numMinVol, lblAge, _numMaxAge, lblDeep, _numDeep, _chkExcludeHp,
            lblSearch, _txtSearch, _btnScan, _btnStop, _btnExport, lblHint });
        Controls.Add(p);
    }

    private int _settingsDeepN() => _settings.GemHunter.DeepSecurityTopN <= 0 ? 25 : _settings.GemHunter.DeepSecurityTopN;

    private NumericUpDown Num(int x, int y, decimal min, decimal max, decimal inc, decimal val)
        => new() { Location = new Point(x, y), Size = new Size(118, 24), Minimum = min, Maximum = max, Increment = inc, Value = val, ThousandsSeparator = true };

    // ------------------------------------------------------------- Griglia
    private void BuildGrid()
    {
        _grid = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false, BackgroundColor = SystemColors.Window, BorderStyle = BorderStyle.None, EnableHeadersVisualStyles = false
        };
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(40, 44, 60);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.ColumnHeadersDefaultCellStyle.Font = UiFonts.Bold9;

        AddCol("Moon", 52, "N0");
        AddCol("Potenziale", 95, null);
        AddCol("Coin", 65, null);
        AddCol("Nome", 105, null);
        AddCol("Chain", 65, null);
        AddCol("Market Cap", 90, "N0");
        AddCol("Liquidità", 85, "N0");
        AddCol("Vol 24h", 90, "N0");
        AddCol("Δ1h%", 55, "N0");
        AddCol("Δ24h%", 60, "N0");
        AddCol("Buy%", 50, "N0");
        AddCol("Età g", 48, "N1");
        AddCol("Sicurezza", 70, null);
        AddCol("Holders", 70, "N0");
        AddCol("Tax B/S %", 75, null);
        AddCol("Rischio", 150, null);

        var btnCol = new DataGridViewButtonColumn
        {
            Name = "Dossier",
            HeaderText = "Dossier",
            Text = "Dossier",
            UseColumnTextForButtonValue = true,
            FillWeight = 65
        };
        _grid.Columns.Add(btnCol);

        // Colonna watchlist « ★ »: salva permanentemente la gemma scelta.
        WatchlistColumn.Attach(_grid, WatchFromRow);

        _grid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) OpenInBrowser(e.RowIndex); };
        _grid.CellClick += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (_grid.Columns[e.ColumnIndex].Name == "Dossier"
                && _grid.Rows[e.RowIndex].Tag is GemCandidate g)
                OpenDossier(g);
        };
        Controls.Add(_grid);
    }

    private void AddCol(string h, int w, string? fmt)
    {
        var c = new DataGridViewTextBoxColumn { HeaderText = h, FillWeight = w };
        if (fmt != null)
        {
            c.DefaultCellStyle.Format = fmt;
            c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            c.DefaultCellStyle.FormatProvider = Ci;
        }
        _grid.Columns.Add(c);
    }

    private void BuildLog()
    {
        _log = new TextBox
        {
            Dock = DockStyle.Bottom, Multiline = true, ReadOnly = true, Height = 90, ScrollBars = ScrollBars.Vertical,
            BackColor = Color.FromArgb(20, 22, 30), ForeColor = Color.Gainsboro, Font = new Font("Consolas", 9f)
        };
        Controls.Add(_log);
    }

    private void BuildStatusBar()
    {
        var strip = new StatusStrip();
        _status = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _progress = new ToolStripProgressBar { Style = ProgressBarStyle.Marquee, Visible = false, Width = 150 };
        strip.Items.Add(_status); strip.Items.Add(_progress);
        Controls.Add(strip);
    }

    // ============================================================== Logica
    private async void Run()
    {
        if (_cts != null) return;
        SaveProviders();   // le chiavi inserite valgono subito

        var sources = GemSource.TopBoosts | GemSource.LatestBoosts | GemSource.Profiles;
        if (_txtSearch.Text.Trim().Length > 0) sources |= GemSource.Search;

        var filter = new GemFilter
        {
            Chain = Chains[_cmbChain.SelectedIndex].id,
            MaxMarketCapUsd = (double)_numMaxMcap.Value,
            MinLiquidityUsd = (double)_numMinLiq.Value,
            MinVolume24hUsd = (double)_numMinVol.Value,
            MaxAgeDays = (double)_numMaxAge.Value,
            Sources = sources,
            SearchQuery = _txtSearch.Text.Trim(),
            MaxResults = 100,
        };

        _cts = new CancellationTokenSource();
        SetBusy(true);
        _log.Clear();
        var progress = new Progress<string>(AppendLog);

        try
        {
            _status.Text = "Fase 1/2 — Scoperta e scoring di mercato...";
            var scanner = new GemScannerService();
            var result = await scanner.ScanAsync(filter, progress, _cts.Token);
            _gems = result.Gems;

            _status.Text = "Fase 2/2 — Controlli di sicurezza multi-provider...";
            var enricher = new GemEnrichmentService();
            await enricher.EnrichAsync(_gems, _settings.GemHunter, (int)_numDeep.Value, progress, _cts.Token);

            if (_chkExcludeHp.Checked)
            {
                int before = _gems.Count;
                _gems = _gems.Where(g => g.IsHoneypot != true).ToList();
                if (before != _gems.Count) AppendLog($"Escluse {before - _gems.Count} honeypot.");
            }

            _gems = _gems.OrderByDescending(g => g.MoonScore).ToList();
            FillGrid();
            _status.Text = $"Trovate {_gems.Count} gemme (su {result.Scanned} candidati) — clic su Dossier per l'approfondimento.";
            _btnExport.Enabled = _gems.Count > 0;
        }
        catch (OperationCanceledException) { _status.Text = "Interrotto."; AppendLog("** Interrotto **"); }
        catch (Exception ex)
        {
            _status.Text = "Errore."; AppendLog("ERRORE: " + ex.Message);
            MessageBox.Show(this, ex.Message, "Caccia gemme PRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally { _cts.Dispose(); _cts = null; SetBusy(false); }
    }

    private void FillGrid()
    {
        _grid.SuspendLayout();
        _grid.Rows.Clear();
        foreach (var g in _gems)
        {
            string tax = g.BuyTaxPct.HasValue || g.SellTaxPct.HasValue
                ? $"{g.BuyTaxPct ?? 0:N1}/{g.SellTaxPct ?? 0:N1}" : "—";
            int i = _grid.Rows.Add(
                g.MoonScore, g.PotentialLabel, g.Symbol, g.Name, g.Chain,
                g.MarketCapUsd, g.LiquidityUsd, g.Volume24hUsd,
                g.PriceChg1h, g.PriceChg24h, g.BuyRatio * 100, g.AgeDays,
                g.SecurityScore.HasValue ? g.SecurityScore.Value.ToString("N0") : "—",
                (object?)g.HolderCount, tax, g.Risk);
            var row = _grid.Rows[i];
            row.Tag = g;

            row.Cells[0].Style.Font = UiFonts.Bold9;
            row.Cells[0].Style.BackColor = g.MoonScore >= 70 ? Color.FromArgb(214, 245, 214)
                : g.MoonScore >= 50 ? Color.FromArgb(235, 248, 235) : Color.White;

            if (g.PotentialX >= 100 && g.IsHoneypot != true)
            {
                row.Cells[1].Style.ForeColor = Color.FromArgb(0, 120, 40);
                row.Cells[1].Style.Font = UiFonts.Bold9;
            }
            ColorDelta(row.Cells[8], g.PriceChg1h);
            ColorDelta(row.Cells[9], g.PriceChg24h);

            if (g.SecurityScore.HasValue)
            {
                var c = g.SecurityScore >= 70 ? Color.FromArgb(0, 120, 40)
                    : g.SecurityScore >= 40 ? Color.FromArgb(180, 90, 0) : Color.Firebrick;
                row.Cells[12].Style.ForeColor = c;
                row.Cells[12].Style.Font = UiFonts.Bold9;
            }
            if (g.IsHoneypot == true)
            {
                row.DefaultCellStyle.BackColor = Color.MistyRose;
                row.Cells[1].Style.ForeColor = Color.Firebrick;
            }
            if (g.Risk != "—") row.Cells[15].Style.ForeColor = Color.Firebrick;
        }
        _grid.ResumeLayout();
        WatchlistColumn.Refresh(_grid, WatchFromRow);   // spunta le gemme già salvate
    }

    /// <summary>Costruisce la voce di watchlist dalla riga (Tag = GemCandidate): token on-chain con contratto.</summary>
    private static Services.WatchedCoin? WatchFromRow(DataGridViewRow row)
    {
        if (row.Tag is not GemCandidate g) return null;
        return new Services.WatchedCoin
        {
            Key = Services.WatchedCoin.MakeKey(g.Chain, g.TokenAddress, g.Symbol),
            Symbol = g.Symbol, Name = g.Name, Chain = g.Chain, Contract = g.TokenAddress, Url = g.Url,
            Source = "Gemme PRO", Note = $"MoonScore {g.MoonScore:N0}",
        };
    }

    private static void ColorDelta(DataGridViewCell c, double v)
        => c.Style.ForeColor = v > 0 ? Color.SeaGreen : v < 0 ? Color.Firebrick : Color.Gray;

    private void OpenDossier(GemCandidate g)
    {
        using var f = new GemReportForm(g);
        f.ShowDialog(this);
    }

    private void OpenInBrowser(int rowIndex)
    {
        if (_grid.Rows[rowIndex].Tag is GemCandidate g && g.Url.StartsWith("http"))
        {
            try { Process.Start(new ProcessStartInfo { FileName = g.Url, UseShellExecute = true }); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Apri link", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }

    private void ExportCsv()
    {
        if (_gems.Count == 0) return;
        using var sfd = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = $"gemme_pro_{DateTime.Now:yyyyMMdd_HHmm}.csv" };
        if (sfd.ShowDialog(this) != DialogResult.OK) return;
        var sb = new StringBuilder();
        sb.AppendLine("moon_score,potential,symbol,name,chain,market_cap_usd,liquidity_usd,volume_24h_usd," +
                      "chg_1h,chg_24h,buy_pct,age_days,security_score,holders,buy_tax,sell_tax,honeypot,risk,token,url");
        foreach (var g in _gems)
            sb.AppendLine(string.Join(",",
                F(g.MoonScore), Q(g.PotentialLabel), Q(g.Symbol), Q(g.Name), g.Chain,
                F(g.MarketCapUsd), F(g.LiquidityUsd), F(g.Volume24hUsd),
                F(g.PriceChg1h), F(g.PriceChg24h), F(g.BuyRatio * 100), F(g.AgeDays),
                g.SecurityScore.HasValue ? F(g.SecurityScore.Value) : "",
                g.HolderCount?.ToString(Ci) ?? "",
                g.BuyTaxPct.HasValue ? F(g.BuyTaxPct.Value) : "",
                g.SellTaxPct.HasValue ? F(g.SellTaxPct.Value) : "",
                g.IsHoneypot == true ? "1" : g.IsHoneypot == false ? "0" : "",
                Q(g.Risk), g.TokenAddress, g.Url));
        try { File.WriteAllText(sfd.FileName, sb.ToString(), new UTF8Encoding(true)); _status.Text = "Esportato: " + sfd.FileName; }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Export", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private static string F(double v) => v.ToString("0.####", Ci);
    private static string Q(string s) => s.Contains(',') || s.Contains('"') ? $"\"{s.Replace("\"", "\"\"")}\"" : s;

    private void SetBusy(bool busy)
    {
        _btnScan.Enabled = !busy; _btnStop.Enabled = busy; _progress.Visible = busy;
        _gridProviders.Enabled = !busy; _btnSaveKeys.Enabled = !busy;
        if (busy) _btnExport.Enabled = false;
    }

    private void AppendLog(string msg)
    {
        if (_log.InvokeRequired) { _log.BeginInvoke(() => AppendLog(msg)); return; }
        _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        _cts?.Cancel();
        SaveProviders();
        base.OnFormClosing(e);
    }
}
