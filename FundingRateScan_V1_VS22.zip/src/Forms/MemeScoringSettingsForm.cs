using FundingRateScan.Meme;

namespace FundingRateScan.Forms;

/// <summary>
/// Impostazioni del punteggio meme (Fase 7 del documento): pesi delle quattro dimensioni,
/// soglie di stato, filtro sopravvivenza e parametri di profondità. Coerente con la
/// filosofia dello scanner: pesi e soglie nelle mani dell'utente (cap. 8.4 / 9.9).
/// </summary>
public sealed class MemeScoringSettingsForm : AppForm
{
    private readonly MemeScoringSettings _s;

    private NumericUpDown _wLiq = null!, _wAdo = null!, _wDer = null!, _wSoc = null!;
    private NumericUpDown _high = null!, _emerg = null!, _riskExcl = null!, _minAge = null!, _maxMcap = null!, _topN = null!;
    private Label _sum = null!;

    public MemeScoringSettingsForm(MemeScoringSettings settings)
    {
        _s = settings;
        BuildUi();
        Load_();
    }

    private void BuildUi()
    {
        Text = "Impostazioni punteggio meme";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = MaximizeBox = false;
        ClientSize = new Size(440, 430);
        Font = new Font("Segoe UI", 9f);

        var gbW = new GroupBox { Text = "Pesi delle dimensioni (%)", Location = new Point(12, 10), Size = new Size(416, 130) };
        Controls.Add(gbW);
        int y = 26;
        _wLiq = AddNum(gbW, "Liquidità & mercato:", ref y, 0, 100, 5);
        _wAdo = AddNum(gbW, "Adozione on-chain:", ref y, 0, 100, 5);
        int y2 = 26;
        _wDer = AddNum(gbW, "Derivati (funding/OI):", ref y2, 0, 100, 5, 210);
        _wSoc = AddNum(gbW, "Momentum sociale:", ref y2, 0, 100, 5, 210);
        _sum = new Label { Location = new Point(16, 100), AutoSize = true, ForeColor = Color.DimGray };
        gbW.Controls.Add(_sum);
        foreach (var n in new[] { _wLiq, _wAdo, _wDer, _wSoc }) n.ValueChanged += (_, _) => UpdateSum();

        var gbT = new GroupBox { Text = "Soglie di stato e filtri", Location = new Point(12, 150), Size = new Size(416, 218) };
        Controls.Add(gbT);
        int y3 = 26;
        _high = AddNum(gbT, "★ Alto potenziale ≥:", ref y3, 0, 100, 5);
        _emerg = AddNum(gbT, "◆ Emergente ≥:", ref y3, 0, 100, 5);
        _riskExcl = AddNum(gbT, "✕ Rischio se penalità <:", ref y3, 0, 1, (decimal)0.05, 0, 2);
        _minAge = AddNum(gbT, "Età min. sopravvivenza (h):", ref y3, 0, 168, 1);
        _maxMcap = AddNum(gbT, "Max market cap ($):", ref y3, 100_000, 1_000_000_000, 500_000);
        _topN = AddNum(gbT, "Top N approfondimento:", ref y3, 5, 100, 5);

        var ok = new Button { Text = "Salva", DialogResult = DialogResult.OK, Location = new Point(232, 378), Size = new Size(95, 30) };
        ok.Click += (_, _) => Save_();
        var cancel = new Button { Text = "Annulla", DialogResult = DialogResult.Cancel, Location = new Point(333, 378), Size = new Size(95, 30) };
        var reset = new Button { Text = "Predefiniti", Location = new Point(12, 378), Size = new Size(100, 30) };
        reset.Click += (_, _) => LoadDefaults();
        Controls.Add(ok); Controls.Add(cancel); Controls.Add(reset);
        AcceptButton = ok; CancelButton = cancel;
    }

    private NumericUpDown AddNum(GroupBox gb, string label, ref int y, decimal min, decimal max, decimal inc, int x = 0, int dec = 0)
    {
        var lbl = new Label { Text = label, Location = new Point(x + 12, y + 3), AutoSize = true, UseMnemonic = false };
        var num = new NumericUpDown
        {
            Location = new Point(x + 12 + 168, y), Size = new Size(28 + (dec > 0 ? 30 : 0) + 30, 23),
            Minimum = min, Maximum = max, Increment = inc, DecimalPlaces = dec, ThousandsSeparator = max >= 100000
        };
        num.Width = max >= 100000 ? 110 : 70;
        gb.Controls.Add(lbl); gb.Controls.Add(num);
        y += 30;
        return num;
    }

    private void UpdateSum()
    {
        decimal tot = _wLiq.Value + _wAdo.Value + _wDer.Value + _wSoc.Value;
        _sum.Text = $"Somma pesi: {tot:N0}% (i pesi vengono normalizzati automaticamente)";
        _sum.ForeColor = tot == 100 ? Color.SeaGreen : Color.DimGray;
    }

    private void Load_()
    {
        _wLiq.Value = (decimal)_s.WLiquidity; _wAdo.Value = (decimal)_s.WAdoption;
        _wDer.Value = (decimal)_s.WDerivatives; _wSoc.Value = (decimal)_s.WSocial;
        _high.Value = (decimal)_s.HighThreshold; _emerg.Value = (decimal)_s.EmergingThreshold;
        _riskExcl.Value = (decimal)_s.RiskExcludeBelow; _minAge.Value = (decimal)_s.MinAgeHoursSurvival;
        _maxMcap.Value = Math.Clamp((decimal)_s.MaxMarketCapUsd, _maxMcap.Minimum, _maxMcap.Maximum);
        _topN.Value = Math.Clamp(_s.DeepTopN, 5, 100);
        UpdateSum();
    }

    private void LoadDefaults()
    {
        var d = new MemeScoringSettings();
        _wLiq.Value = (decimal)d.WLiquidity; _wAdo.Value = (decimal)d.WAdoption;
        _wDer.Value = (decimal)d.WDerivatives; _wSoc.Value = (decimal)d.WSocial;
        _high.Value = (decimal)d.HighThreshold; _emerg.Value = (decimal)d.EmergingThreshold;
        _riskExcl.Value = (decimal)d.RiskExcludeBelow; _minAge.Value = (decimal)d.MinAgeHoursSurvival;
        _maxMcap.Value = (decimal)d.MaxMarketCapUsd; _topN.Value = d.DeepTopN;
        UpdateSum();
    }

    private void Save_()
    {
        _s.WLiquidity = (double)_wLiq.Value; _s.WAdoption = (double)_wAdo.Value;
        _s.WDerivatives = (double)_wDer.Value; _s.WSocial = (double)_wSoc.Value;
        _s.HighThreshold = (double)_high.Value; _s.EmergingThreshold = (double)_emerg.Value;
        _s.RiskExcludeBelow = (double)_riskExcl.Value; _s.MinAgeHoursSurvival = (double)_minAge.Value;
        _s.MaxMarketCapUsd = (double)_maxMcap.Value; _s.DeepTopN = (int)_topN.Value;
    }
}
