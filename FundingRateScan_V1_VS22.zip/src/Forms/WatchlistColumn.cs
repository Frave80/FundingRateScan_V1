using FundingRateScan.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// Aggiunge a una griglia dei risultati una colonna con casella di spunta « ★ »: spuntandola,
/// la coin della riga viene salvata in modo permanente nella watchlist (vedi WatchlistService);
/// togliendo la spunta viene rimossa. Le coin già salvate (« già scoperte ») compaiono con la
/// casella già spuntata e la cella evidenziata, così l'utente le riconosce a colpo d'occhio.
///
/// Ogni form passa una funzione « extract » che ricava la WatchedCoin dalla riga (dal suo Tag),
/// perché ogni vista ha dati diversi (funding, gemme, meme).
/// </summary>
public static class WatchlistColumn
{
    public const string ColName = "Watch";
    private static readonly Color SavedTint = Color.FromArgb(255, 247, 214);   // ambra tenue = già scoperta

    // Evita che l'impostazione programmatica delle spunte (in Refresh) riattivi il salvataggio.
    private static bool _suppress;

    /// <summary>Collega la colonna watchlist alla griglia. Va chiamato una sola volta, dopo aver definito le colonne.</summary>
    public static void Attach(DataGridView grid, Func<DataGridViewRow, WatchedCoin?> extract)
    {
        // La griglia diventa modificabile solo per la casella: tutte le altre colonne restano in sola lettura.
        grid.ReadOnly = false;
        foreach (DataGridViewColumn c in grid.Columns) c.ReadOnly = true;

        var col = new DataGridViewCheckBoxColumn
        {
            Name = ColName,
            HeaderText = "★",
            ToolTipText = "Salva la coin nella watchlist (scoperte)",
            FillWeight = 26,
            ReadOnly = false,
            Resizable = DataGridViewTriState.False,
        };
        grid.Columns.Add(col);

        // Commit immediato della spunta (senza dover spostare il focus).
        grid.CurrentCellDirtyStateChanged += (_, _) =>
        {
            if (grid.IsCurrentCellDirty) grid.CommitEdit(DataGridViewDataErrorContexts.Commit);
        };

        grid.CellValueChanged += (_, e) =>
        {
            if (_suppress || e.RowIndex < 0) return;
            if (grid.Columns[e.ColumnIndex].Name != ColName) return;
            var row = grid.Rows[e.RowIndex];
            var wc = extract(row);
            if (wc == null) return;
            bool isChecked = row.Cells[e.ColumnIndex].Value is bool b && b;
            if (isChecked) WatchlistService.Add(wc);
            else WatchlistService.Remove(wc.Key);
            MarkCell(row.Cells[e.ColumnIndex], isChecked, wc.Key);
        };
    }

    /// <summary>
    /// Reimposta lo stato delle caselle in base alla watchlist corrente. Va chiamato dopo aver
    /// riempito la griglia: le coin già salvate risultano spuntate ed evidenziate (« già scoperta »).
    /// </summary>
    public static void Refresh(DataGridView grid, Func<DataGridViewRow, WatchedCoin?> extract)
    {
        if (!grid.Columns.Contains(ColName)) return;
        int idx = grid.Columns[ColName].Index;
        _suppress = true;
        try
        {
            foreach (DataGridViewRow row in grid.Rows)
            {
                if (row.IsNewRow) continue;
                var wc = extract(row);
                if (wc == null) { row.Cells[idx].Value = false; continue; }
                bool saved = WatchlistService.Contains(wc.Key);
                row.Cells[idx].Value = saved;
                MarkCell(row.Cells[idx], saved, wc.Key);
            }
        }
        finally { _suppress = false; }
    }

    /// <summary>Evidenzia la cella e imposta un tooltip che ricorda quando la coin è stata scoperta.</summary>
    private static void MarkCell(DataGridViewCell cell, bool saved, string key)
    {
        if (saved)
        {
            cell.Style.BackColor = SavedTint;
            var when = WatchlistService.SavedAt(key);
            cell.ToolTipText = when.HasValue
                ? $"Già scoperta — salvata il {when.Value.ToLocalTime():dd/MM/yyyy}"
                : "Salvata nella watchlist";
        }
        else
        {
            cell.Style.BackColor = Color.Empty;
            cell.ToolTipText = "Salva la coin nella watchlist";
        }
    }
}
