using FundingRateScan.Colab;
using FundingRateScan.Models;
using FundingRateScan.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// Finestra "Dettagli" di una coin: elenca tutti i criteri di scelta applicati
/// (indicatori nativi + pipeline Colab/Python) con valori, soglie ed esito,
/// e la probabilità stimata di alta volatilità a 30, 60 e 120 giorni.
/// </summary>
public class CoinCriteriaForm : AppForm
{
    private readonly CoinResult _r;
    private readonly ScanParameters _p;

    public CoinCriteriaForm(CoinResult r, ScanParameters p)
    {
        _r = r;
        _p = p;
        BuildUi();
    }

    private void BuildUi()
    {
        Text = $"Dettagli — {_r.Base}" + (string.IsNullOrWhiteSpace(_r.Name) ? "" : $" ({_r.Name})");
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(720, 640);
        MinimumSize = new Size(620, 520);
        Font = new Font("Segoe UI", 9f);

        var est = VolatilityEstimator.Estimate(_r);

        // ---------------- Motivazioni + disclaimer (in fondo) ----------------
        var txtReasons = new TextBox
        {
            Dock = DockStyle.Bottom,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            Height = 150,
            BackColor = Color.FromArgb(20, 22, 30),
            ForeColor = Color.Gainsboro,
            Font = new Font("Consolas", 9f),
            Text = "MOTIVAZIONI:" + Environment.NewLine +
                   string.Join(Environment.NewLine, est.Reasons.Select(s => "  • " + s)) +
                   Environment.NewLine + Environment.NewLine +
                   "NOTA: stima euristica (hazard giornaliero " + est.DailyHazardPct.ToString("N2") +
                   "%/g, score " + est.Score.ToString("N2") + "). 'Alta volatilità' = movimento brusco/squeeze " +
                   "ben oltre l'oscillazione tipica. È un supporto di ricerca probabilistico, non un consiglio finanziario."
        };

        // ---------------- Probabilità volatilità ----------------
        var gridProb = MakeGrid(110);
        gridProb.Columns.Add(Col("Orizzonte", 120));
        gridProb.Columns.Add(Col("Probabilità alta volatilità", 160, right: true));
        gridProb.Columns.Add(Col("Valutazione", 120));
        AddProbRow(gridProb, "30 giorni", est.P30);
        AddProbRow(gridProb, "60 giorni", est.P60);
        AddProbRow(gridProb, "120 giorni", est.P120);

        var lblProb = Header("Probabilità di alta volatilità (stima)");

        // ---------------- Criteri di scelta ----------------
        var gridCrit = MakeGrid(0);
        gridCrit.Dock = DockStyle.Fill;
        gridCrit.Columns.Add(Col("Criterio", 240));
        gridCrit.Columns.Add(Col("Valore", 110, right: true));
        gridCrit.Columns.Add(Col("Soglia", 110, right: true));
        gridCrit.Columns.Add(Col("Esito", 90));
        FillCriteria(gridCrit);

        var lblCrit = Header($"Criteri di scelta applicati — Fonte: {_r.Source}");

        lblProb.Dock = DockStyle.Bottom;
        gridProb.Dock = DockStyle.Bottom;

        // Docking: i controlli aggiunti per ultimi vengono ancorati per primi
        // al bordo esterno (come in MainForm). Layout finale, dall'alto in basso:
        // lblCrit / gridCrit (Fill) / lblProb / gridProb / txtReasons.
        Controls.Add(gridCrit);     // Fill (innermost)
        Controls.Add(lblCrit);      // Top
        Controls.Add(lblProb);      // Bottom (innermost: sopra gridProb)
        Controls.Add(gridProb);     // Bottom
        Controls.Add(txtReasons);   // Bottom (outermost: in fondo)
    }

    // ------------------------------------------------------------- Criteri
    private void FillCriteria(DataGridView g)
    {
        bool native = _r.Source != "Colab";
        bool colab = _r.Source != "Nativo";

        // --- Selezione nativa (scanner multi-exchange, funding corrente) ---
        AddSection(g, "SELEZIONE NATIVA (funding corrente multi-exchange)");
        if (native)
        {
            AddCrit(g, "Funding APR ≥ soglia", $"{_r.FundingApr:N1}%", $"{_p.FundingAprThreshold:N1}%",
                _r.FundingApr >= _p.FundingAprThreshold);
            AddCrit(g, "Volume 24h ≥ minimo", _r.Volume24hUsd.ToString("N0") + " $", _p.MinVolumeUsd.ToString("N0") + " $",
                _r.Volume24hUsd >= _p.MinVolumeUsd);
            if (_r.Enriched)
            {
                AddCrit(g, "Persistenza funding positivo", $"{_r.PersistencePct:N0}%", $"{_p.MinPersistencePct:N0}%",
                    _r.PersistencePct >= _p.MinPersistencePct);
                AddCrit(g, "Crescita volume (1ª vs 2ª metà)", $"{_r.VolGrowthPct:+0.0;-0.0}%", $"{_p.VolGrowthMinPct:N1}%",
                    _r.VolGrowthPct >= _p.VolGrowthMinPct);
                AddCrit(g, "Crescita open interest", $"{_r.OiGrowthPct:+0.0;-0.0}%", $"{_p.OiGrowthMinPct:N1}%",
                    _r.OiGrowthPct >= _p.OiGrowthMinPct);
            }
            else
                AddInfo(g, "Storico nativo", "non arricchito", "—");
            AddInfo(g, "Classificazione nativa", _r.Classification switch
            {
                Classification.PatternActive => "● Pattern attivo",
                Classification.Watch => "○ Da osservare",
                _ => "Neutra"
            }, "—");
            AddInfo(g, "Exchange", _r.Exchanges, "—");
        }
        else
            AddInfo(g, "Non selezionata dal nativo", "fuori soglia funding/volume o assente sugli exchange", "—");

        // --- Selezione Python / Colab (storico funding) ---
        AddSection(g, "SELEZIONE PYTHON / COLAB (storico funding, CoinGecko top " + ColabConfig.TopNCoins + ")");
        if (colab && (!string.IsNullOrEmpty(_r.ColabStatus) || _r.ColabAprMedio.HasValue))
        {
            if (_r.ColabAprMedio.HasValue)
                AddCrit(g, "APR medio storico ≥ soglia", $"{_r.ColabAprMedio:N1}%", $"{ColabConfig.HighAprThresh:N0}%",
                    _r.ColabAprMedio >= ColabConfig.HighAprThresh);
            if (_r.ColabApr30.HasValue)
                AddCrit(g, "APR ultimi 30gg ≥ soglia", $"{_r.ColabApr30:N1}%", $"{ColabConfig.HighAprRecent:N0}%",
                    _r.ColabApr30 >= ColabConfig.HighAprRecent);
            AddInfo(g, "Giorni minimi di dati", $"≥ {ColabConfig.MinDataDays}", "—");
            AddInfo(g, "Reazione prezzo (per lo status)", $"±{ColabConfig.PriceReactionPct:N0}% su 30gg/1a", "—");
            AddInfo(g, "Status Colab", _r.ColabStatus, "—");
        }
        else
            AddInfo(g, "Non selezionata dal Colab", "fuori top " + ColabConfig.TopNCoins + " CoinGecko o sotto soglie APR", "—");
    }

    // ------------------------------------------------------------- Helper UI
    private static Label Header(string text) => new()
    {
        Text = text,
        Dock = DockStyle.Top,
        Height = 26,
        Padding = new Padding(8, 6, 0, 0),
        Font = UiFonts.Bold9,
        BackColor = Color.FromArgb(40, 44, 60),
        ForeColor = Color.White
    };

    private static DataGridView MakeGrid(int height)
    {
        var g = new DataGridView
        {
            ReadOnly = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false,
            AllowUserToResizeRows = false,
            BackgroundColor = SystemColors.Window,
            BorderStyle = BorderStyle.None,
            EnableHeadersVisualStyles = false,
            ColumnHeadersHeight = 26
        };
        if (height > 0) g.Height = height;
        g.ColumnHeadersDefaultCellStyle.Font = UiFonts.Bold9;
        return g;
    }

    private static DataGridViewTextBoxColumn Col(string header, int weight, bool right = false)
    {
        var c = new DataGridViewTextBoxColumn { HeaderText = header, FillWeight = weight };
        if (right) c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        return c;
    }

    private static void AddSection(DataGridView g, string title)
    {
        int i = g.Rows.Add(title, "", "", "");
        var row = g.Rows[i];
        row.DefaultCellStyle.BackColor = Color.FromArgb(230, 232, 240);
        row.DefaultCellStyle.Font = UiFonts.Bold9;
    }

    private static void AddCrit(DataGridView g, string name, string value, string threshold, bool pass)
    {
        int i = g.Rows.Add(name, value, threshold, pass ? "✓ superato" : "✗ non superato");
        var cell = g.Rows[i].Cells[3];
        cell.Style.ForeColor = pass ? Color.FromArgb(0, 120, 40) : Color.Firebrick;
        cell.Style.Font = UiFonts.Bold9;
    }

    private static void AddInfo(DataGridView g, string name, string value, string threshold)
    {
        int i = g.Rows.Add(name, value, threshold, "info");
        g.Rows[i].Cells[3].Style.ForeColor = Color.Gray;
    }

    private static void AddProbRow(DataGridView g, string horizon, double p)
    {
        int i = g.Rows.Add(horizon, $"{p:N1}%", VolatilityEstimate.Label(p));
        var row = g.Rows[i];
        var color = p >= 50 ? Color.Firebrick : p >= 30 ? Color.FromArgb(180, 90, 0) : Color.FromArgb(0, 120, 40);
        row.Cells[1].Style.ForeColor = color;
        row.Cells[1].Style.Font = UiFonts.Bold95;
        row.Cells[2].Style.ForeColor = color;
    }
}
