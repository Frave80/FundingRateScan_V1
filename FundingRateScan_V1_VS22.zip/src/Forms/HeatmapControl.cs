using System.Drawing.Drawing2D;

namespace FundingRateScan.Forms;

/// <summary>Tavolozza colori della heatmap.</summary>
public enum HeatmapPalette
{
    /// <summary>Divergente centrata sullo zero (verde = positivo, rosso = negativo) — stile Coinglass per i funding.</summary>
    DivergingFunding,
    /// <summary>Nero → rosso: nero = funding basso/negativo, rosso acceso = funding elevato (long).</summary>
    FundingBlackRed,
    /// <summary>Sequenziale (blu → ciano → giallo) per grandezze sempre positive (volume, open interest).</summary>
    Sequential
}

/// <summary>
/// Heatmap a celle disegnata con GDI+: matrice righe × colonne colorata in base
/// al valore, con etichette di asse e barra colore. Tooltip sul passaggio del mouse.
/// </summary>
public class HeatmapControl : Control
{
    private double?[,]? _cells;
    private string[] _rowLabels = Array.Empty<string>();
    private string[] _colLabels = Array.Empty<string>();
    private double _min, _max, _maxAbs;
    private bool _hasData;

    // Geometria calcolata nell'ultimo OnPaint, usata per l'hit-testing del tooltip.
    private RectangleF _grid;
    private float _cellW, _cellH;
    private int _rows, _cols;

    private readonly ToolTip _tip = new();
    private int _lastRow = -1, _lastCol = -1;

    public HeatmapPalette Palette { get; set; } = HeatmapPalette.DivergingFunding;
    public string Unit { get; set; } = "";
    public string EmptyText { get; set; } = "Nessun dato storico disponibile per questa coin.";

    private static readonly Color BgColor = Color.FromArgb(20, 22, 30);
    private static readonly Color EmptyCell = Color.FromArgb(34, 37, 48);

    public HeatmapControl()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint
                 | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = BgColor;
        Font = new Font("Segoe UI", 8f);
    }

    /// <summary>Imposta i dati. cells[row, col] = valore (null = cella vuota).</summary>
    public void SetData(double?[,] cells, string[] rowLabels, string[] colLabels)
    {
        _cells = cells;
        _rowLabels = rowLabels;
        _colLabels = colLabels;
        _rows = cells.GetLength(0);
        _cols = cells.GetLength(1);

        _min = double.MaxValue; _max = double.MinValue; _hasData = false;
        foreach (var v in cells)
        {
            if (!v.HasValue) continue;
            _hasData = true;
            if (v.Value < _min) _min = v.Value;
            if (v.Value > _max) _max = v.Value;
        }
        if (!_hasData) { _min = 0; _max = 0; }
        _maxAbs = Math.Max(Math.Abs(_min), Math.Abs(_max));
        if (_maxAbs <= 0) _maxAbs = 1;

        Invalidate();
    }

    /// <summary>Svuota la heatmap mostrando il testo di stato corrente (EmptyText).</summary>
    public void Clear()
    {
        _cells = null;
        _hasData = false;
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(BgColor);

        if (_cells == null || !_hasData)
        {
            TextRenderer.DrawText(g, EmptyText, Font, ClientRectangle,
                Color.Gray, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            return;
        }

        g.SmoothingMode = SmoothingMode.None;

        const int left = 52, top = 10, right = 14, bottom = 56;
        float gw = Width - left - right;
        float gh = Height - top - bottom;
        if (gw < 20 || gh < 20) return;

        _grid = new RectangleF(left, top, gw, gh);
        _cellW = gw / _cols;
        _cellH = gh / _rows;

        // Celle
        for (int r = 0; r < _rows; r++)
        {
            for (int c = 0; c < _cols; c++)
            {
                var rect = new RectangleF(
                    left + c * _cellW, top + r * _cellH,
                    Math.Max(1, _cellW - 0.6f), Math.Max(1, _cellH - 0.6f));
                var v = _cells[r, c];
                using var br = new SolidBrush(v.HasValue ? ColorFor(v.Value) : EmptyCell);
                g.FillRectangle(br, rect);
            }
        }

        using var lblBrush = new SolidBrush(Color.FromArgb(170, 175, 190));
        using var labelFont = new Font("Segoe UI", 7.5f);

        // Etichette righe (a sinistra)
        int rowStep = Math.Max(1, (int)Math.Ceiling(_rows / Math.Max(1f, gh / 14f)));
        for (int r = 0; r < _rows; r += rowStep)
        {
            if (r >= _rowLabels.Length) break;
            float y = top + r * _cellH + _cellH / 2 - 6;
            TextRenderer.DrawText(g, _rowLabels[r], labelFont,
                new Rectangle(0, (int)y, left - 4, 14), Color.FromArgb(170, 175, 190),
                TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
        }

        // Etichette colonne (in basso)
        int colStep = Math.Max(1, (int)Math.Ceiling(_cols / Math.Max(1f, gw / 60f)));
        for (int c = 0; c < _cols; c += colStep)
        {
            if (c >= _colLabels.Length) break;
            float x = left + c * _cellW;
            TextRenderer.DrawText(g, _colLabels[c], labelFont,
                new Rectangle((int)x - 2, (int)(top + gh + 4), 60, 14),
                Color.FromArgb(150, 155, 170), TextFormatFlags.Left);
        }

        DrawColorbar(g, left, Height - 26, gw);
    }

    private void DrawColorbar(Graphics g, int x, int y, float w)
    {
        int barW = (int)Math.Min(w, 240);
        var rect = new Rectangle(x, y, barW, 12);
        double barLo = Palette switch
        {
            HeatmapPalette.DivergingFunding => -_maxAbs,
            HeatmapPalette.FundingBlackRed => 0,
            _ => _min
        };
        double barHi = Palette switch
        {
            HeatmapPalette.DivergingFunding => _maxAbs,
            HeatmapPalette.FundingBlackRed => _max > 0 ? _max : 1,
            _ => _max
        };
        for (int i = 0; i < barW; i++)
        {
            double t = (double)i / Math.Max(1, barW - 1);   // 0..1
            using var pen = new Pen(ColorFor(barLo + t * (barHi - barLo)));
            g.DrawLine(pen, x + i, y, x + i, y + 12);
        }
        using var f = new Font("Segoe UI", 7.5f);
        var lc = Color.FromArgb(150, 155, 170);
        string lo = Palette == HeatmapPalette.DivergingFunding ? $"{-_maxAbs:0.#}{Unit}" : $"{barLo:0.#}{Unit}";
        string mid = Palette == HeatmapPalette.DivergingFunding ? "0" : $"{(barLo + barHi) / 2:0.#}{Unit}";
        string hi = Palette == HeatmapPalette.DivergingFunding ? $"+{_maxAbs:0.#}{Unit}" : $"{barHi:0.#}{Unit}";
        TextRenderer.DrawText(g, lo, f, new Point(x, y + 12), lc);
        TextRenderer.DrawText(g, mid, f, new Point(x + barW / 2 - 8, y + 12), lc);
        TextRenderer.DrawText(g, hi, f, new Point(x + barW - 34, y + 12), lc);
    }

    /// <summary>Mappa un valore a un colore secondo la tavolozza scelta.</summary>
    private Color ColorFor(double v)
    {
        if (Palette == HeatmapPalette.FundingBlackRed)
        {
            // Nero (basso/negativo) → rosso acceso (funding elevato).
            double posMax = _max > 0 ? _max : 1;
            double t = Math.Clamp(v / posMax, 0, 1);
            t = Math.Pow(t, 0.6);  // schiarisce i valori medi per renderli leggibili
            return Lerp(Color.FromArgb(12, 12, 14), Color.FromArgb(255, 45, 30), t);
        }
        if (Palette == HeatmapPalette.DivergingFunding)
        {
            var neutral = Color.FromArgb(28, 31, 42);
            if (v >= 0)
            {
                double f = Math.Min(1, v / _maxAbs);
                return Lerp(neutral, Color.FromArgb(0, 205, 110), Math.Sqrt(f));
            }
            else
            {
                double f = Math.Min(1, -v / _maxAbs);
                return Lerp(neutral, Color.FromArgb(235, 58, 52), Math.Sqrt(f));
            }
        }
        else
        {
            double range = _max - _min;
            double t = range > 0 ? (v - _min) / range : 0;
            return t < 0.5
                ? Lerp(Color.FromArgb(22, 34, 70), Color.FromArgb(0, 190, 210), t * 2)
                : Lerp(Color.FromArgb(0, 190, 210), Color.FromArgb(240, 220, 70), (t - 0.5) * 2);
        }
    }

    private static Color Lerp(Color a, Color b, double t)
    {
        t = Math.Clamp(t, 0, 1);
        return Color.FromArgb(
            (int)(a.R + (b.R - a.R) * t),
            (int)(a.G + (b.G - a.G) * t),
            (int)(a.B + (b.B - a.B) * t));
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_cells == null || !_hasData || !_grid.Contains(e.Location)) { return; }

        int c = (int)((e.X - _grid.X) / _cellW);
        int r = (int)((e.Y - _grid.Y) / _cellH);
        if (r < 0 || r >= _rows || c < 0 || c >= _cols) return;
        if (r == _lastRow && c == _lastCol) return;
        _lastRow = r; _lastCol = c;

        var v = _cells[r, c];
        string rl = r < _rowLabels.Length ? _rowLabels[r] : "";
        string cl = c < _colLabels.Length ? _colLabels[c] : "";
        string text = v.HasValue
            ? $"{cl} {rl}\n{v.Value:0.###}{Unit}"
            : $"{cl} {rl}\n(nessun dato)";
        _tip.SetToolTip(this, text);
    }
}
