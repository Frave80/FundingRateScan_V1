using System.Text.Json;
using FundingRateScan.Services;

namespace FundingRateScan.Gems;

/// <summary>
/// Arricchimento PRO delle gemme: controlli di sicurezza del contratto e dati holders
/// da provider gratuiti (GoPlus, Honeypot.is, GeckoTerminal) e a chiave (Birdeye, Moralis),
/// quindi calcolo del punteggio sicurezza, del MoonScore finale e del potenziale 100x/200x.
/// </summary>
public sealed class GemEnrichmentService
{
    // Mappa chainId DexScreener → id chain GoPlus (EVM)
    private static readonly Dictionary<string, string> GoPlusChain = new(StringComparer.OrdinalIgnoreCase)
    {
        ["ethereum"] = "1", ["bsc"] = "56", ["polygon"] = "137",
        ["arbitrum"] = "42161", ["base"] = "8453", ["optimism"] = "10", ["avalanche"] = "43114"
    };

    // Mappa chainId DexScreener → network GeckoTerminal
    private static readonly Dictionary<string, string> GtNet = new(StringComparer.OrdinalIgnoreCase)
    {
        ["ethereum"] = "eth", ["solana"] = "solana", ["bsc"] = "bsc",
        ["base"] = "base", ["arbitrum"] = "arbitrum", ["polygon"] = "polygon_pos"
    };

    // Mappa chainId DexScreener → chain Moralis (EVM)
    private static readonly Dictionary<string, string> MoralisChain = new(StringComparer.OrdinalIgnoreCase)
    {
        ["ethereum"] = "eth", ["bsc"] = "bsc", ["polygon"] = "polygon",
        ["arbitrum"] = "arbitrum", ["base"] = "base"
    };

    // Chain supportate da Honeypot.is
    private static readonly Dictionary<string, string> HoneypotChain = new(StringComparer.OrdinalIgnoreCase)
    {
        ["ethereum"] = "1", ["bsc"] = "56", ["base"] = "8453"
    };

    /// <summary>
    /// Arricchisce le prime <paramref name="topN"/> gemme con i controlli di sicurezza
    /// (le restanti ricevono comunque MoonScore/potenziale, senza dati sicurezza).
    /// </summary>
    public async Task EnrichAsync(List<GemCandidate> gems, GemHunterSettings cfg, int topN,
        IProgress<string> log, CancellationToken ct)
    {
        bool On(string name) => cfg.Providers.FirstOrDefault(p => p.Name == name)?.Enabled ?? false;
        string Key(string name) => cfg.Providers.FirstOrDefault(p => p.Name == name)?.ApiKey?.Trim() ?? "";

        int deep = Math.Min(topN, gems.Count);
        log.Report($"Approfondimento sicurezza sulle prime {deep} gemme...");

        for (int i = 0; i < gems.Count; i++)
        {
            ct.ThrowIfCancellationRequested();
            var g = gems[i];
            if (i < deep && g.TokenAddress.Length > 0)
            {
                var sources = new List<string>();
                try
                {
                    // 1) GoPlus Security (gratuito; chiave opzionale)
                    if (On(GemProviders.GoPlus))
                    {
                        bool ok = g.Chain.Equals("solana", StringComparison.OrdinalIgnoreCase)
                            ? await GoPlusSolanaAsync(g, Key(GemProviders.GoPlus), ct)
                            : await GoPlusEvmAsync(g, Key(GemProviders.GoPlus), ct);
                        if (ok) sources.Add("GoPlus");
                    }

                    // 2) Honeypot.is (fallback EVM gratuito)
                    if (On(GemProviders.Honeypot) && g.IsHoneypot == null
                        && HoneypotChain.ContainsKey(g.Chain))
                    {
                        if (await HoneypotAsync(g, ct)) sources.Add("Honeypot.is");
                    }

                    // 3) GeckoTerminal (gratuito): presenza CoinGecko
                    if (On(GemProviders.GeckoTerminal) && GtNet.ContainsKey(g.Chain))
                    {
                        if (await GeckoTerminalAsync(g, ct)) sources.Add("GeckoTerminal");
                    }

                    // 4) Birdeye (chiave): holders Solana
                    if (On(GemProviders.Birdeye) && Key(GemProviders.Birdeye).Length > 0
                        && g.Chain.Equals("solana", StringComparison.OrdinalIgnoreCase))
                    {
                        if (await BirdeyeAsync(g, Key(GemProviders.Birdeye), ct)) sources.Add("Birdeye");
                    }

                    // 5) Moralis (chiave): verifica contratto / spam EVM
                    if (On(GemProviders.Moralis) && Key(GemProviders.Moralis).Length > 0
                        && MoralisChain.ContainsKey(g.Chain))
                    {
                        if (await MoralisAsync(g, Key(GemProviders.Moralis), ct)) sources.Add("Moralis");
                    }
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
                catch { /* singola gemma: arricchimento parziale */ }

                g.SecuritySources = string.Join("+", sources);
                ComputeSecurityScore(g);

                if ((i + 1) % 5 == 0 || i + 1 == deep)
                    log.Report($"  Sicurezza {i + 1}/{deep}...");
                await Task.Delay(150, ct);   // rispetto dei rate limit gratuiti
            }

            ComputeMoonScore(g);
        }
    }

    // ================================================================ GoPlus
    private static async Task<bool> GoPlusEvmAsync(GemCandidate g, string apiKey, CancellationToken ct)
    {
        if (!GoPlusChain.TryGetValue(g.Chain, out var chainId)) return false;
        var url = $"https://api.gopluslabs.io/api/v1/token_security/{chainId}?contract_addresses={g.TokenAddress}";
        using var doc = await HttpHelper.GetJsonAsync(url, HeaderIf(apiKey, "Authorization"), ct);
        if (doc == null || !doc.RootElement.TryGetProperty("result", out var res)
            || res.ValueKind != JsonValueKind.Object) return false;

        JsonElement tok = default;
        bool found = false;
        foreach (var prop in res.EnumerateObject())
            if (prop.Name.Equals(g.TokenAddress, StringComparison.OrdinalIgnoreCase))
            { tok = prop.Value; found = true; break; }
        if (!found) return false;

        g.IsHoneypot ??= Flag(tok, "is_honeypot");
        g.IsOpenSource ??= Flag(tok, "is_open_source");
        g.IsMintable ??= Flag(tok, "is_mintable");
        g.BuyTaxPct ??= Frac(tok, "buy_tax");
        g.SellTaxPct ??= Frac(tok, "sell_tax");

        long hc = HttpHelper.GetLong(tok, "holder_count");
        if (hc > 0) g.HolderCount ??= hc;

        // Concentrazione dei top holder (l'array è già ordinato per quota)
        if (tok.TryGetProperty("holders", out var holders) && holders.ValueKind == JsonValueKind.Array)
        {
            double sum = 0; int n = 0;
            foreach (var h in holders.EnumerateArray())
            {
                if (n++ >= 10) break;
                sum += HttpHelper.GetDouble(h, "percent");
            }
            if (n > 0) g.Top10HoldersPct ??= Math.Round(sum * 100.0, 1);
        }

        // Quota LP bloccata/bruciata
        if (tok.TryGetProperty("lp_holders", out var lps) && lps.ValueKind == JsonValueKind.Array)
        {
            double locked = 0; bool any = false;
            foreach (var h in lps.EnumerateArray())
            {
                any = true;
                if (HttpHelper.GetDouble(h, "is_locked") >= 1)
                    locked += HttpHelper.GetDouble(h, "percent");
            }
            if (any) g.LpLockedPct ??= Math.Round(locked * 100.0, 1);
        }
        return true;
    }

    private static async Task<bool> GoPlusSolanaAsync(GemCandidate g, string apiKey, CancellationToken ct)
    {
        var url = $"https://api.gopluslabs.io/api/v1/solana/token_security?contract_addresses={g.TokenAddress}";
        using var doc = await HttpHelper.GetJsonAsync(url, HeaderIf(apiKey, "Authorization"), ct);
        if (doc == null || !doc.RootElement.TryGetProperty("result", out var res)
            || res.ValueKind != JsonValueKind.Object) return false;

        JsonElement tok = default;
        bool found = false;
        foreach (var prop in res.EnumerateObject())
            if (prop.Name.Equals(g.TokenAddress, StringComparison.OrdinalIgnoreCase))
            { tok = prop.Value; found = true; break; }
        if (!found) return false;

        // Su Solana: "mintable"/"freezable" sono oggetti { status: "0"/"1" }
        if (tok.TryGetProperty("mintable", out var mint) && mint.ValueKind == JsonValueKind.Object)
            g.IsMintable ??= HttpHelper.GetString(mint, "status") == "1";

        long hc = HttpHelper.GetLong(tok, "holder_count");
        if (hc > 0) g.HolderCount ??= hc;

        if (tok.TryGetProperty("holders", out var holders) && holders.ValueKind == JsonValueKind.Array)
        {
            double sum = 0; int n = 0;
            foreach (var h in holders.EnumerateArray())
            {
                if (n++ >= 10) break;
                sum += HttpHelper.GetDouble(h, "percent");
            }
            if (n > 0) g.Top10HoldersPct ??= Math.Round(sum * 100.0, 1);
        }
        return true;
    }

    // ============================================================ Honeypot.is
    private static async Task<bool> HoneypotAsync(GemCandidate g, CancellationToken ct)
    {
        var chainId = HoneypotChain[g.Chain];
        var url = $"https://api.honeypot.is/v2/IsHoneypot?address={g.TokenAddress}&chainID={chainId}";
        using var doc = await HttpHelper.GetJsonAsync(url, ct);
        if (doc == null) return false;
        var root = doc.RootElement;

        if (root.TryGetProperty("honeypotResult", out var hp) && hp.ValueKind == JsonValueKind.Object
            && hp.TryGetProperty("isHoneypot", out var ih)
            && (ih.ValueKind == JsonValueKind.True || ih.ValueKind == JsonValueKind.False))
            g.IsHoneypot ??= ih.GetBoolean();

        if (root.TryGetProperty("simulationResult", out var sim) && sim.ValueKind == JsonValueKind.Object)
        {
            double bt = HttpHelper.GetDouble(sim, "buyTax");
            double st = HttpHelper.GetDouble(sim, "sellTax");
            if (bt > 0) g.BuyTaxPct ??= Math.Round(bt, 1);
            if (st > 0) g.SellTaxPct ??= Math.Round(st, 1);
        }
        if (root.TryGetProperty("token", out var tk) && tk.ValueKind == JsonValueKind.Object)
        {
            long th = HttpHelper.GetLong(tk, "totalHolders");
            if (th > 0) g.HolderCount ??= th;
        }
        return true;
    }

    // ========================================================== GeckoTerminal
    private static async Task<bool> GeckoTerminalAsync(GemCandidate g, CancellationToken ct)
    {
        var net = GtNet[g.Chain];
        var url = $"https://api.geckoterminal.com/api/v2/networks/{net}/tokens/{g.TokenAddress}";
        using var doc = await HttpHelper.GetJsonAsync(url, ct);
        if (doc == null || !doc.RootElement.TryGetProperty("data", out var data)
            || data.ValueKind != JsonValueKind.Object
            || !data.TryGetProperty("attributes", out var attr)
            || attr.ValueKind != JsonValueKind.Object) return false;

        g.CoinGeckoListed = HttpHelper.GetString(attr, "coingecko_coin_id").Length > 0;
        return true;
    }

    // ================================================================ Birdeye
    private static async Task<bool> BirdeyeAsync(GemCandidate g, string apiKey, CancellationToken ct)
    {
        var url = $"https://public-api.birdeye.so/defi/token_overview?address={g.TokenAddress}";
        var headers = new Dictionary<string, string> { ["X-API-KEY"] = apiKey, ["x-chain"] = "solana" };
        using var doc = await HttpHelper.GetJsonAsync(url, headers, ct);
        if (doc == null || !doc.RootElement.TryGetProperty("data", out var data)
            || data.ValueKind != JsonValueKind.Object) return false;

        long holder = HttpHelper.GetLong(data, "holder");
        if (holder > 0) g.HolderCount = holder;   // Birdeye più aggiornato: sovrascrive
        return true;
    }

    // ================================================================ Moralis
    private static async Task<bool> MoralisAsync(GemCandidate g, string apiKey, CancellationToken ct)
    {
        var chain = MoralisChain[g.Chain];
        var url = $"https://deep-index.moralis.io/api/v2.2/erc20/metadata?chain={chain}&addresses%5B0%5D={g.TokenAddress}";
        var headers = new Dictionary<string, string> { ["X-API-Key"] = apiKey };
        using var doc = await HttpHelper.GetJsonAsync(url, headers, ct);
        if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array
            || doc.RootElement.GetArrayLength() == 0) return false;

        var tok = doc.RootElement[0];
        if (tok.TryGetProperty("verified_contract", out var vc)
            && (vc.ValueKind == JsonValueKind.True || vc.ValueKind == JsonValueKind.False))
            g.IsOpenSource ??= vc.GetBoolean();
        if (tok.TryGetProperty("possible_spam", out var ps)
            && (ps.ValueKind == JsonValueKind.True || ps.ValueKind == JsonValueKind.False))
            g.PossibleSpam = ps.GetBoolean();
        return true;
    }

    // ==================================================== Punteggi finali
    /// <summary>Punteggio sicurezza 0..100 dai dati raccolti (null se nessun dato).</summary>
    public static void ComputeSecurityScore(GemCandidate g)
    {
        bool anyData = g.IsHoneypot.HasValue || g.BuyTaxPct.HasValue || g.SellTaxPct.HasValue
                       || g.IsOpenSource.HasValue || g.IsMintable.HasValue || g.HolderCount.HasValue
                       || g.Top10HoldersPct.HasValue || g.LpLockedPct.HasValue
                       || g.CoinGeckoListed.HasValue || g.PossibleSpam.HasValue;
        if (!anyData) { g.SecurityScore = null; return; }

        var notes = g.SecurityNotes;
        notes.Clear();

        if (g.IsHoneypot == true)
        {
            g.SecurityScore = 0;
            notes.Add("HONEYPOT: la vendita risulta bloccata — DA EVITARE");
            return;
        }

        double s = 50;
        if (g.IsHoneypot == false) { s += 15; notes.Add("test honeypot superato (vendita simulata ok)"); }
        if (g.IsOpenSource == true) { s += 8; notes.Add("contratto verificato/open source"); }
        else if (g.IsOpenSource == false) { s -= 12; notes.Add("contratto NON verificato"); }
        if (g.IsMintable == true) { s -= 10; notes.Add("supply mintabile (rischio diluizione)"); }

        double tax = Math.Max(g.BuyTaxPct ?? 0, g.SellTaxPct ?? 0);
        if (g.BuyTaxPct.HasValue || g.SellTaxPct.HasValue)
        {
            if (tax <= 2) { s += 8; notes.Add($"tasse contenute (buy {g.BuyTaxPct ?? 0:N1}% / sell {g.SellTaxPct ?? 0:N1}%)"); }
            else if (tax > 10) { s -= 20; notes.Add($"tasse ELEVATE (max {tax:N1}%)"); }
            else notes.Add($"tasse medie (max {tax:N1}%)");
        }

        if (g.HolderCount.HasValue)
        {
            if (g.HolderCount >= 10_000) { s += 15; notes.Add($"{g.HolderCount:N0} holders (community ampia)"); }
            else if (g.HolderCount >= 1_000) { s += 10; notes.Add($"{g.HolderCount:N0} holders"); }
            else if (g.HolderCount < 200) { s -= 8; notes.Add($"solo {g.HolderCount:N0} holders (early ma fragile)"); }
        }

        if (g.Top10HoldersPct.HasValue)
        {
            if (g.Top10HoldersPct <= 30) { s += 8; notes.Add($"top10 holders {g.Top10HoldersPct:N1}% (buona distribuzione)"); }
            else if (g.Top10HoldersPct >= 60) { s -= 15; notes.Add($"top10 holders {g.Top10HoldersPct:N1}% (forte concentrazione)"); }
        }

        if (g.LpLockedPct.HasValue)
        {
            if (g.LpLockedPct >= 80) { s += 10; notes.Add($"LP bloccata al {g.LpLockedPct:N0}%"); }
            else if (g.LpLockedPct < 20) { s -= 10; notes.Add($"LP bloccata solo al {g.LpLockedPct:N0}% (rischio rug)"); }
        }

        if (g.CoinGeckoListed == true) { s += 5; notes.Add("già censita su CoinGecko"); }
        if (g.PossibleSpam == true) { s -= 30; notes.Add("SEGNALATA come possibile spam (Moralis)"); }

        g.SecurityScore = Math.Round(Math.Clamp(s, 0, 100), 0);
    }

    /// <summary>MoonScore finale e potenziale multiplo verso il benchmark meme (~250M$, classe TURBO).</summary>
    public static void ComputeMoonScore(GemCandidate g)
    {
        const double BenchmarkMcap = 250_000_000;   // TURBO-class: traguardo realistico di una meme riuscita

        g.MoonScore = g.SecurityScore.HasValue
            ? Math.Round(0.65 * g.Score + 0.35 * g.SecurityScore.Value, 0)
            : Math.Round(g.Score * 0.85, 0);        // sicurezza ignota → leggera penalità

        g.PotentialX = g.MarketCapUsd > 0
            ? Math.Round(Math.Min(1000, BenchmarkMcap / g.MarketCapUsd), 0)
            : 0;

        g.PotentialLabel = g.IsHoneypot == true ? "ESCLUSA (honeypot)"
            : g.PotentialX >= 200 ? $"{g.PotentialX:N0}x (estremo)"
            : g.PotentialX >= 100 ? $"{g.PotentialX:N0}x possibile"
            : g.PotentialX >= 20 ? $"{g.PotentialX:N0}x"
            : g.PotentialX >= 5 ? $"{g.PotentialX:N0}x"
            : "< 5x";
    }

    private static Dictionary<string, string>? HeaderIf(string apiKey, string headerName)
        => apiKey.Length > 0 ? new Dictionary<string, string> { [headerName] = apiKey } : null;

    private static bool? Flag(JsonElement el, string prop)
    {
        var s = HttpHelper.GetString(el, prop);
        return s == "1" ? true : s == "0" ? false : null;
    }

    private static double? Frac(JsonElement el, string prop)
    {
        if (!el.TryGetProperty(prop, out var v)) return null;
        double d = HttpHelper.ParseDouble(v);
        return d > 0 || HttpHelper.GetString(el, prop) == "0" ? Math.Round(d * 100.0, 1) : null;
    }
}
