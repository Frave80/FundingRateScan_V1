using System.Text.Json;
using FundingRateScan.Services;

namespace FundingRateScan.Gems;

/// <summary>
/// Scoperta candidati da DEX Screener (endpoint pubblici, nessuna chiave):
/// token "boosted"/trending, ultimi profili e ricerca testuale; quindi recupero
/// dei dati di pair (prezzo, mcap, liquidità, volumi, txns, età).
/// </summary>
public sealed class DexScreenerDiscovery
{
    private const string TopBoosts = "https://api.dexscreener.com/token-boosts/top/v1";
    private const string LatestBoosts = "https://api.dexscreener.com/token-boosts/latest/v1";
    private const string Profiles = "https://api.dexscreener.com/token-profiles/latest/v1";
    private const string TokensBase = "https://api.dexscreener.com/latest/dex/tokens/";
    private const string SearchBase = "https://api.dexscreener.com/latest/dex/search?q=";

    public async Task<List<(string chain, string address)>> GetFeedAddressesAsync(GemSource sources, CancellationToken ct)
    {
        var set = new HashSet<(string, string)>();
        async Task Add(string url)
        {
            using var doc = await HttpHelper.GetJsonAsync(url, ct);
            if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) return;
            foreach (var e in doc.RootElement.EnumerateArray())
            {
                var chain = HttpHelper.GetString(e, "chainId");
                var addr = HttpHelper.GetString(e, "tokenAddress");
                if (chain.Length > 0 && addr.Length > 0) set.Add((chain, addr.ToLowerInvariant()));
            }
        }
        if (sources.HasFlag(GemSource.TopBoosts)) await Add(TopBoosts);
        if (sources.HasFlag(GemSource.LatestBoosts)) await Add(LatestBoosts);
        if (sources.HasFlag(GemSource.Profiles)) await Add(Profiles);
        return set.ToList();
    }

    /// <summary>Recupera i pair per un insieme di token (batch da 30) e ne estrae i candidati.</summary>
    public async Task<List<GemCandidate>> FetchPairsAsync(List<(string chain, string address)> tokens, CancellationToken ct)
    {
        var candidates = new List<GemCandidate>();
        for (int i = 0; i < tokens.Count; i += 30)
        {
            var batch = tokens.Skip(i).Take(30).Select(t => t.address).Distinct();
            var url = TokensBase + string.Join(",", batch);
            using var doc = await HttpHelper.GetJsonAsync(url, ct);
            if (doc == null || !doc.RootElement.TryGetProperty("pairs", out var pairs) || pairs.ValueKind != JsonValueKind.Array)
                continue;
            foreach (var p in pairs.EnumerateArray())
            {
                var g = ParsePair(p);
                if (g != null) candidates.Add(g);
            }
        }
        return candidates;
    }

    public async Task<List<GemCandidate>> SearchAsync(string query, CancellationToken ct)
    {
        var candidates = new List<GemCandidate>();
        if (string.IsNullOrWhiteSpace(query)) return candidates;
        using var doc = await HttpHelper.GetJsonAsync(SearchBase + Uri.EscapeDataString(query), ct);
        if (doc == null || !doc.RootElement.TryGetProperty("pairs", out var pairs) || pairs.ValueKind != JsonValueKind.Array)
            return candidates;
        foreach (var p in pairs.EnumerateArray())
        {
            var g = ParsePair(p);
            if (g != null) candidates.Add(g);
        }
        return candidates;
    }

    /// <summary>Costruisce un candidato da un oggetto pair DEX Screener.</summary>
    public static GemCandidate? ParsePair(JsonElement p)
    {
        if (!p.TryGetProperty("baseToken", out var bt) || bt.ValueKind != JsonValueKind.Object) return null;

        var g = new GemCandidate
        {
            Chain = HttpHelper.GetString(p, "chainId"),
            PairAddress = HttpHelper.GetString(p, "pairAddress").ToLowerInvariant(),
            Url = HttpHelper.GetString(p, "url"),
            TokenAddress = HttpHelper.GetString(bt, "address").ToLowerInvariant(),
            Symbol = HttpHelper.GetString(bt, "symbol"),
            Name = HttpHelper.GetString(bt, "name"),
            PriceUsd = HttpHelper.GetDouble(p, "priceUsd"),
            FdvUsd = HttpHelper.GetDouble(p, "fdv"),
            MarketCapUsd = HttpHelper.GetDouble(p, "marketCap"),
        };
        if (g.MarketCapUsd <= 0) g.MarketCapUsd = g.FdvUsd;   // ripiego su FDV

        if (p.TryGetProperty("liquidity", out var liq) && liq.ValueKind == JsonValueKind.Object)
            g.LiquidityUsd = HttpHelper.GetDouble(liq, "usd");

        if (p.TryGetProperty("volume", out var vol) && vol.ValueKind == JsonValueKind.Object)
        {
            g.Volume24hUsd = HttpHelper.GetDouble(vol, "h24");
            g.Volume1hUsd = HttpHelper.GetDouble(vol, "h1");
        }
        if (p.TryGetProperty("priceChange", out var pc) && pc.ValueKind == JsonValueKind.Object)
        {
            g.PriceChg5m = HttpHelper.GetDouble(pc, "m5");
            g.PriceChg1h = HttpHelper.GetDouble(pc, "h1");
            g.PriceChg6h = HttpHelper.GetDouble(pc, "h6");
            g.PriceChg24h = HttpHelper.GetDouble(pc, "h24");
        }
        if (p.TryGetProperty("txns", out var tx) && tx.TryGetProperty("h24", out var h24) && h24.ValueKind == JsonValueKind.Object)
        {
            g.Buys24 = (int)HttpHelper.GetDouble(h24, "buys");
            g.Sells24 = (int)HttpHelper.GetDouble(h24, "sells");
        }
        long created = HttpHelper.GetLong(p, "pairCreatedAt");
        if (created > 0)
            g.AgeHours = (DateTimeOffset.UtcNow - DateTimeOffset.FromUnixTimeMilliseconds(created)).TotalHours;

        return g;
    }
}
